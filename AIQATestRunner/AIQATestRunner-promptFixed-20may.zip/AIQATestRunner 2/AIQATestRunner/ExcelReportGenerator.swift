//
//  ExcelReportGenerator.swift
//  AIQATestRunner
//
//  Created by Sayed on 15/05/26.
//
//  Builds a minimal .xlsx workbook from a ReportSummary and saves it next to
//  the HTML report at ~/Desktop/e2e/build/aiqa-report.xlsx.
//
//  The XLSX format is a ZIP archive of small XML parts (OOXML). We write the
//  required parts to a temporary folder and use /usr/bin/zip to package them.
//  Strings are inlined (`t="inlineStr"`) to avoid the sharedStrings part — the
//  resulting file is slightly larger but the generator stays simple.
//
//  Columns (no timestamps, per product requirement):
//    A: Test Case       (TC_001, TC_002, ...)
//    B: Module          (Login, Logout, Home, ...)
//    C: Type            (Positive / Negative / Edge)
//    D: Title           (humanized title from the filename)
//    E: Status          (Passed / Failed)
//

import Foundation

// MARK: - Public Entry Point

/// Saves a `.xlsx` workbook summarizing every flow's pass/fail status into the
/// folder containing `aiqa-report.html`. Returns the destination URL on success.
@discardableResult
func generateAndSaveExcelReport(from summary: ReportSummary,
                                in folder: URL) -> URL? {
    let destination = folder.appendingPathComponent("aiqa-report.xlsx")

    let tempRoot = URL(fileURLWithPath: NSTemporaryDirectory(), isDirectory: true)
        .appendingPathComponent("aiqa-xlsx-\(UUID().uuidString)", isDirectory: true)

    do {
        try writeWorkbookParts(summary: summary, into: tempRoot)
        try? FileManager.default.removeItem(at: destination)
        try zipFolder(at: tempRoot, to: destination)
        print("✅ Excel report saved to \(destination.path)")
        return destination
    } catch {
        print("❌ Excel report: failed — \(error.localizedDescription)")
        try? FileManager.default.removeItem(at: tempRoot)
        return nil
    }
}

// MARK: - Workbook Authoring

private func writeWorkbookParts(summary: ReportSummary, into root: URL) throws {
    let fm = FileManager.default
    try? fm.removeItem(at: root)
    try fm.createDirectory(at: root, withIntermediateDirectories: true)
    try fm.createDirectory(at: root.appendingPathComponent("_rels"), withIntermediateDirectories: true)
    try fm.createDirectory(at: root.appendingPathComponent("xl/_rels"), withIntermediateDirectories: true)
    try fm.createDirectory(at: root.appendingPathComponent("xl/worksheets"), withIntermediateDirectories: true)

    try contentTypesXML().write(
        to: root.appendingPathComponent("[Content_Types].xml"),
        atomically: true, encoding: .utf8)

    try rootRelsXML().write(
        to: root.appendingPathComponent("_rels/.rels"),
        atomically: true, encoding: .utf8)

    try workbookXML().write(
        to: root.appendingPathComponent("xl/workbook.xml"),
        atomically: true, encoding: .utf8)

    try workbookRelsXML().write(
        to: root.appendingPathComponent("xl/_rels/workbook.xml.rels"),
        atomically: true, encoding: .utf8)

    try stylesXML().write(
        to: root.appendingPathComponent("xl/styles.xml"),
        atomically: true, encoding: .utf8)

    try sheetXML(summary: summary).write(
        to: root.appendingPathComponent("xl/worksheets/sheet1.xml"),
        atomically: true, encoding: .utf8)
}

// MARK: - XML Parts

private func contentTypesXML() -> String {
    """
    <?xml version="1.0" encoding="UTF-8" standalone="yes"?>
    <Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types">
      <Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/>
      <Default Extension="xml" ContentType="application/xml"/>
      <Override PartName="/xl/workbook.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet.main+xml"/>
      <Override PartName="/xl/worksheets/sheet1.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.worksheet+xml"/>
      <Override PartName="/xl/styles.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.styles+xml"/>
    </Types>
    """
}

private func rootRelsXML() -> String {
    """
    <?xml version="1.0" encoding="UTF-8" standalone="yes"?>
    <Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">
      <Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument" Target="xl/workbook.xml"/>
    </Relationships>
    """
}

private func workbookXML() -> String {
    """
    <?xml version="1.0" encoding="UTF-8" standalone="yes"?>
    <workbook xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main" xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships">
      <sheets>
        <sheet name="Test Results" sheetId="1" r:id="rId1"/>
      </sheets>
    </workbook>
    """
}

private func workbookRelsXML() -> String {
    """
    <?xml version="1.0" encoding="UTF-8" standalone="yes"?>
    <Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">
      <Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/worksheet" Target="worksheets/sheet1.xml"/>
      <Relationship Id="rId2" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/styles" Target="styles.xml"/>
    </Relationships>
    """
}

/// Style indices used by sheetXML when emitting cells via `s="N"`:
///   0 — default
///   1 — header (bold white on blue, centered)
///   2 — passed (green fill)
///   3 — failed (red fill, bold)
private func stylesXML() -> String {
    """
    <?xml version="1.0" encoding="UTF-8" standalone="yes"?>
    <styleSheet xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main">
      <fonts count="4">
        <font><sz val="11"/><name val="Calibri"/></font>
        <font><b/><sz val="11"/><color rgb="FFFFFFFF"/><name val="Calibri"/></font>
        <font><sz val="11"/><color rgb="FF166534"/><name val="Calibri"/></font>
        <font><b/><sz val="11"/><color rgb="FF991B1B"/><name val="Calibri"/></font>
      </fonts>
      <fills count="5">
        <fill><patternFill patternType="none"/></fill>
        <fill><patternFill patternType="gray125"/></fill>
        <fill><patternFill patternType="solid"><fgColor rgb="FF2563EB"/><bgColor rgb="FF2563EB"/></patternFill></fill>
        <fill><patternFill patternType="solid"><fgColor rgb="FFD1FADF"/><bgColor rgb="FFD1FADF"/></patternFill></fill>
        <fill><patternFill patternType="solid"><fgColor rgb="FFFEE4E2"/><bgColor rgb="FFFEE4E2"/></patternFill></fill>
      </fills>
      <borders count="1"><border><left/><right/><top/><bottom/><diagonal/></border></borders>
      <cellStyleXfs count="1"><xf numFmtId="0" fontId="0" fillId="0" borderId="0"/></cellStyleXfs>
      <cellXfs count="4">
        <xf numFmtId="0" fontId="0" fillId="0" borderId="0" xfId="0"/>
        <xf numFmtId="0" fontId="1" fillId="2" borderId="0" xfId="0" applyFont="1" applyFill="1" applyAlignment="1"><alignment horizontal="center" vertical="center"/></xf>
        <xf numFmtId="0" fontId="2" fillId="3" borderId="0" xfId="0" applyFont="1" applyFill="1" applyAlignment="1"><alignment horizontal="center"/></xf>
        <xf numFmtId="0" fontId="3" fillId="4" borderId="0" xfId="0" applyFont="1" applyFill="1" applyAlignment="1"><alignment horizontal="center"/></xf>
      </cellXfs>
      <cellStyles count="1"><cellStyle name="Normal" xfId="0" builtinId="0"/></cellStyles>
    </styleSheet>
    """
}

private func sheetXML(summary: ReportSummary) -> String {
    var rows: [String] = []

    // Header row.
    rows.append(makeRow(rowIndex: 1, cells: [
        (value: "Test Case", styleId: 1),
        (value: "Module",    styleId: 1),
        (value: "Type",      styleId: 1),
        (value: "Title",     styleId: 1),
        (value: "Status",    styleId: 1),
    ]))

    // Data rows in display order (module-grouped: login → middle → logout).
    var rowIndex = 2
    for group in summary.flowsByFeature {
        for flow in group.flows {
            let statusText  = flow.isPassed ? "Passed" : "Failed"
            let statusStyle = flow.isPassed ? 2 : 3
            rows.append(makeRow(rowIndex: rowIndex, cells: [
                (value: flow.serial,           styleId: 0),
                (value: group.display,         styleId: 0),
                (value: flow.type.capitalized, styleId: 0),
                (value: flow.displayTitle,     styleId: 0),
                (value: statusText,            styleId: statusStyle),
            ]))
            rowIndex += 1
        }
    }

    let lastRow = max(rowIndex - 1, 1)
    let dimensionRef = "A1:E\(lastRow)"

    // OOXML schema requires worksheet children in a strict order:
    // sheetPr → dimension → sheetViews → sheetFormatPr → cols → sheetData → …
    // Excel rejects out-of-order children (manifesting as a "repair" prompt
    // and a missing sheet1.xml part). Keep this order intact.
    return """
    <?xml version="1.0" encoding="UTF-8" standalone="yes"?>
    <worksheet xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main">
      <dimension ref="\(dimensionRef)"/>
      <sheetViews>
        <sheetView workbookViewId="0">
          <pane ySplit="1" topLeftCell="A2" activePane="bottomLeft" state="frozen"/>
        </sheetView>
      </sheetViews>
      <cols>
        <col min="1" max="1" width="12" customWidth="1"/>
        <col min="2" max="2" width="18" customWidth="1"/>
        <col min="3" max="3" width="12" customWidth="1"/>
        <col min="4" max="4" width="60" customWidth="1"/>
        <col min="5" max="5" width="12" customWidth="1"/>
      </cols>
      <sheetData>
    \(rows.joined(separator: "\n"))
      </sheetData>
    </worksheet>
    """
}

// MARK: - Row / Cell Builders

private func makeRow(rowIndex: Int, cells: [(value: String, styleId: Int)]) -> String {
    var parts: [String] = ["    <row r=\"\(rowIndex)\">"]
    for (col, cell) in cells.enumerated() {
        let ref = "\(columnLetter(col + 1))\(rowIndex)"
        let escaped = xmlEscape(cell.value)
        let styleAttr = cell.styleId == 0 ? "" : " s=\"\(cell.styleId)\""
        parts.append(
            #"      <c r="\#(ref)"\#(styleAttr) t="inlineStr"><is><t xml:space="preserve">\#(escaped)</t></is></c>"#
        )
    }
    parts.append("    </row>")
    return parts.joined(separator: "\n")
}

/// 1-indexed column number → Excel letter ("A", "B", ..., "Z", "AA", ...).
private func columnLetter(_ index: Int) -> String {
    var n = index
    var s = ""
    while n > 0 {
        let rem = (n - 1) % 26
        s = String(UnicodeScalar(65 + rem)!) + s
        n = (n - 1) / 26
    }
    return s
}

private func xmlEscape(_ s: String) -> String {
    s.replacingOccurrences(of: "&", with: "&amp;")
     .replacingOccurrences(of: "<", with: "&lt;")
     .replacingOccurrences(of: ">", with: "&gt;")
     .replacingOccurrences(of: "\"", with: "&quot;")
     .replacingOccurrences(of: "'", with: "&apos;")
}

// MARK: - Zipping

private enum XLSXError: LocalizedError {
    case zipFailed(status: Int32, stderr: String)
    var errorDescription: String? {
        switch self {
        case .zipFailed(let status, let stderr):
            return "zip exited with \(status): \(stderr)"
        }
    }
}

/// Packages the contents of `folder` into a `.xlsx` (zip) archive at `destination`.
/// We run `/usr/bin/zip` from inside `folder` so the archive's internal paths are
/// relative ("xl/workbook.xml" rather than "/tmp/.../xl/workbook.xml") — Excel
/// rejects absolute paths inside the package.
private func zipFolder(at folder: URL, to destination: URL) throws {
    let task = Process()
    task.launchPath = "/usr/bin/zip"
    task.currentDirectoryURL = folder
    task.arguments = ["-rXq", destination.path, "."]

    let stderrPipe = Pipe()
    task.standardError = stderrPipe
    task.standardOutput = Pipe()

    try task.run()
    task.waitUntilExit()

    let stderrData = stderrPipe.fileHandleForReading.readDataToEndOfFile()
    let stderrText = String(data: stderrData, encoding: .utf8) ?? ""

    // Best-effort cleanup of the staging folder — we keep going even if it fails.
    try? FileManager.default.removeItem(at: folder)

    if task.terminationStatus != 0 {
        throw XLSXError.zipFailed(status: task.terminationStatus, stderr: stderrText)
    }
}
