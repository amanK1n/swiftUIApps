//
//  VaultManager.swift
//  AIQATestRunner
//
//  Created by Sayed on 16/05/26.
//
//  Owns the test-data vault for the currently-active (app, platform).
//  The file URL is injected from WorkspaceManager via `reconfigure(fileURL:)`
//  every time the workspace / app / platform changes. The URL is passed in
//  (rather than fetched from WorkspaceManager.shared here) on purpose:
//  WorkspaceManager.init itself calls into this manager during first-launch
//  bootstrap, so reaching back into WorkspaceManager.shared during init
//  would re-enter `swift_once` and crash with EXC_BREAKPOINT.
//
//  The vault keeps two things per module:
//   • `data`       — input values the AI should reference as ${module.key}
//                    placeholders in POSITIVE flows.
//   • `assertions` — catalog of expected error states (toast or stay) the AI
//                    should use verbatim in NEGATIVE / EDGE flows.
//
//  The vault is *purely additive*: empty file → AI behaves exactly like today.
//  Partial file → AI uses what's there, falls back to literals/guesses for the
//  rest. Everything keyed on the slugified feature name typed in the UI.
//

import Foundation
import Combine

// MARK: - Models

/// Assertion `type` — v1 supports just `toast` and `stay` (covers ~95% of
/// negative-case assertions; `disabled` can be added later if needed).
enum VaultAssertionType: String, Codable, CaseIterable, Identifiable {
    case toast   // visible text appears (assertVisible on the message)
    case stay    // user stays on the current screen (assertVisible on a screen marker)
    var id: String { rawValue }

    var humanLabel: String {
        switch self {
        case .toast: return "Toast / Inline error text"
        case .stay:  return "Stay on screen (no advance)"
        }
    }
}

struct VaultAssertion: Codable, Hashable {
    var type: VaultAssertionType
    /// Holds `text` (toast) or `marker` (stay). Single field so the UI is
    /// simpler — meaning shifts based on `type`.
    var value: String

    init(type: VaultAssertionType, value: String) {
        self.type = type
        self.value = value
    }

    // Tolerant decoder so old/external files can use either `text` or `marker`
    // keys alongside `value`. Encoder always normalizes to `value`.
    private enum CodingKeys: String, CodingKey {
        case type, value, text, marker
    }

    init(from decoder: Decoder) throws {
        let c = try decoder.container(keyedBy: CodingKeys.self)
        self.type = (try? c.decode(VaultAssertionType.self, forKey: .type)) ?? .toast
        if let v = try? c.decode(String.self, forKey: .value) {
            self.value = v
        } else if let t = try? c.decode(String.self, forKey: .text) {
            self.value = t
        } else if let m = try? c.decode(String.self, forKey: .marker) {
            self.value = m
        } else {
            self.value = ""
        }
    }

    func encode(to encoder: Encoder) throws {
        var c = encoder.container(keyedBy: CodingKeys.self)
        try c.encode(type, forKey: .type)
        try c.encode(value, forKey: .value)
    }
}

struct VaultModule: Codable, Hashable {
    var data: [String: String] = [:]
    var assertions: [String: VaultAssertion] = [:]
}

struct Vault: Codable, Hashable {
    var modules: [String: VaultModule] = [:]
}

// MARK: - VaultManager (singleton, observable)

final class VaultManager: ObservableObject {
    static let shared = VaultManager()

    @Published private(set) var vault: Vault = Vault()
    /// Currently-targeted file URL. Nil before the workspace has been
    /// chosen (first launch). All persistence methods early-out when this
    /// is nil so the manager is safe to talk to from any code path.
    @Published private(set) var fileURL: URL?

    private var watcher: DispatchSourceFileSystemObject?
    private var watchedDescriptor: Int32 = -1
    private var isWritingOurselves: Bool = false

    private init() {
        // Don't touch disk until WorkspaceManager has resolved a context.
        // `reconfigure(fileURL:)` will be called from WorkspaceManager once
        // a workspace + app are available.
    }

    /// Re-points the manager at a new `test-data.json` URL, reloads, and
    /// starts watching the new file. Safe to call repeatedly — it tears
    /// down any previous watcher first. Passing `nil` clears the vault
    /// in memory (used during early launch before a workspace is picked).
    ///
    /// IMPORTANT: this is called *during* `WorkspaceManager.init` on first
    /// launch with a saved workspace. We must NOT read
    /// `WorkspaceManager.shared` here — doing so re-enters the singleton's
    /// `swift_once` and traps with EXC_BREAKPOINT. The caller passes the
    /// URL in so we can resolve it without reaching back.
    func reconfigure(fileURL newURL: URL?) {
        stopWatching()
        self.fileURL = newURL
        guard newURL != nil else {
            // No active context yet — start clean so the UI doesn't show
            // stale modules from a previously-loaded vault.
            self.vault = Vault()
            return
        }

        ensureTemplateExists()
        reload()
        startWatching()
    }

    // MARK: First-run template

    /// Ships an empty `test-data.json` on first launch so the Test Data tab
    /// has something to show. Existing files are never touched.
    private func ensureTemplateExists() {
        guard let url = fileURL else { return }
        let folder = url.deletingLastPathComponent()
        try? FileManager.default.createDirectory(at: folder, withIntermediateDirectories: true)

        guard !FileManager.default.fileExists(atPath: url.path) else { return }

        let starter = Vault(modules: [:])
        guard let data = try? jsonEncoder().encode(starter) else { return }
        try? data.write(to: url, options: .atomic)
        print("📦 Vault: created empty template at \(url.path)")
    }

    // MARK: Load / Save

    /// Re-reads the JSON from disk. Failures are logged but never thrown — the
    /// vault always exposes *some* state so the rest of the app works.
    func reload() {
        guard let url = fileURL, let data = try? Data(contentsOf: url) else {
            self.vault = Vault()
            return
        }
        do {
            let decoded = try JSONDecoder().decode(Vault.self, from: data)
            self.vault = decoded
        } catch {
            print("⚠️ Vault: decode failed (\(error.localizedDescription)). Treating as empty.")
            self.vault = Vault()
        }
    }

    /// Writes the in-memory vault back to disk. Guarded against re-triggering
    /// our own FolderWatcher.
    func save(_ newVault: Vault) {
        self.vault = newVault
        guard let url = fileURL else {
            print("⚠️ Vault: cannot save — no active workspace context")
            return
        }
        do {
            let data = try jsonEncoder().encode(newVault)
            isWritingOurselves = true
            try data.write(to: url, options: .atomic)
            DispatchQueue.main.asyncAfter(deadline: .now() + 0.2) { [weak self] in
                self?.isWritingOurselves = false
            }
            print("📦 Vault: saved (\(newVault.modules.count) module(s))")
        } catch {
            print("❌ Vault: save failed — \(error.localizedDescription)")
        }
    }

    // MARK: External-edit watcher

    private func stopWatching() {
        watcher?.cancel()
        watcher = nil
        watchedDescriptor = -1
    }

    private func startWatching() {
        guard let url = fileURL else { return }
        let fd = open(url.path, O_EVTONLY)
        guard fd >= 0 else { return }
        watchedDescriptor = fd

        let src = DispatchSource.makeFileSystemObjectSource(
            fileDescriptor: fd,
            eventMask: [.write, .extend, .delete, .rename],
            queue: .main
        )
        src.setEventHandler { [weak self] in
            guard let self else { return }
            if self.isWritingOurselves { return }
            self.reload()
        }
        src.setCancelHandler { [weak self] in
            if let fd = self?.watchedDescriptor, fd >= 0 {
                close(fd)
            }
        }
        src.resume()
        self.watcher = src
    }

    // MARK: Prompt scoping

    /// Builds the per-call vault block injected into the AI prompt.
    /// Returns an empty string when there's nothing to inject (so the prompt
    /// is byte-identical to today's behavior).
    func promptBlock(forModuleSlug slug: String) -> String {
        guard let entry = vault.modules[slug] else { return "" }
        let hasData = !entry.data.isEmpty
        let hasAssertions = !entry.assertions.isEmpty
        guard hasData || hasAssertions else { return "" }

        var lines: [String] = []
        lines.append("")
        lines.append("VAULT FOR THIS MODULE — strict rules below:")

        if hasData {
            lines.append("")
            lines.append("TEST DATA (use these placeholders for matching fields in POSITIVE flows):")
            for key in entry.data.keys.sorted() {
                lines.append("- ${\(slug).\(key)}")
            }
        }

        if hasAssertions {
            lines.append("")
            lines.append("ERROR-STATE CATALOG:")
            for scenarioId in entry.assertions.keys.sorted() {
                let a = entry.assertions[scenarioId]!
                switch a.type {
                case .toast:
                    lines.append("- \(slug).\(scenarioId): toast → \"\(a.value)\"")
                case .stay:
                    lines.append("- \(slug).\(scenarioId): stay-on-screen marker → \"\(a.value)\"")
                }
            }
        }

        lines.append("")
        lines.append("RULES:")
        if hasData {
            lines.append("- POSITIVE flows: use a placeholder above whenever a textfield semantically matches; otherwise inline a realistic literal value.")
            lines.append("- NEGATIVE / EDGE flows: ALWAYS inline literal invalid/boundary values — never use placeholders for inputs.")
        }
        if hasAssertions {
            lines.append("- If <case_id> matches one in the catalog above, use that exact text in `Visible \"...\"` (for toast) or in the screen-marker check (for stay).")
            lines.append("- If you invent a NEW <case_id> that isn't in the catalog, emit Visible \"<TODO: confirm copy>\" — the user will fill it in.")
            lines.append("- NEVER paraphrase a catalog entry's text. NEVER invent placeholder names.")
        }
        lines.append("")
        return lines.joined(separator: "\n")
    }

    // MARK: Env-file generation for maestro --env-file

    /// Flattens every module.data value into MAESTRO-friendly `KEY=value` lines.
    /// Key format: `<MODULE_UPPER>_<FIELD_UPPER>`. Matches the same flattening
    /// the YAML transpiler does for `${module.field}` references.
    func flattenedEnvFileContents() -> String {
        var lines: [String] = []
        for moduleName in vault.modules.keys.sorted() {
            let module = vault.modules[moduleName]!
            for key in module.data.keys.sorted() {
                let envKey = envVarName(module: moduleName, field: key)
                let envVal = escapeEnvValue(module.data[key] ?? "")
                lines.append("\(envKey)=\(envVal)")
            }
        }
        return lines.joined(separator: "\n") + (lines.isEmpty ? "" : "\n")
    }

    /// Same flattening as `flattenedEnvFileContents()` but returned as a
    /// `[String: String]` dictionary. Used by the maestro runner to inject
    /// vault values into the process environment — maestro substitutes
    /// `${VAR}` in YAMLs against `System.getenv()` in addition to its own
    /// `--env KEY=VALUE` flags, so setting them on the child process is the
    /// simplest and least error-prone path (no shell-escaping concerns).
    func flattenedEnvDict() -> [String: String] {
        var dict: [String: String] = [:]
        for moduleName in vault.modules.keys.sorted() {
            let module = vault.modules[moduleName]!
            for key in module.data.keys.sorted() {
                dict[envVarName(module: moduleName, field: key)] = module.data[key] ?? ""
            }
        }
        return dict
    }

    /// Writes the env file to a temp path and returns its URL. Returns nil
    /// when there's nothing to inject. Kept around for inspection/debugging
    /// (and as a fallback if we ever want to switch to `--env-file` once
    /// maestro adds support); not used by the active runner path.
    func writeTempEnvFile() -> URL? {
        let contents = flattenedEnvFileContents()
        guard !contents.isEmpty else { return nil }

        let url = URL(fileURLWithPath: NSTemporaryDirectory(), isDirectory: true)
            .appendingPathComponent("aiqa-env-\(UUID().uuidString).properties")
        do {
            try contents.write(to: url, atomically: true, encoding: .utf8)
            return url
        } catch {
            print("❌ Vault: failed to write env file — \(error.localizedDescription)")
            return nil
        }
    }

    // MARK: Write-back (silent)

    /// Records (or updates) an assertion for `<module>.<scenarioId>`. Used by
    /// the YAML transpiler when the user has filled in a `<TODO>` in the
    /// preview. Silent: saves immediately, prints a single confirmation log.
    func upsertAssertion(module: String, scenarioId: String, assertion: VaultAssertion) {
        var copy = vault
        var entry = copy.modules[module] ?? VaultModule()
        let existing = entry.assertions[scenarioId]
        if existing == assertion { return }   // no-op if unchanged

        entry.assertions[scenarioId] = assertion
        copy.modules[module] = entry
        save(copy)
        print("📦 Vault: wrote back assertion \(module).\(scenarioId) = \"\(assertion.value)\" [\(assertion.type.rawValue)]")
    }

    // MARK: Module slug listing (for the dropdown)

    func availableModuleSlugs() -> [String] {
        vault.modules.keys.sorted()
    }

    // MARK: Helpers

    private func jsonEncoder() -> JSONEncoder {
        let enc = JSONEncoder()
        enc.outputFormatting = [.prettyPrinted, .sortedKeys]
        return enc
    }
}

// MARK: - Free helpers shared with the YAML transpiler

/// Slugifies arbitrary user-typed feature names into the canonical vault key.
/// `Login` → `login`, `Send Money` → `send_money`, etc. Single source of truth
/// for "what does this user-typed feature name resolve to?"
func vaultSlug(_ raw: String) -> String {
    let lowered = raw.lowercased()
    let allowed = CharacterSet.alphanumerics
    var converted = ""
    for scalar in lowered.unicodeScalars {
        converted.append(allowed.contains(scalar) ? Character(scalar) : "_")
    }
    while converted.contains("__") {
        converted = converted.replacingOccurrences(of: "__", with: "_")
    }
    return converted.trimmingCharacters(in: CharacterSet(charactersIn: "_"))
}

/// Converts a `module.field` pair into the flat `MODULE_FIELD` env-var name
/// that Maestro accepts. Single source of truth — also used by `VaultManager`
/// when flattening to the `--env-file`.
func envVarName(module: String, field: String) -> String {
    let m = vaultSlug(module).uppercased()
    let f = vaultSlug(field).uppercased()
    return "\(m)_\(f)"
}

/// Best-effort escape for env-file values. Maestro reads `KEY=VALUE` lines —
/// newlines would break the file, so we strip them. Quotes inside values are
/// fine because maestro doesn't unquote.
private func escapeEnvValue(_ raw: String) -> String {
    raw.replacingOccurrences(of: "\r", with: "")
       .replacingOccurrences(of: "\n", with: " ")
}
