//
//  WorkspaceManager.swift
//  AIQATestRunner
//
//  Owns the multi-app, multi-platform workspace layout.
//
//  Folder structure inside any chosen workspace:
//
//    <workspace>/
//    ├── aiqa.json                    ← workspace manifest (apps + last-active)
//    └── <AppName>/
//        ├── ios/
//        │   ├── flows/               ← Maestro .yaml flows
//        │   ├── build/               ← reports (html, xlsx)
//        │   └── test-data.json       ← Vault for this (app, platform)
//        ├── android/
//        │   ├── flows/
//        │   ├── build/
//        │   └── test-data.json
//        └── web/
//            ├── flows/
//            ├── build/
//            └── test-data.json
//
//  Why per-(app, platform):
//  • Element labels, toast text, and even available modules differ across
//    iOS/Android/Web for the *same* app — keeping the vault per-platform is
//    the only way to avoid cross-platform pollution.
//  • Reports/history per (app, platform) keeps runs isolated.
//
//  Persistence:
//  • `UserDefaults` stores just the workspace URL — small, system-managed.
//  • Everything else (apps, last-active app, last-active platform) lives in
//    `<workspace>/aiqa.json` so each workspace remembers its OWN context.
//    Switching back to an older workspace restores exactly where the user
//    left off there.
//

import Foundation
import AppKit
import Combine

// MARK: - Platform

enum Platform: String, Codable, CaseIterable, Identifiable {
    case ios, android, web
    var id: String { rawValue }

    var displayName: String {
        switch self {
        case .ios:     return "iOS"
        case .android: return "Android"
        case .web:     return "Web"
        }
    }

    /// Label shown next to the AppId TextField. Each platform identifies an
    /// app under test differently — bundle id (iOS), package name (Android),
    /// base URL (Web).
    var appIdFieldLabel: String {
        switch self {
        case .ios:     return "Bundle Id"
        case .android: return "Package Name"
        case .web:     return "URL"
        }
    }

    var appIdPlaceholder: String {
        switch self {
        case .ios:     return "com.company.app"
        case .android: return "com.company.app"
        case .web:     return "https://app.company.com"
        }
    }

    /// Whether this platform can run automation today.
    /// Web is folder-ready but the runner is intentionally left out of v1
    /// (Maestro is mobile-only; Playwright integration is a v2 task).
    var isRunnable: Bool { self != .web }

    /// Whether this platform has an emulator/simulator concept the Boot
    /// button can drive. Web just opens a browser, so we treat it specially.
    var hasSimulator: Bool { self != .web }
}

// MARK: - Manifest models

/// One app registered in the workspace. Holds the three platform-specific
/// identifiers — only the ones the user filled in will be non-nil/non-empty.
/// Stored verbatim in `aiqa.json`.
struct AppManifest: Codable, Hashable {
    var name: String
    var iosBundleId: String
    var androidPackage: String
    var webURL: String

    init(
        name: String,
        iosBundleId: String = "",
        androidPackage: String = "",
        webURL: String = ""
    ) {
        self.name = name
        self.iosBundleId = iosBundleId
        self.androidPackage = androidPackage
        self.webURL = webURL
    }

    func appId(for platform: Platform) -> String {
        switch platform {
        case .ios:     return iosBundleId
        case .android: return androidPackage
        case .web:     return webURL
        }
    }

    /// Returns a copy with the platform-specific id updated.
    func setting(appId: String, for platform: Platform) -> AppManifest {
        var copy = self
        switch platform {
        case .ios:     copy.iosBundleId = appId
        case .android: copy.androidPackage = appId
        case .web:     copy.webURL = appId
        }
        return copy
    }
}

struct WorkspaceManifest: Codable {
    /// Schema version — bump this if we ever change the on-disk shape so we
    /// can do best-effort migrations without breaking older workspaces.
    var version: Int = 1
    var apps: [AppManifest] = []
    /// Name of the app the user was last working on inside THIS workspace.
    var lastActiveApp: String? = nil
    /// Raw value of the last platform the user was on inside THIS workspace.
    var lastActivePlatform: String? = nil
}

// MARK: - WorkspaceManager

/// Singleton, observable. Every path-resolving call in the app routes
/// through this object — that's how the entire UI re-scopes to a new
/// (app, platform) the moment the user picks one from the header.
final class WorkspaceManager: ObservableObject {
    static let shared = WorkspaceManager()

    // MARK: Published state

    @Published private(set) var workspaceURL: URL?
    @Published private(set) var manifest: WorkspaceManifest = WorkspaceManifest()
    @Published private(set) var activeAppName: String?
    @Published var activePlatform: Platform = .ios {
        didSet { didMutateContext() }
    }

    // MARK: Constants

    private let defaultsKey = "AIQAWorkspaceURL"
    private let manifestFileName = "aiqa.json"

    // MARK: Init

    private init() {
        if let saved = UserDefaults.standard.string(forKey: defaultsKey),
           !saved.isEmpty {
            let url = URL(fileURLWithPath: saved, isDirectory: true)
            if FileManager.default.fileExists(atPath: url.path) {
                loadWorkspace(at: url, persist: false)
                return
            }
            // Path was set but the folder is gone — clear so the picker shows.
            UserDefaults.standard.removeObject(forKey: defaultsKey)
        }
        // No saved workspace; UI will trigger a picker via `needsWorkspacePicker`.
    }

    // MARK: Loading / switching

    /// True when the app has no workspace yet — the UI uses this to drive
    /// the first-launch picker sheet.
    var needsWorkspacePicker: Bool { workspaceURL == nil }

    /// True when the workspace is set but has zero apps — the UI uses this
    /// to drive the "create your first app" sheet.
    var needsFirstAppCreation: Bool {
        workspaceURL != nil && manifest.apps.isEmpty
    }

    /// Selects (or switches to) a workspace. Loads its manifest if present;
    /// otherwise creates a fresh empty manifest.
    func selectWorkspace(_ url: URL) {
        loadWorkspace(at: url, persist: true)
    }

    private func loadWorkspace(at url: URL, persist: Bool) {
        try? FileManager.default.createDirectory(
            at: url, withIntermediateDirectories: true
        )

        self.workspaceURL = url
        self.manifest = readOrCreateManifest(at: url)

        // Restore the per-workspace last-active context if it's still valid.
        if let name = manifest.lastActiveApp,
           manifest.apps.contains(where: { $0.name == name }) {
            self.activeAppName = name
        } else {
            self.activeAppName = manifest.apps.first?.name
        }

        if let raw = manifest.lastActivePlatform,
           let p = Platform(rawValue: raw) {
            self.activePlatform = p
        } else {
            self.activePlatform = .ios
        }

        if persist {
            UserDefaults.standard.set(url.path, forKey: defaultsKey)
        }

        // Make sure scaffolding exists for whatever (app, platform) we're
        // landing on so the rest of the app sees real directories.
        ensureCurrentContextDirectories()

        // Re-point dependent services at the new workspace.
        // Pass URLs in rather than letting these managers re-fetch them
        // from `WorkspaceManager.shared`. During first launch this method
        // runs inside `WorkspaceManager.init`, where `Self.shared` is mid-
        // construction and accessing it would re-enter `swift_once` and
        // crash with EXC_BREAKPOINT.
        VaultManager.shared.reconfigure(fileURL: self.currentVaultURL())
        BuildManager.shared.reconfigure(buildsURL: self.currentBuildsURL())
        NotificationCenter.default.post(name: .aiqaWorkspaceContextChanged, object: nil)
    }

    // MARK: Manifest persistence

    private func manifestURL(in workspace: URL) -> URL {
        workspace.appendingPathComponent(manifestFileName)
    }

    private func readOrCreateManifest(at workspace: URL) -> WorkspaceManifest {
        let url = manifestURL(in: workspace)
        if let data = try? Data(contentsOf: url),
           let decoded = try? JSONDecoder().decode(WorkspaceManifest.self, from: data) {
            return decoded
        }
        let fresh = WorkspaceManifest()
        writeManifest(fresh, to: workspace)
        return fresh
    }

    private func writeManifest(_ m: WorkspaceManifest, to workspace: URL) {
        let enc = JSONEncoder()
        enc.outputFormatting = [.prettyPrinted, .sortedKeys]
        guard let data = try? enc.encode(m) else { return }
        try? data.write(to: manifestURL(in: workspace), options: .atomic)
    }

    private func saveManifest() {
        guard let ws = workspaceURL else { return }
        writeManifest(manifest, to: ws)
    }

    // MARK: App creation

    /// Adds a new app to the workspace and scaffolds its full folder tree.
    /// Returns nil and prints when the name conflicts or is invalid.
    @discardableResult
    func createApp(
        name: String,
        iosBundleId: String = "",
        androidPackage: String = "",
        webURL: String = ""
    ) -> AppManifest? {
        guard workspaceURL != nil else { return nil }

        let trimmed = name.trimmingCharacters(in: .whitespacesAndNewlines)
        guard !trimmed.isEmpty,
              !trimmed.contains("/"),
              !trimmed.contains("\\"),
              !manifest.apps.contains(where: { $0.name.caseInsensitiveCompare(trimmed) == .orderedSame }) else {
            print("⚠️ Workspace: cannot create app — invalid or duplicate name '\(trimmed)'")
            return nil
        }

        let app = AppManifest(
            name: trimmed,
            iosBundleId: iosBundleId.trimmingCharacters(in: .whitespacesAndNewlines),
            androidPackage: androidPackage.trimmingCharacters(in: .whitespacesAndNewlines),
            webURL: webURL.trimmingCharacters(in: .whitespacesAndNewlines)
        )

        manifest.apps.append(app)
        scaffoldDirectories(for: app)
        activeAppName = app.name
        manifest.lastActiveApp = app.name
        saveManifest()
        // Pass URLs in rather than letting these managers re-fetch them
        // from `WorkspaceManager.shared`. During first launch this method
        // runs inside `WorkspaceManager.init`, where `Self.shared` is mid-
        // construction and accessing it would re-enter `swift_once` and
        // crash with EXC_BREAKPOINT.
        VaultManager.shared.reconfigure(fileURL: self.currentVaultURL())
        BuildManager.shared.reconfigure(buildsURL: self.currentBuildsURL())
        NotificationCenter.default.post(name: .aiqaWorkspaceContextChanged, object: nil)
        return app
    }

    /// Creates `<app>/{ios,android,web}/{flows,build}/` and an empty
    /// `test-data.json` per platform. All three platforms get scaffolded
    /// upfront — empty platforms cost nothing on disk and make switching
    /// instant later.
    private func scaffoldDirectories(for app: AppManifest) {
        guard let ws = workspaceURL else { return }
        let appRoot = ws.appendingPathComponent(app.name, isDirectory: true)
        for platform in Platform.allCases {
            let platformRoot = appRoot.appendingPathComponent(platform.rawValue, isDirectory: true)
            // "build" = reports folder, "builds" = uploaded artefacts.
            // Both scaffolded upfront so the file watchers / managers
            // never encounter a missing path.
            for sub in ["flows", "build", "builds"] {
                let dir = platformRoot.appendingPathComponent(sub, isDirectory: true)
                try? FileManager.default.createDirectory(at: dir, withIntermediateDirectories: true)
            }
            let vaultURL = platformRoot.appendingPathComponent("test-data.json")
            if !FileManager.default.fileExists(atPath: vaultURL.path) {
                let starter = Vault(modules: [:])
                let enc = JSONEncoder()
                enc.outputFormatting = [.prettyPrinted, .sortedKeys]
                if let data = try? enc.encode(starter) {
                    try? data.write(to: vaultURL, options: .atomic)
                }
            }
        }
    }

    // MARK: Active context mutation

    func setActiveApp(_ name: String) {
        guard manifest.apps.contains(where: { $0.name == name }) else { return }
        activeAppName = name
        manifest.lastActiveApp = name
        saveManifest()
        ensureCurrentContextDirectories()
        // Pass URLs in rather than letting these managers re-fetch them
        // from `WorkspaceManager.shared`. During first launch this method
        // runs inside `WorkspaceManager.init`, where `Self.shared` is mid-
        // construction and accessing it would re-enter `swift_once` and
        // crash with EXC_BREAKPOINT.
        VaultManager.shared.reconfigure(fileURL: self.currentVaultURL())
        BuildManager.shared.reconfigure(buildsURL: self.currentBuildsURL())
        NotificationCenter.default.post(name: .aiqaWorkspaceContextChanged, object: nil)
    }

    /// Called by `activePlatform.didSet` — persists the choice + refreshes
    /// services that scope by platform (vault, module discovery, reports).
    private func didMutateContext() {
        manifest.lastActivePlatform = activePlatform.rawValue
        saveManifest()
        ensureCurrentContextDirectories()
        // Pass URLs in rather than letting these managers re-fetch them
        // from `WorkspaceManager.shared`. During first launch this method
        // runs inside `WorkspaceManager.init`, where `Self.shared` is mid-
        // construction and accessing it would re-enter `swift_once` and
        // crash with EXC_BREAKPOINT.
        VaultManager.shared.reconfigure(fileURL: self.currentVaultURL())
        BuildManager.shared.reconfigure(buildsURL: self.currentBuildsURL())
        NotificationCenter.default.post(name: .aiqaWorkspaceContextChanged, object: nil)
    }

    /// Updates the platform-specific app id stored on the active app's
    /// manifest entry. Called from the AppId TextField on commit.
    func setActiveAppId(_ value: String) {
        guard let name = activeAppName,
              let idx = manifest.apps.firstIndex(where: { $0.name == name }) else { return }
        let updated = manifest.apps[idx].setting(appId: value, for: activePlatform)
        // Avoid a no-op write that would still touch the file's mtime.
        guard updated != manifest.apps[idx] else { return }
        manifest.apps[idx] = updated
        saveManifest()
    }

    // MARK: Path resolution (THE API the rest of the app uses)

    /// `<workspace>/<app>/<platform>/`. Nil if no workspace or no app.
    func currentPlatformRoot() -> URL? {
        guard let ws = workspaceURL, let name = activeAppName else { return nil }
        return ws
            .appendingPathComponent(name, isDirectory: true)
            .appendingPathComponent(activePlatform.rawValue, isDirectory: true)
    }

    func currentFlowsURL() -> URL? {
        currentPlatformRoot()?.appendingPathComponent("flows", isDirectory: true)
    }

    /// Folder where the runner stores HTML / Excel reports.
    /// Singular `build/` — matches the historical name on disk.
    func currentBuildURL() -> URL? {
        currentPlatformRoot()?.appendingPathComponent("build", isDirectory: true)
    }

    /// Folder where uploaded app artefacts live (.app / .ipa / .apk).
    /// Plural `builds/` — disambiguates from the singular report folder.
    func currentBuildsURL() -> URL? {
        currentPlatformRoot()?.appendingPathComponent("builds", isDirectory: true)
    }

    func currentVaultURL() -> URL? {
        currentPlatformRoot()?.appendingPathComponent("test-data.json")
    }

    /// The active app's manifest entry, if any.
    var currentApp: AppManifest? {
        guard let name = activeAppName else { return nil }
        return manifest.apps.first(where: { $0.name == name })
    }

    /// AppId value for the current (app, platform) — empty string when
    /// either is missing.
    var currentAppId: String { currentApp?.appId(for: activePlatform) ?? "" }

    /// Creates the active context's directories on demand. Cheap and
    /// idempotent — covers the case where someone deleted folders manually.
    private func ensureCurrentContextDirectories() {
        guard let root = currentPlatformRoot() else { return }
        for sub in ["flows", "build", "builds"] {
            let dir = root.appendingPathComponent(sub, isDirectory: true)
            try? FileManager.default.createDirectory(at: dir, withIntermediateDirectories: true)
        }
    }

    // MARK: Legacy migration (~/Desktop/e2e/)

    /// Returns true when a legacy `~/Desktop/e2e/` folder exists with
    /// content the user might want to keep — flat YAMLs, a `test-data.json`,
    /// or a `build/` folder. Empty / non-existent folders return false.
    static func legacyE2EFolderHasContent() -> Bool {
        let url = legacyE2EFolderURL()
        guard FileManager.default.fileExists(atPath: url.path) else { return false }
        let contents = (try? FileManager.default.contentsOfDirectory(
            at: url,
            includingPropertiesForKeys: nil,
            options: [.skipsHiddenFiles]
        )) ?? []
        return contents.contains { url in
            let ext = url.pathExtension.lowercased()
            return ext == "yaml" || ext == "yml" ||
                   url.lastPathComponent == "test-data.json" ||
                   url.lastPathComponent == "build"
        }
    }

    static func legacyE2EFolderURL() -> URL {
        FileManager.default.homeDirectoryForCurrentUser
            .appendingPathComponent("Desktop", isDirectory: true)
            .appendingPathComponent("e2e", isDirectory: true)
    }

    /// One-shot migration of `~/Desktop/e2e/` into the new layout:
    ///   • Workspace = `~/Desktop/e2e/` (kept in place to minimize surprise).
    ///   • App = "Default".
    ///   • Existing `.yaml` files → `Default/ios/flows/`.
    ///   • Existing `test-data.json` → `Default/ios/test-data.json`.
    ///   • Existing `build/` → `Default/ios/build/`.
    ///
    /// Idempotent — safe to call even if some moves already happened.
    func migrateLegacyE2EFolder() {
        let legacy = Self.legacyE2EFolderURL()
        guard FileManager.default.fileExists(atPath: legacy.path) else { return }

        selectWorkspace(legacy)

        // Create the Default app if it doesn't already exist.
        if !manifest.apps.contains(where: { $0.name == "Default" }) {
            createApp(name: "Default")
        }
        setActiveApp("Default")
        activePlatform = .ios

        guard let flows = currentFlowsURL(), let build = currentBuildURL() else { return }
        try? FileManager.default.createDirectory(at: flows, withIntermediateDirectories: true)
        try? FileManager.default.createDirectory(at: build, withIntermediateDirectories: true)

        let entries = (try? FileManager.default.contentsOfDirectory(
            at: legacy,
            includingPropertiesForKeys: nil,
            options: [.skipsHiddenFiles]
        )) ?? []

        for entry in entries {
            let name = entry.lastPathComponent
            // Skip the new layout's own files/folders we just scaffolded.
            if name == "aiqa.json" || name == "Default" { continue }

            let ext = entry.pathExtension.lowercased()
            if ext == "yaml" || ext == "yml" {
                moveItem(entry, into: flows)
            } else if name == "test-data.json" {
                let dest = currentPlatformRoot()?.appendingPathComponent("test-data.json")
                if let dest { moveItem(entry, to: dest) }
            } else if name == "build" {
                // Move contents of legacy build/ into Default/ios/build/.
                let kids = (try? FileManager.default.contentsOfDirectory(
                    at: entry,
                    includingPropertiesForKeys: nil,
                    options: [.skipsHiddenFiles]
                )) ?? []
                for kid in kids { moveItem(kid, into: build) }
                try? FileManager.default.removeItem(at: entry)
            }
        }

        // Pass URLs in rather than letting these managers re-fetch them
        // from `WorkspaceManager.shared`. During first launch this method
        // runs inside `WorkspaceManager.init`, where `Self.shared` is mid-
        // construction and accessing it would re-enter `swift_once` and
        // crash with EXC_BREAKPOINT.
        VaultManager.shared.reconfigure(fileURL: self.currentVaultURL())
        BuildManager.shared.reconfigure(buildsURL: self.currentBuildsURL())
        NotificationCenter.default.post(name: .aiqaWorkspaceContextChanged, object: nil)
        print("🚚 Workspace: migrated ~/Desktop/e2e/ → Default/ios/")
    }

    private func moveItem(_ src: URL, into folder: URL) {
        let dest = folder.appendingPathComponent(src.lastPathComponent)
        moveItem(src, to: dest)
    }

    private func moveItem(_ src: URL, to dest: URL) {
        // If dest already exists, leave the source alone — user can resolve
        // manually. Beats overwriting and losing data.
        guard !FileManager.default.fileExists(atPath: dest.path) else { return }
        do {
            try FileManager.default.moveItem(at: src, to: dest)
        } catch {
            print("⚠️ Workspace: could not move \(src.lastPathComponent) → \(dest.path): \(error.localizedDescription)")
        }
    }
}

// MARK: - Notifications

extension Notification.Name {
    /// Posted whenever the active (workspace, app, platform) tuple changes —
    /// listeners refresh module lists, reload vaults, etc.
    static let aiqaWorkspaceContextChanged = Notification.Name("aiqaWorkspaceContextChanged")
}
