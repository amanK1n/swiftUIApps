//
//  UItilityExplorer.swift
//  AIQATestRunner
//
//  Created by Sayed on 16/04/26.
//

import Foundation
import AppKit

// MARK: - iOS simulator helpers

/// Boots the iOS simulator with the given UDID via `simctl boot`. No-op if
/// the device is already running (simctl would return an error in that case,
/// which we swallow and treat as success — the user's intent is "make this
/// device available", and it already is). Always opens Simulator.app
/// afterwards so the user sees a window.
func bootIOSSimulator(udid: String) {
    let task = Process()
    task.launchPath = "/usr/bin/xcrun"
    task.arguments = ["simctl", "boot", udid]

    let pipe = Pipe()
    task.standardOutput = pipe
    task.standardError = pipe

    do {
        try task.run()
        task.waitUntilExit()
        let data = pipe.fileHandleForReading.readDataToEndOfFile()
        if let output = String(data: data, encoding: .utf8), !output.isEmpty {
            print(output)
        }
    } catch {
        print("Error booting simulator: \(error)")
    }

    openSimulatorApp()
}

func openSimulatorApp() {
    let task = Process()
    task.launchPath = "/usr/bin/open"
    task.arguments = ["-a", "Simulator"]

    try? task.run()
}

// MARK: - Platform-aware boot dispatcher

/// Single entry point the Boot button uses. Reads the currently-selected
/// device from DeviceManager and dispatches by platform.
///
/// Behaviour:
///   • iOS — boots the picked simulator. If it's already booted, simctl's
///     no-op error is swallowed and we just bring Simulator.app to front.
///   • Android — boots the picked AVD via `emulator -avd <name>`. If the
///     AVD is already running or the selection is a physical device, we
///     skip the boot step (there's nothing to do).
///   • Web — never called; the UI hides the Boot button on web.
///
/// Returns nothing — failures are logged. Discovery state and selection
/// live on DeviceManager.shared.
func bootDeviceForActivePlatform() {
    let platform = WorkspaceManager.shared.activePlatform
    guard let device = DeviceManager.shared.selectedDevice(for: platform) else {
        print("⚠️ Boot: no device selected for \(platform.displayName).")
        return
    }

    switch platform {
    case .ios:
        if device.isRunning {
            // Already booted — just focus the Simulator window so the
            // user sees something happen.
            print("ℹ️ iOS: \(device.displayName) is already booted. Bringing Simulator to front.")
            openSimulatorApp()
        } else {
            bootIOSSimulator(udid: device.id)
        }

    case .android:
        if device.isPhysical {
            print("ℹ️ Android: physical device '\(device.displayName)' is already connected. Nothing to boot.")
            return
        }
        if device.isRunning {
            print("ℹ️ Android: AVD '\(device.displayName)' is already running.")
            return
        }
        AndroidTools.bootEmulator(named: device.id)
        if let app = WorkspaceManager.shared.currentApp,
           !app.androidPackage.isEmpty {
            // emulator -avd is a long-running process; we don't block on
            // it. Defer the app-launch via adb to give the emulator time
            // to register. If it's still not ready, the launch is a noop
            // and the user starts the app manually — better than crashing.
            DispatchQueue.global().asyncAfter(deadline: .now() + 8) {
                AndroidTools.launchApp(packageName: app.androidPackage)
            }
        }

    case .web:
        break
    }
}

/// Runs maestro on the given ordered YAML list. Each YAML is symlinked into
/// `/tmp/aiqa-staging/` with its original name. A `config.yaml` is written
/// alongside so maestro's `executionOrder.flowsOrder` runs them sequentially
/// in the requested order (maestro's directory scan is non-deterministic
/// by default, so filename prefixes alone are not enough). Only the custom
/// report opens.
func runAutomationRunner(
    orderedYAMLs: [URL],
    projectName: String,
    appType: String,
    onComplete: @escaping () -> Void
) {
    let staging = URL(fileURLWithPath: "/tmp/aiqa-staging", isDirectory: true)
    try? FileManager.default.removeItem(at: staging)
    do {
        try FileManager.default.createDirectory(at: staging, withIntermediateDirectories: true)
    } catch {
        print("❌ Failed to create staging folder: \(error)")
        onComplete()
        return
    }

    var flowStems: [String] = []
    for (index, url) in orderedYAMLs.enumerated() {
        let fileName = url.lastPathComponent
        let destination = staging.appendingPathComponent(fileName)

        // Layer 2: the FIRST flow in execution order gets the
        // permission-dismissal block spliced in. Permission grants
        // are app-scoped (tcc.db / appops) so once dismissed they
        // stay dismissed for the rest of the suite — no need to
        // inject anywhere else. Subsequent flows are symlinked as-is
        // for zero-overhead. See discussion in chat history for why
        // per-suite beats per-flow / per-module.
        if index == 0 {
            do {
                let original = try String(contentsOf: url, encoding: .utf8)
                let spliced = injectPermissionDismissal(into: original)
                try spliced.write(to: destination, atomically: true, encoding: .utf8)
                flowStems.append(url.deletingPathExtension().lastPathComponent)
                print("📎 Layer 2: injected first-launch permission block into \(fileName)")
            } catch {
                print("⚠️ Failed to splice permission block into \(fileName): \(error). Falling back to symlink.")
                try? FileManager.default.createSymbolicLink(at: destination, withDestinationURL: url)
                flowStems.append(url.deletingPathExtension().lastPathComponent)
            }
        } else {
            do {
                try FileManager.default.createSymbolicLink(at: destination, withDestinationURL: url)
                flowStems.append(url.deletingPathExtension().lastPathComponent)
            } catch {
                print("❌ Failed to symlink \(fileName): \(error)")
            }
        }
    }

    // Maestro respects `executionOrder.flowsOrder` in config.yaml.
    // Without this, maestro intentionally runs flows in a random order.
    let configYAML = buildMaestroConfigYAML(flowStems: flowStems)
    let configURL = staging.appendingPathComponent("config.yaml")
    do {
        try configYAML.write(to: configURL, atomically: true, encoding: .utf8)
        print("📄 Wrote maestro execution order config:\n\(configYAML)")
    } catch {
        print("❌ Failed to write config.yaml: \(error)")
    }

    guard let buildFolder = WorkspaceManager.shared.currentBuildURL() else {
        print("❌ Run: no active workspace context")
        try? FileManager.default.removeItem(at: staging)
        onComplete()
        return
    }
    try? FileManager.default.createDirectory(at: buildFolder, withIntermediateDirectories: true)
    let maestroReportURL = buildFolder.appendingPathComponent("report.html")

    // Build `--env KEY=VALUE` flags from the vault. Each value is wrapped
    // in single quotes (and any literal single quote escaped) so that the
    // shell doesn't interpret special characters in passwords / strings.
    //
    // Why command-line flags and not `task.environment`: maestro's launcher
    // script (`~/.maestro/bin/maestro`) routes through the JVM and does NOT
    // propagate arbitrary process-environment variables to the substitution
    // engine — when a ${VAR} reference can't be resolved, maestro writes
    // the literal string "undefined" into the field. The documented and
    // reliable mechanism is `--env KEY=VALUE` on the maestro CLI.
    let vaultEnv = VaultManager.shared.flattenedEnvDict()
    var envFlags = ""
    if !vaultEnv.isEmpty {
        for key in vaultEnv.keys.sorted() {
            let value = vaultEnv[key] ?? ""
            envFlags += " --env \(key)=\(shellSingleQuote(value))"
        }
        let injectedKeys = vaultEnv.keys.sorted().joined(separator: ", ")
        print("📦 Vault: passing --env for \(vaultEnv.count) var(s): \(injectedKeys)")
    }

    let task = Process()
    task.launchPath = "/bin/zsh"
    let command = """
    \(NSHomeDirectory())/.maestro/bin/maestro test\(envFlags) --format html-detailed --output \(maestroReportURL.path) \(staging.path)
    """
    task.arguments = ["-c", command]

    let pipe = Pipe()
    task.standardOutput = pipe
    task.standardError = pipe

    do {
        try task.run()

        pipe.fileHandleForReading.readabilityHandler = { handle in
            let data = handle.availableData
            if let output = String(data: data, encoding: .utf8), !output.isEmpty {
                print(output)
            }
        }

        task.terminationHandler = { process in
            print("Maestro finished with code: \(process.terminationStatus)")

            DispatchQueue.main.async {
                if let customReportURL = generateAndSaveCustomReport(
                    from: maestroReportURL,
                    projectName: projectName,
                    appType: appType
                ) {
                    NSWorkspace.shared.open(customReportURL)
                }
                try? FileManager.default.removeItem(at: staging)
                onComplete()
            }
        }
    } catch {
        print("❌ Failed to launch maestro: \(error)")
        try? FileManager.default.removeItem(at: staging)
        onComplete()
    }
}

/// POSIX-safe single-quoting for arbitrary shell values. Wraps the input
/// in `'...'` and escapes any literal single quote as `'\''` (close, escape,
/// reopen). Handles every printable character including `$`, `"`, `\`, and
/// spaces — so `Agent@123`, `P@$$w0rd`, and `it's` all survive zsh -c.
private func shellSingleQuote(_ s: String) -> String {
    return "'" + s.replacingOccurrences(of: "'", with: "'\\''") + "'"
}

/// Builds a maestro `config.yaml` body that pins flow execution order.
/// Flows are identified by their file stem (filename without `.yaml`).
/// `continueOnFailure: true` is used so a failed flow doesn't abort the
/// remainder of the run — important because users typically want to see
/// all results, not stop at the first failure.
private func buildMaestroConfigYAML(flowStems: [String]) -> String {
    var lines: [String] = []
    lines.append("executionOrder:")
    lines.append("  continueOnFailure: true")
    lines.append("  flowsOrder:")
    for stem in flowStems {
        lines.append("    - \(stem)")
    }
    return lines.joined(separator: "\n") + "\n"
}

// MARK: - Layer 2 permission-dismissal injection

/// YAML snippet spliced into the very first flow of every suite run.
/// Uses `repeat / while: visible:` so 1, 2, or N consecutive permission
/// dialogs are all handled by the same block — the loop exits the moment
/// no matching button is on screen.
///
/// The text regex covers the common iOS and Android Allow / OK / Continue
/// labels. We deliberately do NOT include "Don't Allow" / "Deny" — we
/// want to grant, not refuse. ATT's "Allow Tracking" matches the bare
/// "Allow" alternation.
///
/// When no dialog is present (re-run, or Layer 1 pre-grant covered
/// everything), the `visible:` predicate fails fast and the block exits
/// in ~1s. Safe no-op.
private let permissionDismissalBlock: String = """
# AIQA: auto-injected first-launch permission dismissal (Layer 2).
- launchApp
- waitForAnimationToEnd
- repeat:
    while:
      visible:
        text: "Allow|Allow While Using App|Allow Once|While Using the App|Only this time|Allow only this time|OK|Continue"
    commands:
      - tapOn:
          text: "Allow|Allow While Using App|Allow Once|While Using the App|Only this time|Allow only this time|OK|Continue"
          optional: true
- waitForAnimationToEnd
"""

/// Splices the permission-dismissal block into the YAML body, right after
/// the `---` separator that divides the appId header from the steps.
///
/// We don't try to be clever about whether the original already has a
/// `- launchApp` — duplicate launches on iOS / Android just bring the
/// existing process to front (or relaunch) without resetting privacy
/// state, so back-to-back launchApps are harmless.
///
/// If the YAML is missing a `---` separator (shouldn't happen with our
/// generator but defensive), the block is prepended to the whole thing
/// and maestro will fail-fast with a parse error — surfacing a real
/// problem instead of silently dropping the dismissal.
private func injectPermissionDismissal(into yaml: String) -> String {
    guard let separator = yaml.range(of: "---") else {
        return permissionDismissalBlock + "\n" + yaml
    }
    // Find the newline that ends the `---` line; insert right after it.
    let afterSeparator: String.Index
    if let newline = yaml.range(of: "\n", range: separator.upperBound..<yaml.endIndex) {
        afterSeparator = newline.upperBound
    } else {
        // `---` is the very last thing in the file (no body). Inject at end.
        afterSeparator = yaml.endIndex
    }
    var result = yaml
    result.insert(contentsOf: permissionDismissalBlock + "\n", at: afterSeparator)
    return result
}
