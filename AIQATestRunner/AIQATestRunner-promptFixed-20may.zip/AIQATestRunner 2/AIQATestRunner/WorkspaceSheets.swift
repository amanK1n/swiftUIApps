//
//  WorkspaceSheets.swift
//  AIQATestRunner
//
//  Two SwiftUI sheets that drive the workspace lifecycle:
//
//    • WorkspacePickerView — first-launch (and "Switch Workspace…") flow.
//      Lets the user point AIQA at any folder on disk, with a one-click
//      shortcut to migrate the legacy ~/Desktop/e2e/ layout into the new
//      multi-app shape.
//
//    • NewAppSheetView — collects an app name + optional platform-specific
//      identifiers, then calls WorkspaceManager.createApp(...) which
//      scaffolds the full {ios,android,web}/{flows,build}/ tree.
//
//  Both sheets are presented from ContentView via simple @State booleans;
//  this file just owns the UI + the small bits of validation each one
//  needs.
//

import SwiftUI
import AppKit

// MARK: - Workspace Picker

struct WorkspacePickerView: View {
    @ObservedObject private var workspace = WorkspaceManager.shared
    @Environment(\.dismiss) private var dismiss

    /// Called after a workspace has been chosen so the parent can decide
    /// whether to immediately follow up with the "create your first app"
    /// sheet (when the chosen workspace has zero apps).
    var onComplete: () -> Void

    @State private var errorMessage: String = ""

    private var hasLegacyFolder: Bool {
        WorkspaceManager.legacyE2EFolderHasContent()
    }

    var body: some View {
        VStack(spacing: 10) {
            Spacer().frame(height: 10)
            VStack(alignment: .center, spacing: 16) {
                HStack {
                    Spacer()
                    if workspace.workspaceURL != nil {
                        Button("X") { dismiss() }
                            .keyboardShortcut(.cancelAction)
                    }
                }
                Image("cta_logo")
                    .resizable()
                    .scaledToFit()
                    .frame(width: 70, height: 70)
                
                
                
                VStack(alignment: .center, spacing: 2) {
                    Text("Cognitive Test Automation")
                        .font(.custom("Roboto-Bold", size: 25))
                    Text("This app helps you authorise and execute your tests with ease.")
                        .font(.custom("Roboto-Regular", size: 12))
                        .foregroundStyle(.secondary)
                }
                
                
                Divider()
                
                if hasLegacyFolder {
                    migrationCard
                    Text("Or pick a different folder")
                        .font(.custom("Roboto-Bold", size: 12))
                        .foregroundStyle(.secondary)
                }
                
                VStack(alignment: .center, spacing: 10) {
                    
                    //                Text("CTA will store everything inside the chosen folder using the new `<app>/<platform>/` layout.")
                    //                    .font(.custom("Roboto-Regular", size: 11))
                    //                    .foregroundStyle(.secondary)
                    Button {
                        chooseFolder()
                    } label: {
                        Text("Choose or Create Workspace")
                            .font(.custom("Inter-Bold", size: 16))
                            .fontWeight(.semibold)
                            .foregroundColor(.white)
                            .padding(.horizontal, 20)
                            .padding(.vertical, 8)
                            .background(Color.red)
                            .clipShape(Capsule())
                    }.buttonStyle(.plain)
                }
                
                if !errorMessage.isEmpty {
                    Text(errorMessage)
                        .font(.custom("Inter-Regular", size: 11))
                        .foregroundStyle(.red)
                }
                
                Spacer(minLength: 0)
                
                
            }
            .padding(24)
            .frame(width: 420, height: 300).background(
                RoundedRectangle(cornerRadius: 10)
                    .fill(Color(NSColor.white))
            )
            .overlay(
                RoundedRectangle(cornerRadius: 10)
                    .stroke(Color.blue.opacity(0.18), lineWidth: 1)
            )
            
            HStack(alignment: .center, spacing: 140) {
                VStack(alignment: .center, spacing: 10) {
                    Image("secure_icon")
                        .resizable()
                        .scaledToFit()
                        .frame(width: 50, height: 50)
                    Text("Secure & Reliable")
                        .font(.custom("Inter-Regular", size: 14))
                        .foregroundStyle(.primary)
                    
                    Text("Enterprise-grade security for your tests and data.")
                        .font(.custom("Inter-Regular", size: 12))
                        .foregroundStyle(.secondary)
                    
                    
                }
                VStack(alignment: .center, spacing: 10) {
                    Image("fast_exec_icon")
                        .resizable()
                        .scaledToFit()
                        .frame(width: 50, height: 50)
                    Text("Faster Execution")
                        .font(.custom("Inter-Regular", size: 14))
                        .foregroundStyle(.primary)
                    
                    Text("Run tests in parallel and save valuable time.")
                        .font(.custom("Inter-Regular", size: 12))
                        .foregroundStyle(.secondary)
                    
                    
                }
                VStack(alignment: .center, spacing: 10) {
                    Image("detail_icon")
                        .resizable()
                        .scaledToFit()
                        .frame(width: 50, height: 50)
                    Text("Detailed Insights")
                        .font(.custom("Inter-Regular", size: 14))
                        .foregroundStyle(.primary)
                    
                    Text("Get comprehensive reports and actionable insights.")
                        .font(.custom("Inter-Regular", size: 12))
                        .foregroundStyle(.secondary)
                    
                    
                }
                
            }.padding(.top, 40)
            
        }.frame(minWidth: 1440, minHeight: 750)
         .background(
            RoundedRectangle(cornerRadius: 10)
                .fill(Color("BGColor"))
        )
    }

    /// Legacy migration card — only shown when ~/Desktop/e2e/ has real
    /// content the user probably wants to keep.
    private var migrationCard: some View {
        VStack(alignment: .leading, spacing: 10) {
            HStack(spacing: 6) {
                Image(systemName: "arrow.triangle.merge")
                    .foregroundStyle(Color.accentColor)
                Text("Existing data found at ~/Desktop/e2e/")
                    .font(.custom("Roboto-Bold", size: 13))
            }
            Text("We can migrate your existing flows into the new layout as the “Default / iOS” context. Your YAMLs, vault, and build folder move into `Default/ios/`. This is a one-time operation.")
                .font(.custom("Roboto-Regular", size: 11))
                .foregroundStyle(.secondary)
                .fixedSize(horizontal: false, vertical: true)

            HStack(spacing: 10) {
                Button {
                    workspace.migrateLegacyE2EFolder()
                    dismiss()
                    onComplete()
                } label: {
                    Label("Migrate ~/Desktop/e2e/", systemImage: "arrow.right.circle.fill")
                }
                .buttonStyle(.borderedProminent)
            }
        }
        .padding(14)
        .background(
            RoundedRectangle(cornerRadius: 10)
                .fill(Color.accentColor.opacity(0.06))
        )
        .overlay(
            RoundedRectangle(cornerRadius: 10)
                .stroke(Color.accentColor.opacity(0.4), lineWidth: 1)
        )
    }

    private func chooseFolder() {
        let panel = NSOpenPanel()
        panel.canChooseDirectories = true
        panel.canChooseFiles = false
        panel.allowsMultipleSelection = false
        panel.canCreateDirectories = true
        panel.title = "Choose CTA Workspace Folder"
        panel.prompt = "Select"
        if panel.runModal() == .OK, let url = panel.url {
            workspace.selectWorkspace(url)
            dismiss()
            onComplete()
        }
    }
}

// MARK: - New App Sheet

struct NewAppSheetView: View {
    @ObservedObject private var workspace = WorkspaceManager.shared
    @Environment(\.dismiss) private var dismiss

    var onComplete: () -> Void

    @State private var name: String = ""
    @State private var iosBundleId: String = ""
    @State private var androidPackage: String = ""
    @State private var webURL: String = ""
    @State private var errorMessage: String = ""

    private var nameIsValid: Bool {
        let trimmed = name.trimmingCharacters(in: .whitespacesAndNewlines)
        guard !trimmed.isEmpty else { return false }
        if trimmed.contains("/") || trimmed.contains("\\") { return false }
        return !workspace.manifest.apps.contains {
            $0.name.caseInsensitiveCompare(trimmed) == .orderedSame
        }
    }

    var body: some View {
        VStack(alignment: .center, spacing: 14) {
            
                
                VStack(alignment: .center, spacing: 2) {
                    Text("Add a new app to this workspace")
                        .font(.custom("Inter-Bold", size: 25))
                        .foregroundStyle(.primary)
                    Text("We'll scaffold iOS, Android, and Web folders for you. Identifiers are optional — fill in just the platforms you'll test.")
                        .font(.custom("Inter-Regular", size: 12))
                        .foregroundStyle(.secondary)
                }
            

            Divider()

            VStack(alignment: .center, spacing: 10) {
                labeledField(
                    label: "App Name",
                    placeholder: "PaymentApp",
                    binding: $name,
                    required: true
                )

                labeledField(
                    label: Platform.ios.appIdFieldLabel,
                    placeholder: Platform.ios.appIdPlaceholder,
                    binding: $iosBundleId
                )

                labeledField(
                    label: Platform.android.appIdFieldLabel,
                    placeholder: Platform.android.appIdPlaceholder,
                    binding: $androidPackage
                )

                labeledField(
                    label: Platform.web.appIdFieldLabel,
                    placeholder: Platform.web.appIdPlaceholder,
                    binding: $webURL
                )
            }.frame(width: 400)

            if !errorMessage.isEmpty {
                Text(errorMessage)
                    .font(.custom("Inter-Regular", size: 11))
                    .foregroundStyle(.red)
            }

           Spacer(minLength: 0)

            HStack {
                
                Button("Cancel") {
                    if !workspace.needsFirstAppCreation {
                        dismiss()
                    }
                }
                .keyboardShortcut(.cancelAction)
                .disabled(workspace.needsFirstAppCreation)
                .font(.custom("Inter-Bold", size: 16))
                .fontWeight(.semibold)
                .foregroundColor(.black)
                .padding(.horizontal, 28)
                .padding(.vertical, 6)
                .background(Color.white)
                .clipShape(Capsule())
                .buttonStyle(.plain)
                .help(workspace.needsFirstAppCreation
                      ? "You must create at least one app before continuing."
                      : "")
                .overlay(
                    RoundedRectangle(cornerRadius: 15)
                        .stroke(Color.black, lineWidth: 1)
                )

                Button("Create") { createApp() }
                    .keyboardShortcut(.defaultAction)
                    .disabled(!nameIsValid)
                    .font(.custom("Inter-Bold", size: 16))
                    .fontWeight(.semibold)
                    .foregroundColor(.white)
                    .padding(.horizontal, 28)
                    .padding(.vertical, 6)
                    .background(Color.red)
                    .clipShape(Capsule())
                    .buttonStyle(.plain)
            }
        }
        .padding(24)
        .frame(width: 720)
        .interactiveDismissDisabled(workspace.needsFirstAppCreation)
    }

    private func labeledField(
        label: String,
        placeholder: String,
        binding: Binding<String>,
        required: Bool = false
    ) -> some View {
        VStack(alignment: .leading, spacing: 4) {
            HStack(spacing: 4) {
                Text(label)
                    .font(.custom("Inter-Bold", size: 11))
                    .foregroundStyle(.primary)
                if required {
                    Text("*").foregroundStyle(.red)
                }
            }
            TextField(placeholder, text: binding)
                .font(.custom("Inter-Regular", size: 12))
                .textFieldStyle(.plain)
                .padding(.horizontal, 12)
                .padding(.vertical, 8)
                .background(Color(.textBackgroundColor))
                .cornerRadius(6)
                .overlay(
                    RoundedRectangle(cornerRadius: 6)
                        .stroke(Color.gray.opacity(0.4), lineWidth: 1)
                )
                .frame(width: 250)
                .tint(.red)
        }
    }

    private func createApp() {
        errorMessage = ""
        let created = workspace.createApp(
            name: name,
            iosBundleId: iosBundleId,
            androidPackage: androidPackage,
            webURL: webURL
        )
        guard created != nil else {
            errorMessage = "Couldn't create app. Name must be unique and free of slashes."
            return
        }
        dismiss()
        onComplete()
    }
}
