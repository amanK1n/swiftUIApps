//
//  MultiFlowSuiteGenerator.swift
//  AIQATestRunner
//
//  Created by Sayed on 14/05/26.
//
//  Generates multiple Maestro YAML test flows (one per scenario) from
//  app screenshots. The AI returns a JSON array of test cases whose
//  `steps` field is written in the proprietary DSL. The user reviews
//  and edits each DSL block in horizontally scrolling preview cards,
//  then transpiles all of them to YAML at once.
//

import Foundation
import AppKit
import SwiftUI

// MARK: - Editable Multi-Flow Case Model

struct EditableMultiFlowCase: Identifiable {
    let id = UUID()
    var title: String
    var steps: String
    var expectedResult: String
    var type: String
}

// MARK: - Multi-Flow Suite Pipeline (extension on TestStepsGenerator)

extension TestStepsGenerator {

    // Entry point — routes to the right backend based on generationMode.
    func generateMultiFlowSuite() async {
        guard !screenshots.isEmpty else {
            await setMultiFlowError("Upload at least one screenshot before generating a suite.")
            return
        }
        let trimmedFeature = featureName.trimmingCharacters(in: .whitespacesAndNewlines)
        guard !trimmedFeature.isEmpty else {
            await setMultiFlowError("Enter the feature name before generating a suite.")
            return
        }

        await MainActor.run {
            self.multiFlowError = ""
            self.multiFlowStatus = "Generating multi-flow suite..."
            self.multiFlowCases = []
            self.multiFlowSavedCount = 0
            self.isLoading = true
        }

        let prompt = buildMultiFlowPrompt()
        let responseText: String?

        if generationMode == .online {
            responseText = await callGeminiForMultiFlow(prompt: prompt)
        } else {
            responseText = await callOllamaForMultiFlow(prompt: prompt)
        }

        await MainActor.run { self.isLoading = false }

        guard let text = responseText else {
            await setMultiFlowError("AI did not return a response. See Xcode console for details.")
            return
        }

        let cases = parseMultiFlowJSON(text)
        guard !cases.isEmpty else {
            await setMultiFlowError("Could not parse any test cases from the AI response. Check console for raw output.")
            return
        }

        await MainActor.run {
            self.multiFlowCases = cases
            self.multiFlowStatus = "Generated \(cases.count) test-cases\(cases.count == 1 ? "" : "s"). Review the DSL. Enter AppID then tap 'Generate YAML for Suite'."
        }
    }

    // MARK: Transpile all DSL cards → YAML files in the active flows/ folder

    func generateYAMLForMultiFlowSuite() {
        guard !multiFlowCases.isEmpty else {
            multiFlowError = "No multi-flow cases to save. Generate the suite first."
            return
        }
        let trimmedAppId = appId.trimmingCharacters(in: .whitespacesAndNewlines)
        guard !trimmedAppId.isEmpty else {
            multiFlowError = "Enter the App ID before generating YAML."
            return
        }
        guard let folder = WorkspaceManager.shared.currentFlowsURL() else {
            multiFlowError = "No active app + platform — pick one before generating YAML."
            return
        }

        multiFlowError = ""
        multiFlowStatus = "Transpiling DSL to YAML..."

        do {
            try FileManager.default.createDirectory(at: folder, withIntermediateDirectories: true)
        } catch {
            multiFlowError = "Failed to create folder \(folder.path): \(error.localizedDescription)"
            return
        }

        let featureSlug = slugify(featureName, maxLength: 30)
        var savedCount = 0
        var failedTitles: [String] = []

        for (index, testCase) in multiFlowCases.enumerated() {
            do {
                let yaml = try generateMaestroYAML(
                    flowDescription: testCase.steps,
                    appId: trimmedAppId
                )
                let serial = String(format: "%03d", index + 1)
                let typeSlug = slugify(testCase.type, maxLength: 12)
                let titleSlug = slugify(testCase.title, maxLength: 50)
                let filename = "TC_\(serial)_\(featureSlug)_\(typeSlug)_\(titleSlug).yaml"
                let fileURL = folder.appendingPathComponent(filename)
                try yaml.write(to: fileURL, atomically: true, encoding: .utf8)
                savedCount += 1
            } catch {
                failedTitles.append(testCase.title)
                print("❌ Failed to write YAML for '\(testCase.title)': \(error.localizedDescription)")
            }
        }

        multiFlowSavedCount = savedCount
        multiFlowSavedFolder = folder

        if savedCount > 0 {
            NotificationCenter.default.post(name: .aiqaE2EFolderDidChange, object: nil)
        }

        if failedTitles.isEmpty {
            multiFlowStatus = "Saved \(savedCount) YAML flow\(savedCount == 1 ? "" : "s") to \(folder.path)"
        } else {
            multiFlowStatus = "Saved \(savedCount) flow\(savedCount == 1 ? "" : "s"). Failed: \(failedTitles.joined(separator: ", "))"
        }
    }

    func openMultiFlowFolder() {
        if let folder = multiFlowSavedFolder {
            NSWorkspace.shared.open(folder)
        } else if let folder = WorkspaceManager.shared.currentFlowsURL() {
            NSWorkspace.shared.open(folder)
        }
    }

    /// Resets the multi-flow workflow so the user can start a fresh module
    /// without losing the surrounding project context.
    ///
    /// CLEARED — everything tied to "this module":
    ///   • Feature under test (TextField + binding)
    ///   • Screenshots (UI and underlying array)
    ///   • Generated DSL preview cards (and the EditableMultiFlowCase array)
    ///   • Status / error / saved-count / saved-folder
    ///
    /// PRESERVED — settings the user explicitly typed for the *project* and
    /// would have to re-enter for every module otherwise:
    ///   • Project Name, App Type, App ID
    ///   • Generation mode (Online / Offline) and platform
    ///   • The single-flow DSL→YAML workflow's state (different feature)
    func resetForNextModule() {
        featureName = ""
        screenshots.removeAll()
        multiFlowCases.removeAll()
        multiFlowStatus = ""
        multiFlowError = ""
        multiFlowSavedCount = 0
        multiFlowSavedFolder = nil
    }

    // MARK: - AI Backends

    private func callGeminiForMultiFlow(prompt: String) async -> String? {
        let apiKey = ""

        let imagesPayload: [[String: Any]] = screenshots.compactMap { item -> [[String: Any]]? in
            guard let base64 = imageToBase64(item.image) else { return nil }
            return [
                ["text": item.description.isEmpty ? "Analyze this screen." : "Screen description: \(item.description)"],
                ["inline_data": ["mime_type": "image/png", "data": base64]]
            ]
        }.flatMap { $0 }

        let body: [String: Any] = [
            "contents": [[
                "parts": [["text": prompt]] + imagesPayload
            ]]
        ]

        guard let url = URL(string: "https://generativelanguage.googleapis.com/v1beta/models/gemini-2.5-flash:generateContent?key=\(apiKey)"),
              let httpBody = try? JSONSerialization.data(withJSONObject: body) else {
            print("❌ Failed to build Gemini request.")
            return nil
        }

        var request = URLRequest(url: url)
        request.httpMethod = "POST"
        request.addValue("application/json", forHTTPHeaderField: "Content-Type")
        request.httpBody = httpBody

        let config = URLSessionConfiguration.default
        config.timeoutIntervalForRequest = 180
        config.timeoutIntervalForResource = 300

        do {
            let (data, response) = try await URLSession(configuration: config).data(for: request)
            if let http = response as? HTTPURLResponse, !(200...299).contains(http.statusCode) {
                print("❌ Gemini HTTP \(http.statusCode):", String(data: data, encoding: .utf8) ?? "")
                return nil
            }
            print("📦 Gemini multi-flow raw:", String(data: data, encoding: .utf8) ?? "nil")
            return parseGeminiResponse(data: data)
        } catch {
            print("❌ Gemini error:", error.localizedDescription)
            return nil
        }
    }

    private func callOllamaForMultiFlow(prompt: String) async -> String? {
        let imagesBase64: [String] = screenshots.compactMap { imageToBase64($0.image) }

        let requestBody: [String: Any] = [
            "model": "qwen2.5vl:7b",
            "prompt": prompt,
            "images": imagesBase64,
            "stream": false
        ]

        guard let url = URL(string: "http://127.0.0.1:11434/api/generate"),
              let httpBody = try? JSONSerialization.data(withJSONObject: requestBody) else {
            print("❌ Failed to build Ollama request.")
            return nil
        }

        var request = URLRequest(url: url)
        request.httpMethod = "POST"
        request.addValue("application/json", forHTTPHeaderField: "Content-Type")
        request.httpBody = httpBody
        request.timeoutInterval = 900

        let config = URLSessionConfiguration.default
        config.timeoutIntervalForRequest = 900
        config.timeoutIntervalForResource = 1200

        do {
            let (data, response) = try await URLSession(configuration: config).data(for: request)
            if let http = response as? HTTPURLResponse, !(200...299).contains(http.statusCode) {
                print("❌ Ollama HTTP \(http.statusCode):", String(data: data, encoding: .utf8) ?? "")
                return nil
            }
            print("📦 Ollama multi-flow raw:", String(data: data, encoding: .utf8) ?? "nil")
            guard let json = try JSONSerialization.jsonObject(with: data) as? [String: Any],
                  let text = json["response"] as? String else {
                print("❌ Failed to parse Ollama response shell.")
                return nil
            }
            return text
        } catch {
            print("❌ Ollama error:", error.localizedDescription)
            return nil
        }
    }

    // MARK: - Prompt

    private func buildMultiFlowPrompt() -> String {
        let descriptions = screenshots.enumerated().map { index, shot in
            "Screen \(index + 1): \(shot.description.isEmpty ? "No description provided" : shot.description)"
        }.joined(separator: "\n")

        // Module-scoped vault block. Empty string when the vault has nothing
        // for this module — in that case the prompt is byte-identical to the
        // pre-vault version, so behavior is unchanged.
        let moduleSlug = vaultSlug(featureName)
        let vaultBlock = VaultManager.shared.promptBlock(forModuleSlug: moduleSlug)
        
dump(vaultBlock)
        
        return """
        You are a mobile QA AI expert.
        Given the mobile app screenshots and a feature name, generate appropriate test cases.

        DECIDE THE NUMBER OF CASES based on feature complexity:
        - Simple features (e.g., logout) may need only 1 happy-path case.
        - Complex features (e.g., login, registration, checkout) may need many cases (positive, multiple negatives, edge).
        - Do NOT pad. Generate only meaningful, distinct test cases.

        For each test case, include exactly these fields:
        - title: short descriptive name. Do NOT include "positive"/"negative"/"edge" in the title.
        - steps: a sequence of DSL commands, one per line, joined with \\n
        - expectedResult: brief 1-line description of the expected outcome.
        - type: exactly one of "positive", "negative", "edge"

        DSL COMMAND REFERENCE for the `steps` field:
        - Tap <label>          → Tap a visible labeled element
        - Tap <label> <index>  → Tap when multiple elements share the same label (0-based index)
        - TapIcon <x%,y%>      → Tap an icon-only element with no readable label
        - Enter <value>        → Type into the currently focused input field
        - Scroll to <value>    → Scroll until that element is visible
        - runflow <label>      → Conditional tap: only if element is visible
        - Visible <text>       → Assert that the given text is visible (use for NEGATIVE / EDGE case error states)

        DSL RULES:
        0. Output ONLY the steps, one per line. No explanation, no markdown, no numbering, no scenario_id.
        1. For input fields: always Tap the field first, then Enter the value on the next line.
        2. If duplicate labels exist, append a 0-based index after the label. Example: Tap User Name 1, Tap Password 1
        3. Use TapIcon with screen-relative whole-number percentages for icon-only buttons. Example: TapIcon 92%, 8%
        4. NEGATIVE cases must test error states (invalid input, missing fields, wrong credentials) and assert the resulting error using `Visible <text>` on the last line.
        5. EDGE cases test boundaries (very long strings, special characters, max/min values, empty inputs) and similarly assert the boundary outcome using `Visible <text>`.
        6. Follow logical order: fill all fields before tapping submit/login/confirm.
        7. POSITIVE cases should NOT emit a final `Visible` assertion — they end after the successful action.
        8. Add a 'Tap OK' if user asks after assertions 
        9. Add index 1 if user asks for it. Example: Tap User Name 1, Tap Password 1
        
        \(vaultBlock)
        Feature under test: \(featureName)

        Screen Descriptions:
        \(descriptions)

        Return ONLY a JSON array. No markdown, no code fences, no commentary.
        [
          {
            "title": "",
            "steps": "Tap ...\\nEnter ...\\nVisible ...",
            "expectedResult": "",
            "type": "positive"
          }
        ]
        """
    }

    // MARK: - JSON parsing

    private func parseMultiFlowJSON(_ rawText: String) -> [EditableMultiFlowCase] {
        let cleaned = rawText
            .replacingOccurrences(of: "```json", with: "")
            .replacingOccurrences(of: "```", with: "")
            .trimmingCharacters(in: .whitespacesAndNewlines)

        guard let data = cleaned.data(using: .utf8) else { return [] }

        guard let decoded = try? JSONDecoder().decode([TestCase].self, from: data) else {
            print("❌ Multi-flow JSON decode failed. Raw:\n\(cleaned)")
            return []
        }

        return decoded.map {
            EditableMultiFlowCase(
                title: $0.title,
                steps: $0.steps,
                expectedResult: $0.expectedResult,
                type: $0.type.lowercased()
            )
        }
    }

    // MARK: - Helpers

    @MainActor
     func setMultiFlowError(_ message: String) {
        self.multiFlowError = message
        self.multiFlowStatus = ""
        self.isLoading = false
    }

    private func e2eDirectoryURL() -> URL {
        let home = FileManager.default.homeDirectoryForCurrentUser
        return home.appendingPathComponent("Desktop", isDirectory: true)
            .appendingPathComponent("e2e", isDirectory: true)
    }

    private func slugify(_ text: String, maxLength: Int = 50) -> String {
        let lowered = text.lowercased()
        let allowed = CharacterSet.alphanumerics
        var converted = ""
        for scalar in lowered.unicodeScalars {
            converted.append(allowed.contains(scalar) ? Character(scalar) : "_")
        }
        while converted.contains("__") {
            converted = converted.replacingOccurrences(of: "__", with: "_")
        }
        converted = converted.trimmingCharacters(in: CharacterSet(charactersIn: "_"))
        if converted.count > maxLength {
            converted = String(converted.prefix(maxLength))
                .trimmingCharacters(in: CharacterSet(charactersIn: "_"))
        }
        return converted.isEmpty ? "untitled" : converted
    }
}
