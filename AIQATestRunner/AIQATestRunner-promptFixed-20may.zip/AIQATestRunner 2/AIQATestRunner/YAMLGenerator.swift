//
//  YAMLGenerator.swift
//  AIQATestRunner
//
//  Created by Sayed on 24/04/26.
//

import AppKit
import Foundation
import UniformTypeIdentifiers



enum FlowGenerationError: LocalizedError {
    case invalidResponse
    case emptyResponse
    case userCancelledSave

    var errorDescription: String? {
        switch self {
        case .invalidResponse:
            return "Gemini returned an unexpected response. Please try again."
        case .emptyResponse:
            return "No Maestro YAML could be generated from the provided steps."
        case .userCancelledSave:
            return "The generated YAML was not saved."
        }
    }
}

func detectLoginPage(steps: [String]) -> [String] {
   var steps = steps

    let lowercasedSteps = steps.map { $0.lowercased() }

    let hasLogin = lowercasedSteps.contains { $0.contains("login") }
    let hasUsername = lowercasedSteps.contains {
        $0.contains("username") || $0.contains("user name")
    }
    let hasPassword = lowercasedSteps.contains { $0.contains("password") }

    // If any two conditions are true
    let matches = [hasLogin, hasUsername, hasPassword].filter { $0 }.count

    if matches >= 2 {
        steps.insert("Launch", at: 0)
    }
    return steps
}


func generateMaestroYAML(flowDescription: String, appId: String) throws -> String {
    // Run the DSL through two pre-transpile passes:
    //  1. Detect `[scenario_id: <module>.<case>]` markers, capture them so the
    //     associated `Visible "..."` line can be silently written back to the
    //     vault, then strip the markers from the step list.
    //  2. Normalize / split into individual step strings.
    let scenarioContext = extractScenarioContext(from: flowDescription)
    var steps = normalizedOfflineSteps(from: scenarioContext.cleanedFlow)

    guard !steps.isEmpty else {
        throw FlowGenerationError.emptyResponse
    }
    let isLoginPage = detectLoginPage(steps: steps)
    steps = isLoginPage
    var yamlSteps: [String] = []
    print(steps)

    for step in steps {
        yamlSteps.append(contentsOf: maestroCommands(for: step))
    }

    // Convert any DSL-style `${module.field}` placeholders we generated into
    // the flat `${MODULE_FIELD}` form maestro's --env-file substitution wants.
    // The dotted form is what the AI emits + what shows up in the DSL preview;
    // the flat form is only ever seen inside the on-disk YAML.
    let finalYAMLBody = rewriteVaultPlaceholders(in: yamlSteps.joined(separator: "\n"))

    // After transpiling, push any user-confirmed assertion text back into the
    // vault. Silent — VaultManager logs a single line per write.
    scenarioContext.writeBackToVault()

    return """
    appId: \(appId)
    ---
    \(finalYAMLBody)
    """
}

/// Rewrites every `${<module>.<field>}` reference found anywhere in the YAML
/// body into the flat env-var form (`${<MODULE>_<FIELD>}`). Idempotent — flat
/// references are left untouched.
private func rewriteVaultPlaceholders(in body: String) -> String {
    guard let regex = try? NSRegularExpression(
        pattern: #"\$\{([A-Za-z][A-Za-z0-9_]*)\.([A-Za-z][A-Za-z0-9_]*)\}"#,
        options: []
    ) else {
        return body
    }
    let ns = body as NSString
    let matches = regex.matches(in: body, range: NSRange(location: 0, length: ns.length))
    guard !matches.isEmpty else { return body }

    var result = body
    for match in matches.reversed() {
        let module = ns.substring(with: match.range(at: 1))
        let field  = ns.substring(with: match.range(at: 2))
        let replacement = "${\(envVarName(module: module, field: field))}"
        if let r = Range(match.range, in: result) {
            result.replaceSubrange(r, with: replacement)
        }
    }
    return result
}

// MARK: - Scenario-id extraction + write-back

/// Captures any `[scenario_id: <module>.<case>]` markers so the Visible line
/// that follows can be saved back to the vault under that scenario.
private struct ScenarioContext {
    let cleanedFlow: String
    let pendingAssertions: [(module: String, scenarioId: String, value: String)]

    func writeBackToVault() {
        for entry in pendingAssertions {
            // Skip the AI's `<TODO>` placeholder — user hasn't filled it in yet.
            let trimmed = entry.value.trimmingCharacters(in: .whitespacesAndNewlines)
            if trimmed.isEmpty || trimmed.lowercased().contains("<todo") { continue }
            VaultManager.shared.upsertAssertion(
                module: entry.module,
                scenarioId: entry.scenarioId,
                assertion: VaultAssertion(type: .toast, value: trimmed)
            )
        }
    }
}

private func extractScenarioContext(from flow: String) -> ScenarioContext {
    let lines = flow.replacingOccurrences(of: "\r\n", with: "\n").components(separatedBy: "\n")
    var cleaned: [String] = []
    var pending: [(String, String, String)] = []
    var currentScenario: (module: String, id: String)?

    // Matches `[scenario_id: <module>.<case>]` (with optional whitespace,
    // optional surrounding brackets removed). Module + case are slug-form.
    let scenarioRegex = try? NSRegularExpression(
        pattern: #"\[\s*scenario_id\s*:\s*([A-Za-z0-9_]+)\.([A-Za-z0-9_]+)\s*\]"#,
        options: [.caseInsensitive]
    )
    let visibleRegex = try? NSRegularExpression(
        pattern: #"^\s*visible\s+(.*)$"#,
        options: [.caseInsensitive]
    )

    for rawLine in lines {
        let line = rawLine.trimmingCharacters(in: .whitespacesAndNewlines)
        let ns = line as NSString

        // 1. Pull scenario_id markers out of the stream entirely; they're
        // metadata for vault write-back, not steps.
        if let regex = scenarioRegex,
           let m = regex.firstMatch(in: line, range: NSRange(location: 0, length: ns.length)) {
            let module = ns.substring(with: m.range(at: 1)).lowercased()
            let scenarioId = ns.substring(with: m.range(at: 2)).lowercased()
            currentScenario = (module, scenarioId)

            // Some flows put the scenario_id on a dedicated line; others
            // prefix the first DSL line with it. Strip just the marker and
            // keep whatever else was on the line.
            let stripped = regex.stringByReplacingMatches(
                in: line, range: NSRange(location: 0, length: ns.length), withTemplate: ""
            ).trimmingCharacters(in: .whitespacesAndNewlines)

            if !stripped.isEmpty {
                cleaned.append(stripped)
                // If the same line was a Visible step, capture it for write-back.
                if let vregex = visibleRegex,
                   let vm = vregex.firstMatch(in: stripped,
                                              range: NSRange(location: 0, length: (stripped as NSString).length)) {
                    let value = (stripped as NSString).substring(with: vm.range(at: 1))
                    if let scen = currentScenario {
                        pending.append((scen.module, scen.id, unquote(value)))
                    }
                }
            }
            continue
        }

        // 2. Capture Visible values when we have an active scenario_id context.
        if let scen = currentScenario,
           let vregex = visibleRegex,
           let vm = vregex.firstMatch(in: line, range: NSRange(location: 0, length: ns.length)) {
            let value = ns.substring(with: vm.range(at: 1))
            pending.append((scen.module, scen.id, unquote(value)))
        }

        if !line.isEmpty {
            cleaned.append(line)
        }
    }

    return ScenarioContext(
        cleanedFlow: cleaned.joined(separator: "\n"),
        pendingAssertions: pending.map {
            (module: $0.0, scenarioId: $0.1, value: $0.2)
        }
    )
}

private func unquote(_ s: String) -> String {
    var t = s.trimmingCharacters(in: .whitespacesAndNewlines)
    if (t.hasPrefix("\"") && t.hasSuffix("\"")) || (t.hasPrefix("'") && t.hasSuffix("'")),
       t.count >= 2 {
        t = String(t.dropFirst().dropLast())
    }
    return t
}

@MainActor
func saveGeneratedYAMLToUserSelectedLocation(_ yaml: String, suggestedFileName: String) throws -> URL {
    let savePanel = NSSavePanel()
    savePanel.title = "Save YAML"
    savePanel.message = "Choose a file name and folder for the generated Maestro flow."
    savePanel.nameFieldLabel = "Flow Name:"
    savePanel.nameFieldStringValue = "\(suggestedFileName).yaml"
    savePanel.canCreateDirectories = true
    savePanel.isExtensionHidden = false

    if let yamlType = UTType(filenameExtension: "yaml"),
       let ymlType = UTType(filenameExtension: "yml") {
        savePanel.allowedContentTypes = [yamlType, ymlType]
    }

    savePanel.directoryURL = defaultSaveDirectory()

    guard savePanel.runModal() == .OK, let saveURL = savePanel.url else {
        throw FlowGenerationError.userCancelledSave
    }

    try yaml.write(to: saveURL, atomically: true, encoding: .utf8)
    return saveURL
}

private func defaultSaveDirectory() -> URL {
    let fileManager = FileManager.default
    let desktopE2EPath = (NSHomeDirectory() as NSString).appendingPathComponent("Desktop/e2e")

    if fileManager.fileExists(atPath: desktopE2EPath) {
        return URL(fileURLWithPath: desktopE2EPath, isDirectory: true)
    }

    return fileManager.homeDirectoryForCurrentUser.appendingPathComponent("Desktop", isDirectory: true)
}

private func extractMaestroYAML(from text: String) -> String {
    let trimmed = text.trimmingCharacters(in: .whitespacesAndNewlines)

    if trimmed.hasPrefix("```"), let fencedYAML = extractFirstCodeBlock(from: trimmed) {
        return fencedYAML.trimmingCharacters(in: .whitespacesAndNewlines)
    }

    if let appIdRange = trimmed.range(of: "appId:") {
        return String(trimmed[appIdRange.lowerBound...]).trimmingCharacters(in: .whitespacesAndNewlines)
    }

    return trimmed
}

private func extractFirstCodeBlock(from text: String) -> String? {
    guard let openingFenceRange = text.range(of: "```") else {
        return nil
    }

    let afterOpeningFence = text[openingFenceRange.upperBound...]
    guard let closingFenceRange = afterOpeningFence.range(of: "```") else {
        return nil
    }

    var codeBlock = String(afterOpeningFence[..<closingFenceRange.lowerBound])
        .trimmingCharacters(in: .whitespacesAndNewlines)

    if codeBlock.lowercased().hasPrefix("yaml") {
        codeBlock = String(codeBlock.dropFirst(4)).trimmingCharacters(in: .whitespacesAndNewlines)
    }

    return codeBlock
}

private func normalizedOfflineSteps(from description: String) -> [String] {
    let rawLines = description
        .replacingOccurrences(of: "\r\n", with: "\n")
        .components(separatedBy: .newlines)
        .flatMap { line -> [String] in
            let trimmed = line.trimmingCharacters(in: .whitespacesAndNewlines)
            guard !trimmed.isEmpty else { return [] }
            if trimmed.contains("\n") { return [trimmed] }
            // Split on ". " (period followed by whitespace) only, so that
            // dots inside `${module.field}` placeholders are preserved.
            // Splitting on a bare "." would shatter `${login.username}`
            // into `${login` and `username}`.
            return trimmed
                .components(separatedBy: ". ")
                .map { $0.trimmingCharacters(in: .whitespacesAndNewlines) }
                .filter { !$0.isEmpty }
        }

    return rawLines
        .map {
            $0.replacingOccurrences(
                of: #"^((\d+[\).\s-]*)|([-*]\s+))"#,
                with: "",
                options: .regularExpression
            )
        }
        .filter { !$0.isEmpty }
}

private func maestroCommands(for originalStep: String) -> [String] {
    let step = originalStep.trimmingCharacters(in: .whitespacesAndNewlines)
    let lowercased = step.lowercased()

    if lowercased.hasPrefix("tap below ") {
        let target = extractedQuotedText(from: step)
            ?? extractedText(afterKeyword: "tap below", in: step)
            ?? "Target"
        return [
            "- tapOn:",
            "    below:",
            "      text: \"\(escapeYAML(target))\""
        ]
    }

    if lowercased.hasPrefix("runflow ") {
        let target = extractedQuotedText(from: step)
            ?? extractedText(afterKeyword: "runflow", in: step)
            ?? "Expected text"
        return [
            "- runFlow:",
            "    when:",
            "      visible:",
            "        text: \"\(assertPattern(for: target))\"",
            "    commands:",
            "      - tapOn: \"\(assertPattern(for: target))\""
        ]
    }
    if lowercased.hasPrefix("visible ") {
        let target = extractedQuotedText(from: step)
            ?? extractedText(afterKeyword: "visible", in: step)
            ?? "Expected text"
        return [
            "- assertVisible:",
            "    text: \"\(assertPattern(for: target))\""
        ]
    }
    
    if lowercased.hasPrefix("tapicon ") {
        let value = extractedQuotedText(from: step)
            ?? extractedText(afterKeyword: "tapicon", in: step)
            ?? "Expected text"
        return [
            "- tapOn:",
            "    point: \"\(escapeYAML(value))\""
        ]
    }

    if lowercased.hasPrefix("enter ") {
        let value = extractedQuotedText(from: step)
            ?? extractedText(afterKeyword: "enter", in: step)
            ?? "Sample text"
        return [
            "- inputText: \"\(escapeYAML(value))\"",
            "- tapOn:",
            "    text: \"Done\"",
            "    optional: true"
        ]
    }
    
    if lowercased.hasPrefix("enter") {
        let value = extractedQuotedText(from: step)
            ?? extractedText(afterKeyword: "enter", in: step)
            ?? "Sample text"
        return [
            "- inputText: \"\"",
            "- tapOn:",
            "    text: \"Done\"",
            "    optional: true"
        ]
    }

    if lowercased.hasPrefix("tap ") {
        var target = extractedQuotedText(from: step)
            ?? extractedText(afterKeyword: "tap", in: step)
            ?? "Target"
        
        var indexLine: String? = nil
        
        let components = target.split(separator: " ")
        
        if let last = components.last, let index = Int(last) {
            target = components.dropLast().joined(separator: " ")
            indexLine = "    index: \(index)"
        }
        
        var yaml = [
            "- tapOn:",
            "    text: \"\(escapeYAML(target))\""
        ]
        
        if let indexLine {
            yaml.append(indexLine)
        }
        
        return yaml
    }

    if lowercased.contains("launch") || lowercased.contains("open app") {
        return ["- launchApp",
                "- waitForAnimationToEnd"
        ]
    }
    

    if lowercased.contains("wait") {
        
        // Extract full raw target string (may include timeout at end)
        if var target = extractedQuotedText(from: step) ??
            extractedText(afterKeywords: ["for", "until"], in: step) {
            
            var timeout = 20000 // default
            
            // Check if last word is a number (timeout)
            let parts = target.split(separator: " ")
            if let last = parts.last, let value = Int(last) {
                timeout = value
                target = parts.dropLast().joined(separator: " ")
            }
            
            return [
                "- extendedWaitUntil:",
                "    visible: \"\(assertPattern(for: target))\"",
                "    timeout: \(timeout)"
            ]
        }
        
        return ["- waitForAnimationToEnd"]
    }

    if lowercased.contains("assert") || lowercased.contains("verify") || lowercased.contains("ensure") || lowercased.contains("confirm") {
        let target = extractedQuotedText(from: step)
            ?? extractedText(afterKeywords: ["verify", "ensure", "confirm", "assert"], in: step)
            ?? "Expected text"
        return [
            "- assertVisible:",
            "    text: \"\(assertPattern(for: target))\""
        ]
    }

    if lowercased.contains("scroll") {
        let target = extractedQuotedText(from: step)
            ?? extractedText(afterKeywords: ["to", "until"], in: step)
            ?? "Target element"
        return [
            "- scrollUntilVisible:",
            "    element: \"\(escapeYAML(target))\"",
            "    direction: DOWN"
        ]
    }

    if lowercased.contains("swipe left") {
        return ["- swipe:", "    direction: LEFT"]
    }

    if lowercased.contains("swipe right") {
        return ["- swipe:", "    direction: RIGHT"]
    }

    if lowercased.contains("swipe up") {
        return ["- swipe:", "    direction: UP"]
    }

    if lowercased.contains("swipe down") {
        return ["- swipe:", "    direction: DOWN"]
    }

    if lowercased.contains("back") {
        return ["- back"]
    }

    if lowercased.contains("enter ") || lowercased.contains("type ") || lowercased.contains("input ") {
        let value = extractedQuotedText(from: step)
            ?? extractedText(afterKeywords: ["enter", "type", "input"], in: step)
            ?? "Sample text"
        return [
            "- inputText: \"\(escapeYAML(value))\"",
            "- tapOn: \"Done\""
        ]
    }

    if lowercased.contains("tap") || lowercased.contains("click") || lowercased.contains("select") || lowercased.contains("press") {
        let target = extractedQuotedText(from: step)
            ?? extractedText(afterKeywords: ["tap", "click", "select", "press"], in: step)
            ?? "Target"
        return [
            "- tapOn:",
            "    text: \"\(escapeYAML(target))\""
        ]
    }

    return [
        "- assertVisible:",
        "    text: \"\(assertPattern(for: step))\""
    ]
}

private func extractedQuotedText(from text: String) -> String? {
    guard let range = text.range(of: "\"([^\"]+)\"", options: .regularExpression) else {
        return nil
    }
    return String(text[range]).trimmingCharacters(in: CharacterSet(charactersIn: "\""))
}

private func extractedText(afterKeywords keywords: [String], in text: String) -> String? {
    let lowered = text.lowercased()
    for keyword in keywords {
        guard let range = lowered.range(of: keyword) else { continue }
        let extracted = text[range.upperBound...]
            .trimmingCharacters(in: .whitespacesAndNewlines)
            .trimmingCharacters(in: CharacterSet(charactersIn: ":,-"))
        if !extracted.isEmpty {
            return extracted
        }
    }
    return nil
}

private func extractedText(afterKeyword keyword: String, in text: String) -> String? {
    extractedText(afterKeywords: [keyword], in: text)
}

private func assertPattern(for value: String) -> String {
    let trimmed = value.trimmingCharacters(in: .whitespacesAndNewlines)
    if trimmed.hasPrefix(".*") || trimmed.hasSuffix(".*") {
        return escapeYAML(trimmed)
    }
    return ".*" + escapeYAML(trimmed) + ".*"
}

private func escapeYAML(_ value: String) -> String {
    value
        .trimmingCharacters(in: .whitespacesAndNewlines)
        .replacingOccurrences(of: "\"", with: "\\\"")
}
