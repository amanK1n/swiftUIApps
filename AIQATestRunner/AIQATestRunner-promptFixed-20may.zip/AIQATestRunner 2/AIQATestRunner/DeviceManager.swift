//
//  DeviceManager.swift
//  AIQATestRunner
//
//  Discovers available simulators (iOS) and emulators / connected devices
//  (Android), tracks the user's selection per platform, and persists the
//  choice across app launches.
//
//  The UI binds to this manager via @ObservedObject; the Boot helpers in
//  UItilityExplorer.swift read the currently-selected device when the user
//  clicks the Boot button.
//
//  Refresh policy:
//    • Auto-refresh runs whenever the active platform changes (called from
//      ContentView.onWorkspaceContextReady).
//    • The Device row has its own Refresh button for ad-hoc rescans when
//      the user creates a new simulator/AVD or plugs in a phone.
//

import Foundation
import AppKit
import Combine

// MARK: - Model

struct DeviceInfo: Identifiable, Hashable {
    /// Stable identifier — UDID on iOS, AVD name or adb serial on Android.
    /// Used as the persistence key and as the discriminator in the picker.
    let id: String

    let platform: Platform

    /// Human-readable label used in the picker. Includes status suffix
    /// — e.g. "iPhone 16 Pro · iOS 18.1 (Booted)".
    let displayName: String

    /// True for iOS sims that report state "Booted" and for Android AVDs
    /// whose name shows up in `adb devices`. For physical Android devices
    /// (which can't be booted by us) this is true while they're connected.
    let isRunning: Bool

    /// Android-only flag — true for a physical device attached over adb.
    /// Used to skip the boot step for these (they're already on) and to
    /// optionally render a different icon.
    let isPhysical: Bool

    /// Sort key for iOS runtime (e.g. "18.1") so iPhones can be ordered
    /// newest-first. Empty on Android.
    let runtimeSort: String

    /// Full UDID / AVD path shown in the hover tooltip so power users can
    /// copy the identifier without us cluttering the picker label.
    let tooltip: String
}

// MARK: - Manager

final class DeviceManager: ObservableObject {
    static let shared = DeviceManager()

    @Published private(set) var iosDevices: [DeviceInfo] = []
    @Published private(set) var androidDevices: [DeviceInfo] = []

    @Published var selectedIOSDeviceId: String? {
        didSet {
            UserDefaults.standard.set(selectedIOSDeviceId, forKey: iosSelectionKey)
        }
    }
    @Published var selectedAndroidDeviceId: String? {
        didSet {
            UserDefaults.standard.set(selectedAndroidDeviceId, forKey: androidSelectionKey)
        }
    }

    /// Set when discovery surfaces a real problem (e.g. Android SDK missing).
    /// The UI shows this verbatim in the picker / tooltip — keeps the user
    /// out of the dark about why nothing is listed.
    @Published private(set) var iosError: String?
    @Published private(set) var androidError: String?

    private let iosSelectionKey = "AIQALastIOSDeviceUDID"
    private let androidSelectionKey = "AIQALastAndroidDeviceId"

    private init() {
        self.selectedIOSDeviceId = UserDefaults.standard.string(forKey: iosSelectionKey)
        self.selectedAndroidDeviceId = UserDefaults.standard.string(forKey: androidSelectionKey)
    }

    // MARK: Refresh entry point

    /// Re-discovers devices for the given platform. Runs on a background
    /// queue (simctl + adb each take ~0.5–1s) and republishes results on
    /// the main thread. Web is a no-op.
    func refresh(for platform: Platform) {
        switch platform {
        case .ios:
            DispatchQueue.global(qos: .userInitiated).async { [weak self] in
                let result = Self.discoverIOSDevices()
                DispatchQueue.main.async {
                    self?.applyIOS(result)
                }
            }
        case .android:
            DispatchQueue.global(qos: .userInitiated).async { [weak self] in
                let result = Self.discoverAndroidDevices()
                DispatchQueue.main.async {
                    self?.applyAndroid(result)
                }
            }
        case .web:
            break
        }
    }

    /// Applies an iOS discovery result and reconciles the persisted selection.
    /// If the saved UDID is no longer present we silently drop it and pick
    /// the first available device — better than showing a stale name.
    private func applyIOS(_ result: DiscoveryResult) {
        self.iosDevices = result.devices
        self.iosError = result.error

        if let saved = selectedIOSDeviceId,
           result.devices.contains(where: { $0.id == saved }) {
            // Saved selection still valid — keep it.
        } else {
            self.selectedIOSDeviceId = result.devices.first?.id
        }
    }

    private func applyAndroid(_ result: DiscoveryResult) {
        self.androidDevices = result.devices
        self.androidError = result.error

        if let saved = selectedAndroidDeviceId,
           result.devices.contains(where: { $0.id == saved }) {
            // Saved selection still valid — keep it.
        } else {
            self.selectedAndroidDeviceId = result.devices.first?.id
        }
    }

    // MARK: Lookups used by the UI + boot helpers

    func devices(for platform: Platform) -> [DeviceInfo] {
        switch platform {
        case .ios:     return iosDevices
        case .android: return androidDevices
        case .web:     return []
        }
    }

    func error(for platform: Platform) -> String? {
        switch platform {
        case .ios:     return iosError
        case .android: return androidError
        case .web:     return nil
        }
    }

    func selectedDevice(for platform: Platform) -> DeviceInfo? {
        let id: String?
        switch platform {
        case .ios:     id = selectedIOSDeviceId
        case .android: id = selectedAndroidDeviceId
        case .web:     return nil
        }
        guard let id else { return nil }
        return devices(for: platform).first(where: { $0.id == id })
    }

    func select(_ device: DeviceInfo) {
        switch device.platform {
        case .ios:     selectedIOSDeviceId = device.id
        case .android: selectedAndroidDeviceId = device.id
        case .web:     break
        }
    }
}

// MARK: - Discovery — iOS

private struct DiscoveryResult {
    let devices: [DeviceInfo]
    let error: String?
}

extension DeviceManager {

    /// Reads `xcrun simctl list devices available -j`, walks the
    /// runtime-keyed dict, filters to phones and pads, and returns a
    /// flat list sorted by runtime desc then name.
    fileprivate static func discoverIOSDevices() -> DiscoveryResult {
        guard FileManager.default.fileExists(atPath: "/usr/bin/xcrun") else {
            return DiscoveryResult(devices: [], error: "Xcode command-line tools not found.")
        }

        let task = Process()
        task.launchPath = "/usr/bin/xcrun"
        task.arguments = ["simctl", "list", "devices", "available", "-j"]
        let pipe = Pipe()
        task.standardOutput = pipe
        task.standardError = Pipe()
        do {
            try task.run()
            task.waitUntilExit()
        } catch {
            return DiscoveryResult(devices: [], error: "Failed to run xcrun: \(error.localizedDescription)")
        }

        let data = pipe.fileHandleForReading.readDataToEndOfFile()
        guard
            let json = try? JSONSerialization.jsonObject(with: data) as? [String: Any],
            let runtimeMap = json["devices"] as? [String: [[String: Any]]]
        else {
            return DiscoveryResult(devices: [], error: "Couldn't parse simctl output.")
        }

        var devices: [DeviceInfo] = []
        for (runtimeKey, entries) in runtimeMap {
            let (runtimeLabel, runtimeSort) = Self.parseIOSRuntime(runtimeKey)
            for entry in entries {
                guard
                    let name = entry["name"] as? String,
                    let udid = entry["udid"] as? String,
                    let isAvailable = entry["isAvailable"] as? Bool, isAvailable
                else { continue }

                // Skip Watch / TV / Vision Pro — the app is mobile-app focused,
                // and showing all device classes would just clutter the picker.
                let lower = name.lowercased()
                guard lower.contains("iphone") || lower.contains("ipad") else { continue }

                let state = (entry["state"] as? String) ?? "Shutdown"
                let isBooted = (state == "Booted")
                let suffix = isBooted ? " (Booted)" : ""
                let display = "\(name) · \(runtimeLabel)\(suffix)"

                devices.append(DeviceInfo(
                    id: udid,
                    platform: .ios,
                    displayName: display,
                    isRunning: isBooted,
                    isPhysical: false,
                    runtimeSort: runtimeSort,
                    tooltip: "UDID: \(udid)"
                ))
            }
        }

        // Sort: runtime desc (newer iOS at top), then name asc.
        devices.sort { lhs, rhs in
            if lhs.runtimeSort != rhs.runtimeSort {
                return lhs.runtimeSort > rhs.runtimeSort
            }
            return lhs.displayName < rhs.displayName
        }

        if devices.isEmpty {
            return DiscoveryResult(devices: [], error: "No iOS simulators found. Add one in Xcode → Settings → Platforms.")
        }
        return DiscoveryResult(devices: devices, error: nil)
    }

    /// Parses simctl's runtime key into a human label + a string usable for
    /// descending sort.
    ///   "com.apple.CoreSimulator.SimRuntime.iOS-18-1"  → ("iOS 18.1", "18.1")
    ///   "com.apple.CoreSimulator.SimRuntime.iPadOS-17-5" → ("iPadOS 17.5", "17.5")
    /// We pad the sort key components so "9.0" sorts below "10.0":
    ///   "18.1" → "00018.00001" so string comparison is monotonic.
    private static func parseIOSRuntime(_ key: String) -> (label: String, sort: String) {
        let suffix = key.split(separator: ".").last.map(String.init) ?? key
        let parts = suffix.split(separator: "-")
        guard parts.count >= 2 else { return (suffix, "00000.00000") }

        let platformPart = String(parts[0])         // "iOS" / "iPadOS"
        let versionParts = parts.dropFirst().map(String.init)
        let label = "\(platformPart) \(versionParts.joined(separator: "."))"

        let paddedVersion = versionParts.map {
            String(format: "%05d", Int($0) ?? 0)
        }.joined(separator: ".")
        return (label, paddedVersion)
    }
}

// MARK: - Discovery — Android

extension DeviceManager {

    /// Combines `emulator -list-avds` with `adb devices -l`. AVDs that match
    /// a running emulator get a "(Running)" suffix; physical devices in
    /// `adb devices` that aren't AVDs get a "(Connected)" suffix and are
    /// flagged `isPhysical` so the boot helper knows there's nothing to do.
    fileprivate static func discoverAndroidDevices() -> DiscoveryResult {
        guard AndroidTools.sdkRootURL() != nil else {
            return DiscoveryResult(
                devices: [],
                error: "Android SDK not detected. Install Android Studio or set ANDROID_HOME."
            )
        }

        let avdNames = AndroidTools.listAVDs()
        let connectedSerials = AndroidTools.listRunningDevices()

        // Map each connected serial → its `avd name` (if it's an emulator)
        // or model (if it's a physical phone). We use the emulator command
        // running via adb to figure out which serial maps to which AVD.
        let connectedToAVD = mapConnectedToAVD(serials: connectedSerials)
        let runningAVDs = Set(connectedToAVD.values)

        var devices: [DeviceInfo] = []

        for avd in avdNames {
            let display = humanizeAVDName(avd)
            let isRunning = runningAVDs.contains(avd)
            let suffix = isRunning ? " (Running)" : ""
            devices.append(DeviceInfo(
                id: avd,
                platform: .android,
                displayName: "\(display)\(suffix)",
                isRunning: isRunning,
                isPhysical: false,
                runtimeSort: "",
                tooltip: "AVD: \(avd)"
            ))
        }

        // Physical devices: serials in adb that don't map to a known AVD.
        for serial in connectedSerials where connectedToAVD[serial] == nil {
            let model = adbDeviceModel(serial: serial) ?? "Connected device"
            devices.append(DeviceInfo(
                id: serial,
                platform: .android,
                displayName: "\(model) (Connected)",
                isRunning: true,
                isPhysical: true,
                runtimeSort: "",
                tooltip: "ADB serial: \(serial)"
            ))
        }

        devices.sort { lhs, rhs in
            // Physical (connected) phones first — they're ready to test on.
            if lhs.isPhysical != rhs.isPhysical {
                return lhs.isPhysical
            }
            return lhs.displayName < rhs.displayName
        }

        if devices.isEmpty {
            return DiscoveryResult(
                devices: [],
                error: "No AVDs configured. Create one in Android Studio → Device Manager."
            )
        }
        return DiscoveryResult(devices: devices, error: nil)
    }

    /// `Pixel_7_API_34` → `Pixel 7 API 34`.
    private static func humanizeAVDName(_ raw: String) -> String {
        raw.replacingOccurrences(of: "_", with: " ")
    }

    /// For each `emulator-<port>` serial, asks adb for its AVD name via
    /// `adb -s <serial> emu avd name`. Returns serial → AVD name. Physical
    /// devices aren't included in the result.
    private static func mapConnectedToAVD(serials: [String]) -> [String: String] {
        guard let adb = AndroidTools.adbBinaryURL() else { return [:] }
        var result: [String: String] = [:]
        for serial in serials where serial.hasPrefix("emulator-") {
            let task = Process()
            task.executableURL = adb
            task.arguments = ["-s", serial, "emu", "avd", "name"]
            let pipe = Pipe()
            task.standardOutput = pipe
            task.standardError = Pipe()
            do {
                try task.run()
                task.waitUntilExit()
            } catch {
                continue
            }
            let raw = String(data: pipe.fileHandleForReading.readDataToEndOfFile(),
                             encoding: .utf8) ?? ""
            // The first line is the AVD name, the second is "OK".
            let avd = raw
                .split(separator: "\n")
                .map { $0.trimmingCharacters(in: .whitespacesAndNewlines) }
                .first(where: { !$0.isEmpty && $0 != "OK" })
            if let avd { result[serial] = avd }
        }
        return result
    }

    /// Best-effort `ro.product.model` lookup so physical devices show
    /// something nicer than their serial.
    private static func adbDeviceModel(serial: String) -> String? {
        guard let adb = AndroidTools.adbBinaryURL() else { return nil }
        let task = Process()
        task.executableURL = adb
        task.arguments = ["-s", serial, "shell", "getprop", "ro.product.model"]
        let pipe = Pipe()
        task.standardOutput = pipe
        task.standardError = Pipe()
        do {
            try task.run()
            task.waitUntilExit()
        } catch {
            return nil
        }
        let raw = String(data: pipe.fileHandleForReading.readDataToEndOfFile(),
                         encoding: .utf8) ?? ""
        let trimmed = raw.trimmingCharacters(in: .whitespacesAndNewlines)
        return trimmed.isEmpty ? nil : trimmed
    }
}
