//
//  AndroidTools.swift
//  AIQATestRunner
//
//  Android counterparts to the iOS xcrun/simctl helpers in UItilityExplorer.
//
//  Everything keys off the standard Android SDK layout:
//    $ANDROID_HOME/emulator/emulator       — boots an AVD
//    $ANDROID_HOME/platform-tools/adb      — talks to running emulators/devices
//
//  ANDROID_HOME is read from the user's environment if set; otherwise we
//  fall back to the macOS default install at ~/Library/Android/sdk/, which
//  is where Android Studio puts it out of the box.
//

import Foundation
import AppKit

enum AndroidTools {

    // MARK: SDK location

    /// Best-effort resolution of the Android SDK root. Returns nil when we
    /// can't find anything — callers surface a clear error instead of
    /// failing silently with "command not found".
    static func sdkRootURL() -> URL? {
        if let env = ProcessInfo.processInfo.environment["ANDROID_HOME"], !env.isEmpty {
            let url = URL(fileURLWithPath: env, isDirectory: true)
            if FileManager.default.fileExists(atPath: url.path) { return url }
        }
        if let env = ProcessInfo.processInfo.environment["ANDROID_SDK_ROOT"], !env.isEmpty {
            let url = URL(fileURLWithPath: env, isDirectory: true)
            if FileManager.default.fileExists(atPath: url.path) { return url }
        }
        // Default location for Android Studio installs on macOS.
        let defaultURL = FileManager.default.homeDirectoryForCurrentUser
            .appendingPathComponent("Library/Android/sdk", isDirectory: true)
        if FileManager.default.fileExists(atPath: defaultURL.path) {
            return defaultURL
        }
        return nil
    }

    static func emulatorBinaryURL() -> URL? {
        sdkRootURL()?.appendingPathComponent("emulator/emulator")
    }

    static func adbBinaryURL() -> URL? {
        sdkRootURL()?.appendingPathComponent("platform-tools/adb")
    }

    // MARK: AVD listing

    /// Returns the names of every AVD configured on this machine, parsed
    /// from `emulator -list-avds`. Empty array when the binary is missing
    /// or no AVDs exist.
    static func listAVDs() -> [String] {
        guard let emulator = emulatorBinaryURL(),
              FileManager.default.isExecutableFile(atPath: emulator.path) else {
            return []
        }
        let task = Process()
        task.executableURL = emulator
        task.arguments = ["-list-avds"]
        let pipe = Pipe()
        task.standardOutput = pipe
        task.standardError = Pipe()   // swallow stderr — only AVD names matter
        do {
            try task.run()
            task.waitUntilExit()
        } catch {
            return []
        }
        let data = pipe.fileHandleForReading.readDataToEndOfFile()
        let text = String(data: data, encoding: .utf8) ?? ""
        return text
            .split(separator: "\n")
            .map { $0.trimmingCharacters(in: .whitespacesAndNewlines) }
            .filter { !$0.isEmpty }
    }

    /// Returns the serials of currently-attached/running devices and
    /// emulators (whatever `adb devices` reports as `device` state).
    static func listRunningDevices() -> [String] {
        guard let adb = adbBinaryURL(),
              FileManager.default.isExecutableFile(atPath: adb.path) else {
            return []
        }
        let task = Process()
        task.executableURL = adb
        task.arguments = ["devices"]
        let pipe = Pipe()
        task.standardOutput = pipe
        task.standardError = Pipe()
        do {
            try task.run()
            task.waitUntilExit()
        } catch {
            return []
        }
        let data = pipe.fileHandleForReading.readDataToEndOfFile()
        let text = String(data: data, encoding: .utf8) ?? ""
        return text
            .split(separator: "\n")
            .dropFirst()                 // header: "List of devices attached"
            .compactMap { line -> String? in
                let parts = line.split(whereSeparator: { $0.isWhitespace })
                guard parts.count >= 2, parts[1] == "device" else { return nil }
                return String(parts[0])
            }
    }

    // MARK: Boot

    /// Boots `avdName` in the background. The emulator binary is a
    /// long-running process — we deliberately don't `waitUntilExit`, we
    /// just kick it off and let the user see the window come up.
    /// Returns true when the launch succeeded (not when the device is
    /// fully booted — that takes ~30s).
    @discardableResult
    static func bootEmulator(named avdName: String) -> Bool {
        guard let emulator = emulatorBinaryURL() else {
            print("❌ Android: emulator binary not found — set ANDROID_HOME or install the Android SDK at ~/Library/Android/sdk/")
            return false
        }
        let task = Process()
        task.executableURL = emulator
        task.arguments = ["-avd", avdName]
        // Detach stdout/stderr so the emulator can keep running after we
        // hand control back to SwiftUI.
        task.standardOutput = FileHandle.nullDevice
        task.standardError = FileHandle.nullDevice
        do {
            try task.run()
            print("📱 Android: launching emulator '\(avdName)'")
            return true
        } catch {
            print("❌ Android: failed to launch emulator '\(avdName)': \(error.localizedDescription)")
            return false
        }
    }

    /// Launches the given package's MAIN/LAUNCHER activity via adb monkey —
    /// the simplest way to start an arbitrary app without knowing its
    /// fully-qualified activity name. Returns true on a non-zero monkey
    /// exit code only when adb itself is missing.
    @discardableResult
    static func launchApp(packageName: String) -> Bool {
        guard let adb = adbBinaryURL() else {
            print("❌ Android: adb not found")
            return false
        }
        let task = Process()
        task.executableURL = adb
        task.arguments = [
            "shell", "monkey",
            "-p", packageName,
            "-c", "android.intent.category.LAUNCHER",
            "1"
        ]
        task.standardOutput = Pipe()
        task.standardError = Pipe()
        do {
            try task.run()
            task.waitUntilExit()
            return true
        } catch {
            print("❌ Android: failed to launch '\(packageName)': \(error.localizedDescription)")
            return false
        }
    }

    // MARK: Boot & wait

    /// Boots the named AVD and blocks until adb sees it AND it reports
    /// `sys.boot_completed == 1`. Returns the resolved adb serial
    /// (`emulator-5554` etc.) so the caller can use it for `adb install`.
    ///
    /// Implementation notes:
    /// • `emulator -avd <name>` is detached and starts a long-running
    ///   process; we don't wait for it to exit.
    /// • We snapshot the existing serials before launching and then
    ///   poll for a NEW serial that wasn't there before. This is more
    ///   reliable than parsing emulator's own stdout.
    /// • Once the serial appears, we wait on `sys.boot_completed` —
    ///   the canonical Android signal that the framework is up.
    static func bootAndWaitReady(avdName: String, timeoutSeconds: Int = 240)
        -> (success: Bool, output: String, serial: String?)
    {
        guard let emulator = emulatorBinaryURL() else {
            return (false, "Emulator binary not found — set ANDROID_HOME or install the Android SDK.", nil)
        }

        // Snapshot existing emulators so we can spot the new one later.
        let beforeSerials = Set(listRunningDevices().filter { $0.hasPrefix("emulator-") })

        // Launch detached.
        let bootTask = Process()
        bootTask.executableURL = emulator
        bootTask.arguments = ["-avd", avdName]
        bootTask.standardOutput = FileHandle.nullDevice
        bootTask.standardError = FileHandle.nullDevice
        do {
            try bootTask.run()
        } catch {
            return (false, "Failed to launch emulator '\(avdName)': \(error.localizedDescription)", nil)
        }

        // Phase 1: poll adb until a new serial appears.
        let deadline = Date().addingTimeInterval(TimeInterval(timeoutSeconds))
        var serial: String? = nil
        while Date() < deadline {
            let now = Set(listRunningDevices().filter { $0.hasPrefix("emulator-") })
            let newOnes = now.subtracting(beforeSerials)
            if let first = newOnes.first {
                serial = first
                break
            }
            Thread.sleep(forTimeInterval: 1.5)
        }
        guard let resolvedSerial = serial else {
            return (false, "Emulator didn't register with adb within \(timeoutSeconds)s", nil)
        }

        // Phase 2: poll sys.boot_completed for THIS serial until it
        // returns "1". This is the Android-blessed readiness signal.
        guard let adb = adbBinaryURL() else {
            return (false, "adb not found", resolvedSerial)
        }
        while Date() < deadline {
            let task = Process()
            task.executableURL = adb
            task.arguments = ["-s", resolvedSerial, "shell", "getprop", "sys.boot_completed"]
            let pipe = Pipe()
            task.standardOutput = pipe
            task.standardError = Pipe()
            do {
                try task.run()
                task.waitUntilExit()
            } catch {
                Thread.sleep(forTimeInterval: 2)
                continue
            }
            let out = String(data: pipe.fileHandleForReading.readDataToEndOfFile(),
                             encoding: .utf8) ?? ""
            if out.trimmingCharacters(in: .whitespacesAndNewlines) == "1" {
                return (true, "", resolvedSerial)
            }
            Thread.sleep(forTimeInterval: 2)
        }
        return (false, "Emulator failed to finish booting within \(timeoutSeconds)s", resolvedSerial)
    }

    /// Resolves a running emulator's AVD name to its adb serial. Returns
    /// nil when the AVD isn't currently registered with adb (i.e. not
    /// running). Used by the install path when the user picks an
    /// already-running AVD from the device dropdown — DeviceInfo carries
    /// the AVD name as its id, but adb install needs the serial.
    static func serialForRunningAVD(_ avdName: String) -> String? {
        guard let adb = adbBinaryURL() else { return nil }
        let serials = listRunningDevices().filter { $0.hasPrefix("emulator-") }
        for serial in serials {
            let task = Process()
            task.executableURL = adb
            task.arguments = ["-s", serial, "emu", "avd", "name"]
            let pipe = Pipe()
            task.standardOutput = pipe
            task.standardError = Pipe()
            do {
                try task.run()
                task.waitUntilExit()
            } catch {
                continue
            }
            let raw = String(data: pipe.fileHandleForReading.readDataToEndOfFile(),
                             encoding: .utf8) ?? ""
            let name = raw
                .split(separator: "\n")
                .map { $0.trimmingCharacters(in: .whitespacesAndNewlines) }
                .first(where: { !$0.isEmpty && $0 != "OK" }) ?? ""
            if name == avdName { return serial }
        }
        return nil
    }

    // MARK: APK install

    /// Locates the latest `aapt2` (preferred) or `aapt` binary inside the
    /// SDK's `build-tools/<version>/`. We pick the highest version-string
    /// available so we don't depend on a specific SDK release.
    static func aaptBinaryURL() -> URL? {
        guard let sdk = sdkRootURL() else { return nil }
        let buildTools = sdk.appendingPathComponent("build-tools", isDirectory: true)
        guard let versions = try? FileManager.default.contentsOfDirectory(
            at: buildTools,
            includingPropertiesForKeys: nil,
            options: [.skipsHiddenFiles]
        ) else { return nil }

        // Sort descending so the newest build-tools version wins.
        let sorted = versions.sorted { $0.lastPathComponent > $1.lastPathComponent }
        for versionFolder in sorted {
            for name in ["aapt2", "aapt"] {
                let url = versionFolder.appendingPathComponent(name)
                if FileManager.default.isExecutableFile(atPath: url.path) {
                    return url
                }
            }
        }
        return nil
    }

    /// Parses `aapt dump badging <apk>` (works for both aapt and aapt2) and
    /// returns `(package, versionName, versionCode)`. Returns nil when aapt
    /// isn't installed — the build importer falls back to a "metadata
    /// unavailable" path so the user still gets to install the APK.
    static func apkBadging(at apk: URL) -> (package: String, versionName: String, versionCode: String)? {
        guard let aapt = aaptBinaryURL() else { return nil }
        let task = Process()
        task.executableURL = aapt
        task.arguments = ["dump", "badging", apk.path]
        let pipe = Pipe()
        task.standardOutput = pipe
        task.standardError = Pipe()
        do {
            try task.run()
            task.waitUntilExit()
        } catch {
            return nil
        }
        let raw = String(data: pipe.fileHandleForReading.readDataToEndOfFile(),
                         encoding: .utf8) ?? ""

        // We only need the first `package:` line. Format:
        //   package: name='com.foo.bar' versionCode='1' versionName='1.0' ...
        guard let packageLine = raw.split(separator: "\n").first(where: { $0.hasPrefix("package:") }) else {
            return nil
        }
        let pkg = extractAaptField(in: String(packageLine), key: "name")
        let versionName = extractAaptField(in: String(packageLine), key: "versionName")
        let versionCode = extractAaptField(in: String(packageLine), key: "versionCode")

        guard !pkg.isEmpty else { return nil }
        return (package: pkg, versionName: versionName, versionCode: versionCode)
    }

    /// Pulls the value out of an aapt-style key='value' field. Tolerant of
    /// missing keys (returns empty string).
    private static func extractAaptField(in line: String, key: String) -> String {
        let pattern = "\(key)='([^']*)'"
        guard let regex = try? NSRegularExpression(pattern: pattern),
              let match = regex.firstMatch(
                in: line,
                range: NSRange(line.startIndex..., in: line)
              ),
              match.numberOfRanges > 1,
              let range = Range(match.range(at: 1), in: line)
        else { return "" }
        return String(line[range])
    }

    /// Installs an APK onto the given device serial via `adb install -r`.
    /// `-r` keeps user data, matching the platform default for "reinstall"
    /// — clearing app state is a per-test concern handled by maestro's
    /// `clearState` step, not by us at install time.
    ///
    /// Returns the combined stdout+stderr so the caller can surface adb's
    /// error text (e.g. INSTALL_FAILED_VERSION_DOWNGRADE).
    static func installAPK(at apk: URL, onSerial serial: String) -> (success: Bool, output: String) {
        guard let adb = adbBinaryURL() else {
            return (false, "adb not found — set ANDROID_HOME or install Android Studio.")
        }
        let task = Process()
        task.executableURL = adb
        task.arguments = ["-s", serial, "install", "-r", apk.path]
        let pipe = Pipe()
        task.standardOutput = pipe
        task.standardError = pipe
        do {
            try task.run()
            task.waitUntilExit()
        } catch {
            return (false, "Failed to run adb: \(error.localizedDescription)")
        }
        let output = String(data: pipe.fileHandleForReading.readDataToEndOfFile(),
                            encoding: .utf8) ?? ""
        return (task.terminationStatus == 0, output)
    }

    // MARK: Pre-grant runtime permissions

    /// The platform-defined set of "dangerous" runtime permissions — the
    /// ones that trigger a system dialog on first use. Granted via
    /// `pm grant`; granting non-dangerous permissions throws so we filter
    /// strictly against this list.
    ///
    /// Sourced from Android's Manifest.permission docs across API levels:
    ///   • Tiramisu (33): POST_NOTIFICATIONS, READ_MEDIA_*
    ///   • S (31):        BLUETOOTH_*, NEARBY_WIFI_DEVICES
    ///   • Q  (29):       ACCESS_BACKGROUND_LOCATION, ACTIVITY_RECOGNITION
    ///   • everything else: pre-Q legacy dangerous perms.
    private static let dangerousPermissions: Set<String> = [
        // Calendar
        "android.permission.READ_CALENDAR",
        "android.permission.WRITE_CALENDAR",
        // Camera
        "android.permission.CAMERA",
        // Contacts
        "android.permission.READ_CONTACTS",
        "android.permission.WRITE_CONTACTS",
        "android.permission.GET_ACCOUNTS",
        // Location
        "android.permission.ACCESS_FINE_LOCATION",
        "android.permission.ACCESS_COARSE_LOCATION",
        "android.permission.ACCESS_BACKGROUND_LOCATION",
        // Microphone
        "android.permission.RECORD_AUDIO",
        // Phone
        "android.permission.READ_PHONE_STATE",
        "android.permission.READ_PHONE_NUMBERS",
        "android.permission.CALL_PHONE",
        "android.permission.ANSWER_PHONE_CALLS",
        "android.permission.READ_CALL_LOG",
        "android.permission.WRITE_CALL_LOG",
        "android.permission.ADD_VOICEMAIL",
        "android.permission.USE_SIP",
        "android.permission.PROCESS_OUTGOING_CALLS",
        // Sensors
        "android.permission.BODY_SENSORS",
        "android.permission.BODY_SENSORS_BACKGROUND",
        "android.permission.ACTIVITY_RECOGNITION",
        // SMS
        "android.permission.SEND_SMS",
        "android.permission.RECEIVE_SMS",
        "android.permission.READ_SMS",
        "android.permission.RECEIVE_WAP_PUSH",
        "android.permission.RECEIVE_MMS",
        // Storage (legacy, pre-Tiramisu)
        "android.permission.READ_EXTERNAL_STORAGE",
        "android.permission.WRITE_EXTERNAL_STORAGE",
        // Media (Tiramisu+)
        "android.permission.READ_MEDIA_IMAGES",
        "android.permission.READ_MEDIA_VIDEO",
        "android.permission.READ_MEDIA_AUDIO",
        "android.permission.READ_MEDIA_VISUAL_USER_SELECTED",
        // Notifications (Tiramisu+)
        "android.permission.POST_NOTIFICATIONS",
        // Nearby devices (S+)
        "android.permission.BLUETOOTH_SCAN",
        "android.permission.BLUETOOTH_CONNECT",
        "android.permission.BLUETOOTH_ADVERTISE",
        "android.permission.NEARBY_WIFI_DEVICES"
    ]

    /// Parses `aapt dump permissions <apk>` and returns the subset of
    /// declared permissions that match Android's dangerous-permission
    /// list. These are the only permissions `pm grant` will accept;
    /// normal permissions are auto-granted at install time anyway.
    ///
    /// Returns an empty array when aapt isn't available — caller treats
    /// that as "nothing to pre-grant" and proceeds.
    static func dangerousPermissionsDeclared(in apk: URL) -> [String] {
        guard let aapt = aaptBinaryURL() else { return [] }
        let task = Process()
        task.executableURL = aapt
        task.arguments = ["dump", "permissions", apk.path]
        let pipe = Pipe()
        task.standardOutput = pipe
        task.standardError = Pipe()
        do {
            try task.run()
            task.waitUntilExit()
        } catch {
            return []
        }
        let raw = String(data: pipe.fileHandleForReading.readDataToEndOfFile(),
                         encoding: .utf8) ?? ""

        // aapt output (one per line):
        //   uses-permission: name='android.permission.CAMERA'
        //   uses-permission: name='android.permission.INTERNET'
        var declared: [String] = []
        for line in raw.split(separator: "\n") {
            let trimmed = line.trimmingCharacters(in: .whitespacesAndNewlines)
            guard trimmed.hasPrefix("uses-permission") else { continue }
            // Extract the name='…' value.
            let pattern = "name='([^']*)'"
            guard let regex = try? NSRegularExpression(pattern: pattern),
                  let m = regex.firstMatch(
                    in: trimmed,
                    range: NSRange(trimmed.startIndex..., in: trimmed)
                  ),
                  m.numberOfRanges > 1,
                  let r = Range(m.range(at: 1), in: trimmed)
            else { continue }
            let perm = String(trimmed[r])
            if dangerousPermissions.contains(perm) {
                declared.append(perm)
            }
        }
        return declared
    }

    /// Grants the given runtime permissions to `package` on `serial` via
    /// `adb shell pm grant`. Each grant is best-effort — failures are
    /// logged to the returned string but the loop continues. This lets
    /// older devices that don't recognise a newer permission still get
    /// every other permission granted.
    ///
    /// Returns the number of grants attempted and the combined log so
    /// the caller can surface "granted N/M" to the console.
    static func grantPermissions(
        _ permissions: [String],
        package: String,
        serial: String
    ) -> (granted: Int, attempted: Int, log: String) {
        guard !permissions.isEmpty, !package.isEmpty else {
            return (0, 0, "")
        }
        guard let adb = adbBinaryURL() else {
            return (0, permissions.count, "adb not found — skipped pre-grant.")
        }

        var log = ""
        var granted = 0
        for perm in permissions {
            let task = Process()
            task.executableURL = adb
            task.arguments = ["-s", serial, "shell", "pm", "grant", package, perm]
            let pipe = Pipe()
            task.standardOutput = pipe
            task.standardError = pipe
            do {
                try task.run()
                task.waitUntilExit()
            } catch {
                log += "✗ \(perm): \(error.localizedDescription)\n"
                continue
            }
            let output = String(data: pipe.fileHandleForReading.readDataToEndOfFile(),
                                encoding: .utf8) ?? ""
            if task.terminationStatus == 0 {
                granted += 1
            } else {
                // Common case: permission isn't recognized by the device's
                // API level (newer perm on older OS). Not fatal.
                let trimmed = output.trimmingCharacters(in: .whitespacesAndNewlines)
                if !trimmed.isEmpty {
                    log += "✗ \(perm): \(trimmed)\n"
                }
            }
        }
        return (granted, permissions.count, log)
    }
}
