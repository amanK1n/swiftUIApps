//
//  BuildManager.swift
//  AIQATestRunner
//
//  Owns the "App Under Test" build artefact for the currently-active
//  (app, platform). One current build per context, stored inside the
//  workspace at:
//
//    <workspace>/<App>/<platform>/builds/
//        <name>.app/                  ← iOS unpacked bundle
//        <name>.apk                   ← Android single file
//        build.meta.json              ← parsed metadata + import timestamp
//
//  Responsibilities:
//    • Peek metadata from a dropped file (without committing to disk).
//    • Commit an import (validate → unpack/copy → write meta.json).
//    • Reconfigure when the workspace context changes (load existing
//      meta from disk so the card shows the right thing).
//    • Install dispatcher — iOS goes to IOSTools, Android to AndroidTools.
//
//  Like VaultManager, this manager is fed URLs from WorkspaceManager
//  rather than reaching back into the singleton — that avoids the
//  swift_once re-entrancy crash documented in WorkspaceManager.
//

import Foundation
import AppKit
import Combine

// MARK: - Models

struct BuildInfo: Codable, Hashable {
    /// User-facing filename — "MyApp.app" or "MyApp.apk". Useful when the
    /// internal storage path uses a different name.
    let filename: String

    /// Absolute path to the installable artefact. For iOS this is the
    /// `.app` directory; for Android the `.apk` file.
    let path: String

    let bundleId: String       // CFBundleIdentifier / package name
    let versionName: String    // CFBundleShortVersionString / versionName
    let versionCode: String    // CFBundleVersion / versionCode — empty if unknown
    let sizeBytes: Int64
    let importedAt: Date
    let platform: String       // raw value of Platform — "ios" / "android"

    var humanSize: String {
        ByteCountFormatter.string(fromByteCount: sizeBytes, countStyle: .file)
    }

    var humanImportedAt: String {
        let fmt = RelativeDateTimeFormatter()
        fmt.unitsStyle = .short
        return fmt.localizedString(for: importedAt, relativeTo: Date())
    }
}

/// Result returned by `peekMetadata(of:platform:)` — used by the UI to
/// decide whether to prompt the user about a bundle-id conflict before
/// committing the import.
struct BuildPeek {
    let source: URL                // the file the user dropped
    let metadata: BuildInfo        // synthesized — path field is the source, will be rewritten on commit
}

enum BuildImportError: LocalizedError {
    case noActiveContext
    case wrongFileType(expected: String)
    case ipaUnzipFailed(String)
    case missingMetadata(String)
    case copyFailed(String)
    case writeMetaFailed(String)
    case aabNotSupported

    var errorDescription: String? {
        switch self {
        case .noActiveContext:
            return "No active app / platform. Pick one before uploading a build."
        case .wrongFileType(let expected):
            return "This platform accepts \(expected). Different platforms have their own build slots."
        case .ipaUnzipFailed(let msg):
            return "Couldn't unzip the .ipa: \(msg)"
        case .missingMetadata(let msg):
            return "Couldn't read build metadata: \(msg)"
        case .copyFailed(let msg):
            return "Failed to copy the build into the workspace: \(msg)"
        case .writeMetaFailed(let msg):
            return "Failed to persist build metadata: \(msg)"
        case .aabNotSupported:
            return ".aab is not supported yet. Convert to APK with bundletool, or upload a universal APK."
        }
    }
}

// MARK: - Manager

final class BuildManager: ObservableObject {
    static let shared = BuildManager()

    /// The build currently sitting in `<context>/builds/`. Nil when no
    /// build has been uploaded yet for this (app, platform).
    @Published private(set) var current: BuildInfo?

    /// Most recent transient error from `import(...)` — UI surfaces it as
    /// a banner inside the card.
    @Published var lastImportError: String?

    /// `<context>/builds/` for the currently-active (app, platform).
    /// Nil before the workspace context is resolved.
    private var buildsURL: URL?

    private let metaFileName = "build.meta.json"

    private init() {}

    // MARK: Context lifecycle

    /// Re-points the manager at the new platform's `builds/` folder and
    /// loads any existing build metadata so the card renders the saved
    /// state. Called from WorkspaceManager whenever the (app, platform)
    /// context changes.
    func reconfigure(buildsURL: URL?) {
        self.buildsURL = buildsURL
        self.lastImportError = nil
        guard let url = buildsURL else {
            self.current = nil
            return
        }
        try? FileManager.default.createDirectory(at: url, withIntermediateDirectories: true)

        let metaURL = url.appendingPathComponent(metaFileName)
        guard let data = try? Data(contentsOf: metaURL),
              let decoded = try? JSONDecoder.iso8601.decode(BuildInfo.self, from: data) else {
            self.current = nil
            return
        }

        // Sanity-check the recorded path is still there. If the user
        // moved/deleted it manually, we surface "no build" rather than
        // showing stale metadata for a vanished artefact.
        if FileManager.default.fileExists(atPath: decoded.path) {
            self.current = decoded
        } else {
            self.current = nil
        }
    }

    // MARK: Peek (parse without committing)

    /// Validates the file type for the platform and parses its metadata
    /// without copying anything. The caller (UI) uses this to drive the
    /// replace-confirmation and bundle-id mismatch dialogs before the
    /// real import.
    ///
    /// For iOS the source can be either a `.app` bundle directory or an
    /// `.ipa` archive; for Android only `.apk`. `.aab` is rejected.
    func peekMetadata(of source: URL, platform: Platform) -> Result<BuildPeek, BuildImportError> {
        let ext = source.pathExtension.lowercased()

        switch platform {
        case .ios:
            guard ext == "app" || ext == "ipa" else {
                return .failure(.wrongFileType(expected: ".app or .ipa"))
            }
            return peekIOS(source: source, ext: ext)
        case .android:
            if ext == "aab" { return .failure(.aabNotSupported) }
            guard ext == "apk" else {
                return .failure(.wrongFileType(expected: ".apk"))
            }
            return peekAndroid(source: source)
        case .web:
            return .failure(.wrongFileType(expected: "(web builds aren't supported)"))
        }
    }

    private func peekIOS(source: URL, ext: String) -> Result<BuildPeek, BuildImportError> {
        // For an .app we read the plist in-place; for an .ipa we unzip to
        // a temp dir, read, and then immediately discard the temp dir.
        // Peek never writes to the workspace.
        let appURL: URL
        var tempCleanup: URL? = nil
        if ext == "app" {
            appURL = source
        } else {
            do {
                appURL = try IOSTools.unzipIPA(at: source)
                tempCleanup = appURL.deletingLastPathComponent().deletingLastPathComponent()
            } catch {
                return .failure(.ipaUnzipFailed(error.localizedDescription))
            }
        }
        defer {
            if let temp = tempCleanup {
                try? FileManager.default.removeItem(at: temp)
            }
        }

        guard let meta = IOSTools.bundleMetadata(forApp: appURL) else {
            return .failure(.missingMetadata("Info.plist missing CFBundleIdentifier"))
        }

        let info = BuildInfo(
            filename: source.lastPathComponent,
            path: source.path,             // peek only; commit will rewrite this
            bundleId: meta.bundleId,
            versionName: meta.versionShort.isEmpty ? "—" : meta.versionShort,
            versionCode: meta.bundleVersion,
            sizeBytes: directorySize(at: ext == "app" ? source : appURL),
            importedAt: Date(),
            platform: Platform.ios.rawValue
        )
        return .success(BuildPeek(source: source, metadata: info))
    }

    private func peekAndroid(source: URL) -> Result<BuildPeek, BuildImportError> {
        let badging = AndroidTools.apkBadging(at: source)
        let size = (try? FileManager.default.attributesOfItem(atPath: source.path)[.size] as? Int64) ?? 0

        // Fall back to a friendly placeholder bundle id when aapt is missing
        // rather than blocking the import — the user can still install via
        // adb, and they can fix the AppId field manually.
        let info = BuildInfo(
            filename: source.lastPathComponent,
            path: source.path,
            bundleId: badging?.package ?? "",
            versionName: badging?.versionName.isEmpty == false ? badging!.versionName : "—",
            versionCode: badging?.versionCode ?? "",
            sizeBytes: size,
            importedAt: Date(),
            platform: Platform.android.rawValue
        )
        return .success(BuildPeek(source: source, metadata: info))
    }

    // MARK: Commit (copy / unpack into workspace)

    /// Performs the real import — removes the previous build (if any),
    /// copies / unpacks the new one into `<context>/builds/`, writes
    /// `build.meta.json`, and publishes the new `current`.
    ///
    /// Caller is expected to have already shown the user any necessary
    /// confirmation dialogs (replace prompt, bundle-id mismatch).
    @discardableResult
    func commitImport(of source: URL, platform: Platform) -> Result<BuildInfo, BuildImportError> {
        guard let folder = buildsURL else {
            return .failure(.noActiveContext)
        }
        try? FileManager.default.createDirectory(at: folder, withIntermediateDirectories: true)

        // Always start from a clean slot — old build out, new build in.
        // `removePreviousBuild()` is best-effort; failures here aren't
        // fatal, the new copy will just sit next to leftovers.
        removePreviousBuild(in: folder)

        switch platform {
        case .ios:    return commitIOS(source: source, folder: folder)
        case .android: return commitAndroid(source: source, folder: folder)
        case .web:    return .failure(.wrongFileType(expected: "(web builds aren't supported)"))
        }
    }

    private func commitIOS(source: URL, folder: URL) -> Result<BuildInfo, BuildImportError> {
        let ext = source.pathExtension.lowercased()
        let appURL: URL
        var tempCleanup: URL? = nil

        if ext == "app" {
            appURL = source
        } else if ext == "ipa" {
            do {
                appURL = try IOSTools.unzipIPA(at: source)
                tempCleanup = appURL.deletingLastPathComponent().deletingLastPathComponent()
            } catch {
                return .failure(.ipaUnzipFailed(error.localizedDescription))
            }
        } else {
            return .failure(.wrongFileType(expected: ".app or .ipa"))
        }
        defer {
            if let temp = tempCleanup { try? FileManager.default.removeItem(at: temp) }
        }

        guard let meta = IOSTools.bundleMetadata(forApp: appURL) else {
            return .failure(.missingMetadata("Info.plist missing CFBundleIdentifier"))
        }

        let destinationName = appURL.lastPathComponent     // "MyApp.app"
        let destination = folder.appendingPathComponent(destinationName, isDirectory: true)
        do {
            // copyItem on a directory copies it recursively — perfect for .app.
            try FileManager.default.copyItem(at: appURL, to: destination)
        } catch {
            return .failure(.copyFailed(error.localizedDescription))
        }

        let info = BuildInfo(
            filename: destinationName,
            path: destination.path,
            bundleId: meta.bundleId,
            versionName: meta.versionShort.isEmpty ? "—" : meta.versionShort,
            versionCode: meta.bundleVersion,
            sizeBytes: directorySize(at: destination),
            importedAt: Date(),
            platform: Platform.ios.rawValue
        )
        return persistMeta(info, in: folder)
    }

    private func commitAndroid(source: URL, folder: URL) -> Result<BuildInfo, BuildImportError> {
        guard source.pathExtension.lowercased() == "apk" else {
            return .failure(.wrongFileType(expected: ".apk"))
        }

        let destinationName = source.lastPathComponent
        let destination = folder.appendingPathComponent(destinationName)
        do {
            try FileManager.default.copyItem(at: source, to: destination)
        } catch {
            return .failure(.copyFailed(error.localizedDescription))
        }

        // Try to parse the APK now that it's in place — but treat failure
        // as "metadata unknown, allow install anyway".
        let badging = AndroidTools.apkBadging(at: destination)
        let size = (try? FileManager.default.attributesOfItem(atPath: destination.path)[.size] as? Int64) ?? 0

        let info = BuildInfo(
            filename: destinationName,
            path: destination.path,
            bundleId: badging?.package ?? "",
            versionName: badging?.versionName.isEmpty == false ? badging!.versionName : "—",
            versionCode: badging?.versionCode ?? "",
            sizeBytes: size,
            importedAt: Date(),
            platform: Platform.android.rawValue
        )
        return persistMeta(info, in: folder)
    }

    /// Writes `build.meta.json` and republishes `current`.
    private func persistMeta(_ info: BuildInfo, in folder: URL) -> Result<BuildInfo, BuildImportError> {
        let metaURL = folder.appendingPathComponent(metaFileName)
        do {
            let data = try JSONEncoder.iso8601.encode(info)
            try data.write(to: metaURL, options: .atomic)
        } catch {
            return .failure(.writeMetaFailed(error.localizedDescription))
        }
        self.current = info
        self.lastImportError = nil
        return .success(info)
    }

    /// Removes the previously-stored build artefact and its meta. Safe to
    /// call when nothing is there — best-effort cleanup.
    private func removePreviousBuild(in folder: URL) {
        let contents = (try? FileManager.default.contentsOfDirectory(
            at: folder,
            includingPropertiesForKeys: nil,
            options: [.skipsHiddenFiles]
        )) ?? []
        for entry in contents {
            try? FileManager.default.removeItem(at: entry)
        }
    }

    // MARK: Remove

    /// Deletes the current build from disk and clears `current`. Used by
    /// the card's "Remove" button. No-op when there's nothing to delete.
    func removeCurrent() {
        guard let folder = buildsURL else { return }
        removePreviousBuild(in: folder)
        self.current = nil
        self.lastImportError = nil
    }

    // MARK: Install

    /// One-step "ensure device is up, then install build" pipeline used by
    /// the Build card's Install button.
    ///
    /// Stages reported via `onProgress` (always called on the main thread):
    ///   • `.booting(displayName)` — only when the device wasn't already
    ///     running. Skipped entirely for booted sims / running AVDs /
    ///     connected physical devices.
    ///   • `.installing(displayName)`
    ///
    /// The whole pipeline runs on a background queue so the SwiftUI view
    /// stays responsive (a cold AVD boot takes 30-60 seconds). The final
    /// `(success, output)` is also delivered on the main thread.
    ///
    /// AVD identifier handling: a stopped AVD's DeviceInfo.id is the AVD
    /// name, NOT an adb serial — adb install needs a serial. After boot
    /// we resolve the new serial out of `emulator -list-avds` + adb and
    /// use that for the install command. Physical Android devices use
    /// the serial directly. iOS UDIDs are stable across boot/shutdown
    /// transitions.
    func installCurrent(
        on device: DeviceInfo,
        onProgress: @escaping (InstallStage) -> Void,
        completion: @escaping (Bool, String) -> Void
    ) {
        guard let build = current else {
            completion(false, "No build to install.")
            return
        }
        let buildURL = URL(fileURLWithPath: build.path)
        let displayName = stripStatusSuffix(device.displayName)

        DispatchQueue.global(qos: .userInitiated).async {
            // Convenience to bounce closures back to the main actor.
            func main(_ block: @escaping () -> Void) {
                DispatchQueue.main.async(execute: block)
            }

            switch device.platform {
            case .ios:
                if !device.isRunning {
                    main { onProgress(.booting(displayName)) }
                    let result = IOSTools.bootAndWaitReady(udid: device.id)
                    if !result.success {
                        main { completion(false, "Boot failed. \(result.output.trimmingCharacters(in: .whitespacesAndNewlines))") }
                        return
                    }
                }
                main { onProgress(.installing(displayName)) }
                let result = IOSTools.installApp(at: buildURL, onUDID: device.id)

                // Layer 1: pre-grant every TCC privacy service so the
                // app's fresh-install dialogs (camera, photos, location,
                // mic, contacts, etc.) never appear. Notifications and
                // ATT are not covered by simctl — Layer 2 handles those.
                // Best-effort — install success isn't gated on this.
                if result.success && !build.bundleId.isEmpty {
                    let grant = IOSTools.grantAllPrivacy(udid: device.id, bundleId: build.bundleId)
                    if grant.success {
                        print("🔐 Pre-granted TCC privacy services for \(build.bundleId)")
                    } else {
                        let trimmed = grant.output.trimmingCharacters(in: .whitespacesAndNewlines)
                        print("⚠️ simctl privacy grant all failed (non-fatal): \(trimmed)")
                    }
                }

                main { completion(result.success, result.output.trimmingCharacters(in: .whitespacesAndNewlines)) }

            case .android:
                let serial: String
                if device.isPhysical {
                    // Physical device — id is already the adb serial.
                    serial = device.id
                } else if device.isRunning {
                    // AVD already running — id is the AVD name; resolve
                    // it to its adb serial by asking each emulator-NNNN
                    // for its avd name.
                    guard let s = AndroidTools.serialForRunningAVD(device.id) else {
                        main { completion(false, "Couldn't resolve serial for running AVD '\(device.id)'.") }
                        return
                    }
                    serial = s
                } else {
                    // AVD not running — boot it, wait for ready, capture
                    // the new serial that adb assigned.
                    main { onProgress(.booting(displayName)) }
                    let result = AndroidTools.bootAndWaitReady(avdName: device.id)
                    if !result.success {
                        main { completion(false, "Boot failed. \(result.output.trimmingCharacters(in: .whitespacesAndNewlines))") }
                        return
                    }
                    guard let s = result.serial else {
                        main { completion(false, "Boot succeeded but no adb serial was assigned.") }
                        return
                    }
                    serial = s
                }

                main { onProgress(.installing(displayName)) }
                let result = AndroidTools.installAPK(at: buildURL, onSerial: serial)

                // Layer 1: pre-grant every dangerous runtime permission
                // the APK declares. Mirrors the iOS simctl path — silently
                // accept every permission dialog before any test runs.
                // POST_NOTIFICATIONS is included; older OS versions ignore
                // permissions they don't know.
                if result.success && !build.bundleId.isEmpty {
                    let declared = AndroidTools.dangerousPermissionsDeclared(in: buildURL)
                    if !declared.isEmpty {
                        let outcome = AndroidTools.grantPermissions(
                            declared, package: build.bundleId, serial: serial
                        )
                        print("🔐 Pre-granted \(outcome.granted)/\(outcome.attempted) runtime permissions for \(build.bundleId)")
                        let trimmedLog = outcome.log.trimmingCharacters(in: .whitespacesAndNewlines)
                        if !trimmedLog.isEmpty {
                            print(trimmedLog)
                        }
                    }
                }

                main { completion(result.success, result.output.trimmingCharacters(in: .whitespacesAndNewlines)) }

            case .web:
                main { completion(false, "Web installs aren't supported.") }
            }
        }
    }

    /// Removes the trailing status suffix added by DeviceManager.
    private func stripStatusSuffix(_ display: String) -> String {
        display
            .replacingOccurrences(of: " (Booted)", with: "")
            .replacingOccurrences(of: " (Running)", with: "")
            .replacingOccurrences(of: " (Connected)", with: "")
    }
}

// MARK: - Install stage

/// Surfaces install progress to the UI. The SwiftUI view maps these to
/// button labels ("Booting iPhone 16 Pro…" / "Installing…") and to a
/// spinner overlay.
enum InstallStage {
    case booting(_ deviceDisplayName: String)
    case installing(_ deviceDisplayName: String)
}

// MARK: - Helpers

/// Recursively sums file sizes inside a directory. `.app` bundles can run
/// 100s of MBs; we report the on-disk footprint, not just the directory
/// entry size.
private func directorySize(at url: URL) -> Int64 {
    var total: Int64 = 0
    guard let enumerator = FileManager.default.enumerator(
        at: url,
        includingPropertiesForKeys: [.fileSizeKey, .isRegularFileKey],
        options: [.skipsHiddenFiles]
    ) else {
        // Single-file fallback (.apk).
        if let size = try? FileManager.default.attributesOfItem(atPath: url.path)[.size] as? Int64 {
            return size
        }
        return 0
    }
    for case let fileURL as URL in enumerator {
        if let values = try? fileURL.resourceValues(forKeys: [.fileSizeKey, .isRegularFileKey]),
           values.isRegularFile == true,
           let size = values.fileSize {
            total += Int64(size)
        }
    }
    return total
}

// MARK: - JSON helpers

private extension JSONEncoder {
    /// Encoder that uses ISO-8601 for `Date`, matching the meta.json on disk.
    static var iso8601: JSONEncoder {
        let enc = JSONEncoder()
        enc.dateEncodingStrategy = .iso8601
        enc.outputFormatting = [.prettyPrinted, .sortedKeys]
        return enc
    }
}

private extension JSONDecoder {
    static var iso8601: JSONDecoder {
        let dec = JSONDecoder()
        dec.dateDecodingStrategy = .iso8601
        return dec
    }
}
