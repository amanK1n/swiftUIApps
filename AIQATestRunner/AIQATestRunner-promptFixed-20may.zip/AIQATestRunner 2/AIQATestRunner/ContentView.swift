//
//  ContentView.swift
//  AIQATestRunner
//
//  Created by Sayed on 16/04/26.
//

import SwiftUI
enum FlowGenerationMode: String, CaseIterable, Identifiable {
    case online = "Online"
    case offline = "Offline"
    var id: String { rawValue }
}

extension View {
    func sectionCard(padding: CGFloat = 18, isComingSoon: Bool = false) -> some View {
        self
            .padding(padding)
            .frame(maxWidth: .infinity, alignment: .leading)
            .background(
                RoundedRectangle(cornerRadius: 14)
                    .fill(isComingSoon ? Color(red: 1.0, green: 0.75, blue: 0.4) : Color(NSColor.windowBackgroundColor))
            )
            .overlay(
                RoundedRectangle(cornerRadius: 14)
                    .stroke(Color.secondary.opacity(0.14), lineWidth: 1)
            )
    }
}

struct ContentView: View {
    @State private var generationMode: FlowGenerationMode = .offline
    @State private var geminiAPIKey: String
    @State private var appId = ""
    @State private var flowDescription = ""
    @State private var generatedYAML = ""
    @State private var statusMessage = ""
    @State private var errorMessage = ""
    @State private var savedFilePath = ""
    @State private var isGenerating = false
    
    @State private var featureName: String = ""
    @State private var isLoading = false
    @State private var screenshots: [ScreenshotItem] = []
    @State private var testSteps: [TestStep] = []
    @State private var folderURL: URL?
    @State var projectName: String = ""
    @State var appType: String = ""
    @State var multiFlowSavedCount: Int = 0

    @State private var availableModules: [ModuleInfo] = []
    @State private var selectedModules: Set<String> = []
    @State private var hasDoneInitialScan: Bool = false
    @State private var isRunningAutomation: Bool = false
    @State private var isShowingVault: Bool = false
    @State private var isShowingWorkspacePicker: Bool = false
    @State private var isShowingNewApp: Bool = false
    @State private var pendingPlatformSwitch: Platform? = nil
    @State private var pendingAppSwitch: String? = nil
    @Environment(\.scenePhase) private var scenePhase
    @StateObject private var folderWatcher = FolderWatcher()
    @ObservedObject private var workspace = WorkspaceManager.shared
    @ObservedObject private var deviceManager = DeviceManager.shared
    @State private var showModules = false
    @State private var selectedModule: String? = "Login"
    let modules = ["Login", "Add Money", "Send Money", "Bill Pay", "Deposit Cash", "Withdraw Cash", "Request Money", "Merchant Payment", "Top-up", "Recharge", "Logout"]
    init() {
        _geminiAPIKey = State(initialValue: ProcessInfo.processInfo.environment["GEMINI_API_KEY"] ?? "")
        loadFonts()
    }
    
    var body: some View {
        ZStack {
            Color("BGColor")
                .ignoresSafeArea()
//            Image("app_background") // add generated image to Assets
//                .resizable()
//                .aspectRatio(contentMode: .fill)
//                .ignoresSafeArea()
//                .opacity(0.95)
            
            
            ScrollView {
                VStack(alignment: .leading, spacing: 18) {
                    headerSection
                   // figmaConnectSection
                    if workspace.workspaceURL != nil {
                        workspaceContextBar
                       
                    }
                    testStepsCard.padding(.horizontal, 20)
                    actionSection.padding(.horizontal, 20).padding(.bottom, 20)
                }
                .padding(0)
                .frame(maxWidth: .infinity, alignment: .leading)
            }
        }
        .frame(minWidth: 900, minHeight: 740)
        .onAppear {
            // First-launch flow: no workspace saved → open the picker; the
            // picker itself decides whether the user gets a migration prompt.
            if workspace.needsWorkspacePicker {
                isShowingWorkspacePicker = true
            } else if workspace.needsFirstAppCreation {
                isShowingNewApp = true
            } else {
                onWorkspaceContextReady()
            }
        }
        .onChange(of: scenePhase) { phase in
            if phase == .active {
                refreshModules()
            }
        }
        .onReceive(NotificationCenter.default.publisher(for: .aiqaWorkspaceContextChanged)) { _ in
            onWorkspaceContextReady()
        }
        .onReceive(NotificationCenter.default.publisher(for: .aiqaE2EFolderDidChange)) { _ in
            refreshModules()
        }
        .sheet(isPresented: $isShowingVault) {
            TestDataVaultView()
        }
        .sheet(isPresented: $isShowingWorkspacePicker) {
            WorkspacePickerView(
                onComplete: {
                    isShowingWorkspacePicker = false
                    if workspace.needsFirstAppCreation {
                        isShowingNewApp = true
                    }
                }
            )
        }
        .sheet(isPresented: $isShowingNewApp) {
            NewAppSheetView(
                onComplete: { isShowingNewApp = false }
            )
        }
    }
    
    private var sampleFigmaUI: some View {

        HStack(spacing: 0) {

            // LEFT MODULE PANE
            if showModules {

                VStack(alignment: .leading, spacing: 12) {

                    Text("Modules")
                        .font(.headline)
                        .padding(.bottom, 8)

                    ForEach(modules, id: \.self) { module in

                        Button {

                            selectedModule = module

                        } label: {

                            HStack {

                                Image(systemName: "square.grid.2x2")

                                Text(module)
                                    .font(.headline)

                                Spacer()
                            }
                            .padding(10)
                            .background(
                                selectedModule == module
                                ? Color.orange.opacity(0.25)
                                : Color(NSColor.windowBackgroundColor)
                            )
                            .clipShape(
                                RoundedRectangle(cornerRadius: 10)
                            )
                        }
                        .buttonStyle(.plain)
                    }

                    Spacer()
                }
                .padding()
                .frame(width: 240)
                .background(.ultraThinMaterial)
                .transition(.move(edge: .leading))
            }
            if showModules {
                Divider()
            }

            // RIGHT PANE
            if showModules {

                VStack(alignment: .leading, spacing: 18) {

                    if let selectedModule {

                        Text(selectedModule)
                            .font(.title.bold())
                            .padding(.top, 8)

                        ScrollView(.horizontal, showsIndicators: true) {

                            HStack(spacing: 22) {

                                ForEach(1...5, id: \.self) { index in

                                    VStack(spacing: 12) {

                                        RoundedRectangle(cornerRadius: 22)
                                            .fill(Color.gray.opacity(0.20))
                                            .frame(width: 220, height: 460)
                                            .overlay {

                                                VStack(spacing: 16) {

                                                    Image(systemName: "iphone")

                                                        .font(.system(size: 54))

                                                    Text("Screen \(index)")
                                                        .font(.title3)
                                                }
                                                .foregroundStyle(.secondary)
                                            }

                                        Text("Screen \(index)")
                                            .font(.headline)
                                    }
                                }
                            }
                            .padding(.horizontal, 6)
                            .padding(.vertical, 8)
                        }
                    }

                    Spacer()
                }
                .padding(24)
                .frame(maxWidth: .infinity, maxHeight: .infinity)
            }
        }
        .frame(minHeight: showModules ? 560 : 0)
    }
    private var figmaConnectSection: some View {
        VStack(alignment: .center, spacing: 8) {
            HStack(spacing: 6) {
                Text("Enter Figma Link")
                    .font(.custom("Roboto-Bold", size: 13))
                    .foregroundStyle(.black)
                TextField("https://www.figma.com/design/xyz", text: $projectName)
                    .textFieldStyle(.roundedBorder)
                Text("Enter Access Token")
                    .font(.custom("Roboto-Bold", size: 13))
                    .foregroundStyle(.black)
                TextField("figd_xyz", text: $projectName)
                    .textFieldStyle(.roundedBorder)
                Button {
                    //isShowingVault = true
                    print("Fetch figma modules")
                    withAnimation(.easeInOut(duration: 0.25)) {
                                                showModules.toggle()
                                            }
                } label: {
                    Label("Fetch Modules", systemImage: "magnifyingglass")
                }.buttonStyle(.glass)
            }.tint(.orange)
            sampleFigmaUI
        }.sectionCard(isComingSoon: true)
    }
    
    private var headerSection: some View {
        HStack(alignment: .center, spacing: 8) {
            
            
            ZStack {
//                RoundedRectangle(cornerRadius: 12)
//                    .fill(Color.accentColor.opacity(0.12))
//                    .frame(width: 52, height: 52)
                Image("cta_logo")
                    .resizable()
                    .scaledToFit()
                    .frame(width: 92, height: 92)
                    .clipShape(RoundedRectangle(cornerRadius: 12))
                    .padding(.leading, 20)
            }
            
            
            Spacer()
            
            Button {
                isShowingNewApp = true
            } label: {
                Text("New App")
                    .font(.custom("Inter-Bold", size: 16))
                    .foregroundStyle(Color.red)
            }.buttonStyle(.plain)
             .padding(.trailing, 20)
            
            Button {
                isShowingWorkspacePicker = true
            } label: {
                Text("Switch Workspace")
                    .font(.custom("Inter-Bold", size: 16))
                    .foregroundStyle(Color.black)
            }.buttonStyle(.plain)
             .padding(.trailing, 20)
            
            Button {
                isShowingVault = true
            } label: {
                Text("Test Data")
                    .font(.custom("Inter-Bold", size: 16))
                    .fontWeight(.semibold)
                    .foregroundColor(.white)
                    .padding(.horizontal, 45)
                    .padding(.vertical, 8)
                    .background(Color.red)
                    .clipShape(Capsule())
            }.buttonStyle(.plain)
                .padding(.trailing, 40)
//            .controlSize(.regular)
//            .help("Open the test-data vault (modules, inputs, assertions)")
            
            
            VStack(alignment: .trailing, spacing: 0) {
                OnlineOfflinePicker(selection: $generationMode).padding(.trailing, 20).padding(.leading, 20)
            }
            
            
          
            
        }
        .padding(EdgeInsets(top: 0, leading: 0, bottom: 0, trailing: 0))
        .background(Color.white)
        .shadow(color: .black.opacity(0.08), radius: 1, x: 0, y: -1)
        .shadow(color: .black.opacity(0.1), radius: 6, x: 0, y: 5)
    }
    
    
    
    // Custom Segmented Picker matching the design
    struct OnlineOfflinePicker: View {
        @Binding var selection: FlowGenerationMode

        var body: some View {
            HStack(spacing: 0) {
                ForEach(FlowGenerationMode.allCases) { mode in
                    Button(action: {
                        withAnimation(.easeInOut(duration: 0.2)) {
                            selection = mode
                        }
                    }) {
                        segmentLabel(for: mode)
                    }
                    .buttonStyle(.plain)
                }
            }
            
            .background(
                RoundedRectangle(cornerRadius: 10)
                    .fill(Color(red: 242/255, green: 244/255, blue: 247/255))
            )
            .frame(height: 52)
        }

        @ViewBuilder
        private func segmentLabel(for mode: FlowGenerationMode) -> some View {
            let isSelected = selection == mode
            let textColor: Color = isSelected ? .black : Color(red: 91/255, green: 91/255, blue: 92/255)
            let bgColor: Color = isSelected ? Color(red: 248/255, green: 255/255, blue: 249/255) : .clear
            let borderColor: Color = isSelected ? Color(red: 0.2, green: 0.85, blue: 0.2) : .clear

            Text(mode.rawValue)
                .font(.custom("Inter-Bold", size: 16))
                .foregroundColor(textColor)
                .frame(width: 90, height: 35)
                .background(segmentBackground(bgColor: bgColor, borderColor: borderColor))
        }

        private func segmentBackground(bgColor: Color, borderColor: Color) -> some View {
            RoundedRectangle(cornerRadius: 10)
                .fill(bgColor)
                .overlay(
                    RoundedRectangle(cornerRadius: 10)
                        .stroke(borderColor, lineWidth: 2.5)
                )
        }
    }
    
    
    
    private var generatorSection: some View {
        VStack(alignment: .leading, spacing: 14) {
            sectionTitle("DSL to YAML", icon: "wand.and.stars")
            
            
            
            VStack(alignment: .leading, spacing: 6) {
                Text("Flow Description")
                    .font(.custom("Roboto-Bold", size: 13))
                    .foregroundStyle(.secondary)
                
                ZStack(alignment: .topLeading) {
                    RoundedRectangle(cornerRadius: 10)
                        .fill(Color(NSColor.textBackgroundColor))
                    
                    if flowDescription.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty {
                        Text("Describe the full flow in plain English. Example: Launch the app, tap Login, enter username and password, submit, verify the dashboard is visible.")
                            .foregroundStyle(.secondary)
                            .padding(.horizontal, 14)
                            .padding(.vertical, 16)
                    }
                    
                    TextEditor(text: $flowDescription)
                        .scrollContentBackground(.hidden)
                        .padding(8)
                        .font(.system(.body, design: .monospaced))
                }
                .frame(minHeight: 200)
                .overlay(
                    RoundedRectangle(cornerRadius: 10)
                        .stroke(Color.secondary.opacity(0.18), lineWidth: 1)
                )
            }
            
            HStack(spacing: 12) {
                Button {
                    Task {
                        await generateAndSaveFlow()
                    }
                } label: {
                    if isGenerating {
                        Label("Generating...", systemImage: "sparkles")
                    } else {
                        Label("Generate YAML", systemImage: "sparkles")
                    }
                }
                .controlSize(.large)
                .buttonStyle(.borderedProminent)
                .disabled(isGenerating)
                
                if isGenerating {
                    ProgressView()
                        .controlSize(.small)
                }
                
                Spacer()
            }
            
            if !statusMessage.isEmpty {
                statusPill(text: statusMessage, color: .secondary, icon: "info.circle")
            }
            
            if !errorMessage.isEmpty {
                statusPill(text: errorMessage, color: .red, icon: "exclamationmark.triangle.fill")
            }
            
            if !savedFilePath.isEmpty {
                HStack(spacing: 10) {
                    statusPill(text: "Saved to \(savedFilePath)", color: .green, icon: "checkmark.circle.fill")
                    if let folderURL = folderURL,
                       FileManager.default.fileExists(atPath: folderURL.path) {
                        Button {
                            openFolder(at: folderURL)
                        } label: {
                            Label("Open Folder", systemImage: "folder")
                        }
                    }
                }
            }
        }
        .sectionCard()
    }
    
    @ViewBuilder
    private var generatedPreviewSection: some View {
        if !generatedYAML.isEmpty {
            VStack(alignment: .leading, spacing: 10) {
                sectionTitle("Generated YAML", icon: "doc.text")
                
                ScrollView {
                    Text(generatedYAML)
                        .frame(maxWidth: .infinity, alignment: .leading)
                        .font(.system(.body, design: .monospaced))
                        .textSelection(.enabled)
                        .padding(14)
                }
                .frame(minHeight: 220)
                .background(
                    RoundedRectangle(cornerRadius: 10)
                        .fill(Color(NSColor.textBackgroundColor))
                )
                .overlay(
                    RoundedRectangle(cornerRadius: 10)
                        .stroke(Color.secondary.opacity(0.18), lineWidth: 1)
                )
            }
            .sectionCard()
        }
    }
    
    private var testStepsCard: some View {
        VStack(alignment: .leading, spacing: 12) {
            sectionTitle("Capture & Generate Test Cases With Steps", icon: "")
            
            TestStepsGenerator(
                featureName: $featureName,
                screenshots: $screenshots,
                isLoading: $isLoading,
                testSteps: $testSteps,
                flowDescription: $flowDescription,
                generationMode: $generationMode,
                appId: $appId,
                projectName: $projectName,
                appType: $appType,
                multiFlowSavedCount: $multiFlowSavedCount
            )
        }
        .sectionCard()
    }
    
    
    
    
    
    
    public var actionSection: some View {
        VStack(alignment: .leading, spacing: 12) {
            if workspace.activePlatform.hasSimulator {
                deviceRow
            }

            HStack(spacing: 12) {
                bootButton

                Spacer()

                HStack(spacing: 6) {
//                    Image(systemName: "square.stack.3d.up")
//                        .font(.system(size: 13, weight: .semibold))
//                        .foregroundStyle(Color.red)
                    Text("Modules to Run")
                        .font(.custom("Inter-Bold", size: 14))
                }

                Button {
                    refreshModules()
                } label: {
                    Label("Refresh", systemImage: "arrow.clockwise")
                        .font(.custom("Inter-Bold", size: 16))
                        .fontWeight(.semibold)
                        .foregroundColor(.black)
                        .padding(.horizontal, 10)
                        .padding(.vertical, 3)
                        .background(Color.white)
                        .clipShape(Capsule())
                }.buttonStyle(.plain)
                    .overlay(
                        RoundedRectangle(cornerRadius: 20)
                            .stroke(Color.black, lineWidth: 1)
                    )
            }

            if availableModules.isEmpty {
                HStack(spacing: 8) {
                    Image(systemName: "info.circle")
                        .foregroundStyle(.secondary)
                    Text("Generate flows first, then they'll appear here as modules.")
                        .font(.custom("Roboto-Regular", size: 12))
                        .foregroundStyle(.secondary)
                    Spacer()
                }
                .padding(.vertical, 8)
            } else {
                FlowLayout(spacing: 8) {
                    ModuleChip(
                        label: "All",
                        isSelected: allModulesSelected,
                        isMaster: true,
                        action: toggleAllModules
                    )
                    ForEach(availableModules) { module in
                        ModuleChip(
                            label: "\(module.name) (\(module.flowCount))",
                            isSelected: selectedModules.contains(module.name),
                            action: { toggleModule(module.name) }
                        ).foregroundStyle(.red)
                            .tint(.red)
                    }
                }
            }

            HStack(spacing: 10) {
                Button {
                    runSelectedModules()
                } label: {
                    if isRunningAutomation {
                        HStack(spacing: 8) {
                            ProgressView().controlSize(.small)
                            Text("Running Automation...")
                        }
                    } else {
                       // Label(runButtonTitle, systemImage: "play.fill")
                        Label("Run Automation", systemImage: "play.fill")
                            .font(.custom("Inter-Bold", size: 16))
                            .fontWeight(.semibold)
                            .foregroundColor(.white)
                            .padding(.horizontal, 10)
                            .padding(.vertical, 8)
                            .background(Color.red)
                            .clipShape(Capsule())
                    }
                }
                .buttonStyle(.plain)
                .disabled(
                    isRunningAutomation
                    || availableModules.isEmpty
                    || selectedModules.isEmpty
                    || !workspace.activePlatform.isRunnable
                )
                .help(workspace.activePlatform.isRunnable
                      ? "Run the selected modules"
                      : "Web runner not yet wired up — coming in a future release.")

                Spacer()
            }
        }
        .sectionCard(padding: 14)
    }

    /// Platform-aware Boot button.
    ///   • Label is dynamic — reflects the picked device ("Boot iPhone 16 Pro"
    ///     / "Launch Pixel 7 API 34"). Falls back to "Boot Device" when
    ///     nothing is selected so the button still reads as an action.
    ///   • Disabled with a tooltip when no device is selected or the list
    ///     is empty (e.g. no AVDs configured).
    ///   • For physical Android devices the button reads "Connected" and
    ///     is disabled — there's literally nothing to boot.
    ///   • Hidden on Web (browsers don't need a boot step).
    @ViewBuilder
    private var bootButton: some View {
        let platform = workspace.activePlatform
        if platform.hasSimulator {
            let selected = deviceManager.selectedDevice(for: platform)
            let devices = deviceManager.devices(for: platform)
            let error = deviceManager.error(for: platform)

            let isPhysicalConnected = selected?.isPhysical == true
            let isDisabled = selected == nil || devices.isEmpty || isPhysicalConnected

            Button {
                bootDeviceForActivePlatform()
            } label: {
                Label(bootButtonTitle(for: platform, device: selected),
                      systemImage: bootButtonIcon(for: platform))
            }
            .controlSize(.large)
            .disabled(isDisabled)
            .help(bootButtonHelp(
                platform: platform,
                device: selected,
                isEmpty: devices.isEmpty,
                error: error
            ))
        } else {
            EmptyView()
        }
    }

    /// Dynamic title for the Boot button. Reads the picked device so the
    /// user can tell at a glance what'll happen on click.
    private func bootButtonTitle(for platform: Platform, device: DeviceInfo?) -> String {
        guard let device else {
            return platform == .ios ? "Boot Simulator" : "Launch Emulator"
        }
        if device.isPhysical {
            return "Device Connected"
        }
        // Strip the status suffix ("(Booted)" / "(Running)") off the picker
        // label — those suffixes belong in the picker, not the button.
        let raw = device.displayName
        let trimmed = raw
            .replacingOccurrences(of: " (Booted)", with: "")
            .replacingOccurrences(of: " (Running)", with: "")
        switch platform {
        case .ios:     return "Boot \(trimmed)"
        case .android: return "Launch \(trimmed)"
        case .web:     return ""
        }
    }

    private func bootButtonIcon(for platform: Platform) -> String {
        platform == .ios ? "iphone" : "smartphone"
    }

    private func bootButtonHelp(
        platform: Platform,
        device: DeviceInfo?,
        isEmpty: Bool,
        error: String?
    ) -> String {
        if let error { return error }
        if isEmpty {
            switch platform {
            case .ios:     return "No iOS simulators found. Add one in Xcode → Settings → Platforms."
            case .android: return "No AVDs configured. Create one in Android Studio → Device Manager."
            case .web:     return ""
            }
        }
        guard let device else { return "Pick a simulator first." }
        if device.isPhysical {
            return "Physical device is already connected. Maestro will use it for the run."
        }
        if device.isRunning {
            return "Already running — clicking will just bring the window to front."
        }
        return "Boot the selected device."
    }

    /// New "Device row" UI — sits above the Boot button when the active
    /// platform has the concept of a simulator/emulator.
    ///
    /// Three pieces:
    ///   1. Icon + "Simulator" / "Emulator" label.
    ///   2. Menu listing every discovered device. Each row shows the device
    ///      name + runtime + a "(Booted)" / "(Running)" / "(Connected)"
    ///      suffix when applicable, with full identifier in the tooltip.
    ///   3. Refresh button — re-runs simctl / emulator+adb without waiting
    ///      for the next platform switch.
    private var deviceRow: some View {
        let platform = workspace.activePlatform
        let devices = deviceManager.devices(for: platform)
        let selected = deviceManager.selectedDevice(for: platform)
        let error = deviceManager.error(for: platform)

        return HStack(spacing: 10) {
            Image(systemName: platform == .ios ? "iphone.gen3" : "smartphone")
                .font(.system(size: 14, weight: .semibold))
                .foregroundStyle(Color.black)

            Text(platform == .ios ? "Simulator" : "Emulator")
                .font(.custom("Roboto-Bold", size: 13))
                .foregroundStyle(.secondary)

            Menu {
                if devices.isEmpty {
                    Button(error ?? "No devices found") {}.disabled(true)
                } else {
                    ForEach(devices) { device in
                        Button {
                            deviceManager.select(device)
                        } label: {
                            if device.id == selected?.id {
                                Label(device.displayName, systemImage: "checkmark")
                            } else {
                                Text(device.displayName)
                            }
                        }
                        .help(device.tooltip)
                    }
                }
            } label: {
                HStack(spacing: 6) {
                    Text(selected?.displayName
                         ?? (error ?? "Select a device"))
                        .font(.custom("Roboto-Regular", size: 12))
                        .lineLimit(1)
                        .truncationMode(.middle)
                }
            }
            .menuStyle(.borderlessButton)
            .frame(minWidth: 280, maxWidth: 380)

            Button {
                deviceManager.refresh(for: platform)
            } label: {
                Label("Refresh", systemImage: "arrow.clockwise")
            }
            .controlSize(.small)
            .help("Re-scan for available \(platform == .ios ? "simulators" : "emulators and devices")")

            Spacer()
        }
        .padding(.horizontal, 12)
        .padding(.vertical, 8)
        .background(
            RoundedRectangle(cornerRadius: 8)
                .fill(Color.secondary.opacity(0.06))
        )
        .overlay(
            RoundedRectangle(cornerRadius: 8)
                .stroke(Color.secondary.opacity(0.18), lineWidth: 1)
        )
    }

    private var allModulesSelected: Bool {
        !availableModules.isEmpty && selectedModules.count == availableModules.count
    }

    private var runButtonTitle: String {
        let mods = selectedModules.count
        let flows = availableModules
            .filter { selectedModules.contains($0.name) }
            .reduce(0) { $0 + $1.flowCount }
        if mods == 0 {
            return "Run Automation Suite"
        }
        return "Run Automation Suite — \(mods) module\(mods == 1 ? "" : "s") · \(flows) flow\(flows == 1 ? "" : "s")"
    }

    private func toggleAllModules() {
        if allModulesSelected {
            selectedModules.removeAll()
        } else {
            selectedModules = Set(availableModules.map(\.name))
        }
    }

    private func toggleModule(_ name: String) {
        if selectedModules.contains(name) {
            selectedModules.remove(name)
        } else {
            selectedModules.insert(name)
        }
    }

    private func refreshModules() {
        let oldNames = Set(availableModules.map(\.name))
        availableModules = discoverModules()
        let newNames = Set(availableModules.map(\.name))

        if !hasDoneInitialScan {
            selectedModules = newNames
            hasDoneInitialScan = true
        } else {
            let stillThere = selectedModules.intersection(newNames)
            let newlyAdded = newNames.subtracting(oldNames)
            selectedModules = stillThere.union(newlyAdded)
        }
    }

    /// Called whenever the active (workspace, app, platform) context becomes
    /// known (initial launch with saved state, after the picker / new-app
    /// sheets, or after the user switches app/platform from the header).
    ///
    /// Reactions:
    ///   • Module checkboxes get re-scanned from the new platform's flows/.
    ///   • The folder watcher is re-pointed at the new flows/ folder.
    ///   • The AppId field auto-fills from the active app manifest.
    ///   • `hasDoneInitialScan` is reset so the new context's first scan
    ///     auto-selects everything (consistent with first-run behavior).
    private func onWorkspaceContextReady() {
        hasDoneInitialScan = false
        appId = workspace.currentAppId
        refreshModules()
        if let flows = workspace.currentFlowsURL() {
            folderWatcher.start(at: flows) { refreshModules() }
        }
        // Re-scan devices so the picker reflects the new platform's reality
        // (a different simctl/adb world) without the user touching Refresh.
        deviceManager.refresh(for: workspace.activePlatform)
    }

    /// Top-of-app workspace context bar — workspace path label + App and
    /// Platform dropdowns + "+ New App" and "Switch Workspace…" buttons.
    /// Stays out of the user's way (single thin row), but is always visible
    /// so the active context is unambiguous.
    private var workspaceContextBar: some View {
        HStack(spacing: 20) {
            VStack(alignment: .leading, spacing: 12) {
                HStack(spacing: 6) {
                    Text(workspace.workspaceURL?.lastPathComponent ?? "—")
                        .font(.custom("Inter-Bold", size: 25))
                        .lineLimit(1)
                        .help(workspace.workspaceURL?.path ?? "")
                }
                
                
                
                VStack(alignment: .leading, spacing: 6) {
                    Text("App Name")
                        .font(.custom("Inter-Bold", size: 12))
                        .foregroundStyle(.primary)
                    Menu {
                        ForEach(workspace.manifest.apps, id: \.name) { app in
                            Button(app.name) { handleAppSwitchRequest(to: app.name) }
                        }
                        Divider()
                        Button {
                            isShowingNewApp = true
                        } label: {
                            Label("New App…", systemImage: "plus")
                        }
                    } label: {
                        HStack {
                            Text(workspace.activeAppName ?? "—")
                                .font(.custom("Inter-Bold", size: 12))
                                .foregroundColor(.primary)
                            Spacer()
                            Image(systemName: "chevron.up.chevron.down")
                                .font(.system(size: 10, weight: .medium))
                                .foregroundColor(.secondary)
                        }
                        .padding(.horizontal, 12)
                        .frame(width: 250, height: 36)  // 👈 adjust as needed
                        .background(
                            RoundedRectangle(cornerRadius: 8)
                                .fill(Color.white)
                        )
                        .overlay(
                            RoundedRectangle(cornerRadius: 8)
                                .stroke(Color(red: 210/255, green: 213/255, blue: 219/255), lineWidth: 1)
                        )
                    }.buttonStyle(.plain)
                    
                    
                }
                
                
                
                VStack(alignment: .leading, spacing: 6) {
                    Text("Platform")
                        .font(.custom("Inter-Bold", size: 12))
                        .foregroundStyle(.primary)
                    Menu {
                        ForEach(Platform.allCases) { p in
                            Button {
                                handlePlatformSwitchRequest(to: p)
                            } label: {
                                if p == workspace.activePlatform {
                                    Label(p.displayName, systemImage: "checkmark")
                                } else {
                                    Text(p.displayName)
                                }
                            }
                        }
                    } label: {
                        Text(workspace.activePlatform.displayName)
                            .font(.custom("Inter-Bold", size: 12))
                            .foregroundColor(.primary)
                        Spacer()
                        Image(systemName: "chevron.up.chevron.down")
                            .font(.system(size: 10, weight: .medium))
                            .foregroundColor(.secondary)
                    }.padding(.horizontal, 12)
                        .frame(width: 250, height: 36)  // 👈 adjust as needed
                        .contentShape(Rectangle())
                        .background(
                            RoundedRectangle(cornerRadius: 8)
                                .fill(Color.white)
                        )
                        .overlay(
                            RoundedRectangle(cornerRadius: 8)
                                .stroke(Color(red: 210/255, green: 213/255, blue: 219/255), lineWidth: 1)
                        ).contentShape(Rectangle())
                    
                }.buttonStyle(.plain)
                
                Spacer()
                
                // New app add btn removed from here
                
                // Switch workspace button removed from here
                
                
                
            }
            .padding(.leading, 20)
            .padding(.vertical, 24)
            .overlay(
                RoundedRectangle(cornerRadius: 10)
                    .stroke(Color.clear.opacity(0.18), lineWidth: 1)
            )
            .alert(
                "Discard unsaved Multi-Flow work?",
                isPresented: Binding(
                    get: { pendingPlatformSwitch != nil || pendingAppSwitch != nil },
                    set: { newValue in
                        if !newValue {
                            pendingPlatformSwitch = nil
                            pendingAppSwitch = nil
                        }
                    }
                )
            ) {
                Button("Cancel", role: .cancel) {
                    pendingPlatformSwitch = nil
                    pendingAppSwitch = nil
                }
                Button("Discard & Switch", role: .destructive) {
                    applyPendingSwitch()
                }
            } message: {
                Text("You have screenshots or generated DSL cards that aren't saved as YAML. Switching will clear them.")
            }
            
            if workspace.activePlatform != .web {
                BuildUnderTestView().padding(.trailing, 20).padding(.top, 0)
            }
        }
    }
    /// True when there's in-progress Multi-Flow work that would be lost on a
    /// context switch. We use this to decide whether to show the discard
    /// alert vs. switching silently.
    private var hasUnsavedMultiFlowWork: Bool {
        !screenshots.isEmpty || !featureName.isEmpty
    }

    private func handlePlatformSwitchRequest(to platform: Platform) {
        guard platform != workspace.activePlatform else { return }
        if hasUnsavedMultiFlowWork {
            pendingPlatformSwitch = platform
        } else {
            workspace.activePlatform = platform
        }
    }

    private func handleAppSwitchRequest(to name: String) {
        guard name != workspace.activeAppName else { return }
        if hasUnsavedMultiFlowWork {
            pendingAppSwitch = name
        } else {
            workspace.setActiveApp(name)
        }
    }

    /// Applies a pending app or platform switch from the discard alert.
    /// Clears the in-progress Multi-Flow state first so the new context
    /// loads from scratch.
    private func applyPendingSwitch() {
        screenshots.removeAll()
        featureName = ""
        if let platform = pendingPlatformSwitch {
            workspace.activePlatform = platform
        }
        if let name = pendingAppSwitch {
            workspace.setActiveApp(name)
        }
        pendingPlatformSwitch = nil
        pendingAppSwitch = nil
    }

    private func runSelectedModules() {
        let ordered = orderedYAMLs(from: availableModules, selected: selectedModules)
        guard !ordered.isEmpty else { return }

        isRunningAutomation = true
        runAutomationRunner(
            orderedYAMLs: ordered,
            projectName: projectName.trimmingCharacters(in: .whitespacesAndNewlines),
            appType: appType.trimmingCharacters(in: .whitespacesAndNewlines)
        ) {
            isRunningAutomation = false
        }
    }
    
    
    private func sectionTitle(_ title: String, icon: String) -> some View {
        HStack(spacing: 8) {
//            Image(systemName: icon)
//                .font(.system(size: 18, weight: .black))
//                .foregroundStyle(Color.red)
            Text(title)
                .font(.custom("Inter-Bold", size: 25))
        }
    }
    
    private func statusPill(text: String, color: Color, icon: String) -> some View {
        HStack(spacing: 8) {
            Image(systemName: icon)
                .foregroundStyle(color)
            Text(text)
                .font(.custom("Roboto-Regular", size: 12))
                .foregroundStyle(color)
                .textSelection(.enabled)
        }
        .padding(.horizontal, 12)
        .padding(.vertical, 8)
        .background(
            RoundedRectangle(cornerRadius: 8)
                .fill(color.opacity(0.08))
        )
    }
    func openFolder(at url: URL) {
        
        NSWorkspace.shared.open(url)
    }
    @MainActor
    private func generateAndSaveFlow() async {
        let description = flowDescription.trimmingCharacters(in: .whitespacesAndNewlines)
        let apiKey = geminiAPIKey.trimmingCharacters(in: .whitespacesAndNewlines)
        let enteredAppId = appId.trimmingCharacters(in: .whitespacesAndNewlines)
        
        errorMessage = ""
        savedFilePath = ""
        
        guard !description.isEmpty else {
            statusMessage = ""
            errorMessage = "Enter a flow description before generating YAML."
            return
        }
        
        guard !enteredAppId.isEmpty else {
            statusMessage = ""
            errorMessage = "Enter the app ID before generating YAML."
            return
        }
        
        isGenerating = true
        statusMessage = generationMode == .online
        ? "Generating YAML from your DSL..."
        : "Generating YAML locally in offline mode..."
        
        do {
            let yaml: String
            
            if generationMode == .online {
                yaml = try generateMaestroYAML(
                    flowDescription: description,
                    appId: enteredAppId
                )
            } else {
                yaml = try generateMaestroYAML(
                    flowDescription: description,
                    appId: enteredAppId
                )
            }
            
            generatedYAML = yaml
            
            statusMessage = "YAML generated. Choose the name and folder in the macOS save dialog."
            
            let savedURL = try saveGeneratedYAMLToUserSelectedLocation(
                yaml,
                suggestedFileName: suggestedFileName(from: description)
            )
            
            savedFilePath = savedURL.path
            folderURL = savedURL
            statusMessage = "YAML generated and saved successfully."
        } catch FlowGenerationError.userCancelledSave {
            statusMessage = "YAML generated, but save was cancelled."
        } catch {
            statusMessage = ""
            errorMessage = error.localizedDescription
        }
        
        isGenerating = false
    }
    
    private func suggestedFileName(from description: String) -> String {
        let words = description
            .lowercased()
            .components(separatedBy: CharacterSet.alphanumerics.inverted)
            .filter { !$0.isEmpty }
        
        let fileName = words.prefix(6).joined(separator: "-")
        return fileName.isEmpty ? "generated-maestro-flow" : fileName
    }
    
    private func loadFonts() {
        let fontURLs = Bundle.main.urls(forResourcesWithExtension: "ttf", subdirectory: nil) ?? []
        
        for url in fontURLs {
            CTFontManagerRegisterFontsForURL(url as CFURL, .process, nil)
        }
    }
}
