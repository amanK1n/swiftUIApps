//
//  ModuleManager.swift
//  AIQATestRunner
//
//  Created by Sayed on 15/05/26.
//
//  Discovers YAML modules in the active platform's `flows/` folder, decides
//  their execution order (login first, logout last, others alphabetical),
//  watches that folder for changes, and provides the chip-based UI for
//  module selection.
//
//  The folder URL is resolved at call time from WorkspaceManager — the same
//  discovery code works regardless of which app + platform the user is on.
//

import Foundation
import SwiftUI
import AppKit
import Combine

// MARK: - Notification

extension Notification.Name {
    /// Kept for backward compatibility with existing observers. Posted on the
    /// same triggers as `.aiqaWorkspaceContextChanged` so observers don't
    /// need to change.
    static let aiqaE2EFolderDidChange = Notification.Name("aiqaE2EFolderDidChange")
}

// MARK: - Module Discovery

struct ModuleInfo: Identifiable, Hashable {
    var id: String { name }
    let name: String
    let yamlURLs: [URL]
    var flowCount: Int { yamlURLs.count }
}

/// Folder where today's YAML flows live for the active (app, platform).
/// Returns nil if the user hasn't picked a workspace + app yet — callers
/// should treat that as "no modules to show".
func activeFlowsFolderURL() -> URL? {
    WorkspaceManager.shared.currentFlowsURL()
}

/// Ranks a test-case type so that, within a module, cases sort as
/// negative → edge → positive. This guarantees the positive (state-changing)
/// case runs last in the module — e.g. the successful login is executed
/// after all login negatives/edges, so subsequent modules can rely on the
/// logged-in state; similarly the successful logout is the very last flow
/// of the run so the session is actually torn down.
private func typeRank(_ kind: String) -> Int {
    switch kind.lowercased() {
    case "negative": return 0
    case "edge":     return 1
    case "positive": return 2
    default:         return 1   // unknown types slot in with edge cases
    }
}

/// Scans the active platform's `flows/` folder for YAML files matching
/// `TC_<NNN>_<feature>_<type>_<title>.yaml` and groups them by `<feature>`.
/// Returns an empty list when no workspace context is active.
///
/// Within each module, flows are ordered:
///   1. all `negative` cases (by serial)
///   2. all `edge` cases (by serial)
///   3. all `positive` cases (by serial) — runs last so module state advances
///      only after every invalid path has been exercised.
func discoverModules() -> [ModuleInfo] {
    guard let folder = activeFlowsFolderURL() else { return [] }
    try? FileManager.default.createDirectory(at: folder, withIntermediateDirectories: true)

    guard let files = try? FileManager.default.contentsOfDirectory(
        at: folder,
        includingPropertiesForKeys: nil,
        options: [.skipsHiddenFiles]
    ) else {
        return []
    }

    let yamlFiles = files.filter { url in
        let ext = url.pathExtension.lowercased()
        return ext == "yaml" || ext == "yml"
    }

    var moduleMap: [String: [(serial: Int, typeRank: Int, url: URL)]] = [:]

    for url in yamlFiles {
        let stem = url.deletingPathExtension().lastPathComponent
        let parts = stem.split(separator: "_")
        guard parts.count >= 5, parts[0] == "TC", let serial = Int(parts[1]) else {
            continue
        }
        let feature = String(parts[2]).lowercased()
        let kind = String(parts[3])
        moduleMap[feature, default: []].append((serial, typeRank(kind), url))
    }

    return moduleMap
        .map { name, entries in
            let sortedURLs = entries
                .sorted { lhs, rhs in
                    if lhs.typeRank != rhs.typeRank { return lhs.typeRank < rhs.typeRank }
                    return lhs.serial < rhs.serial
                }
                .map { $0.url }
            return ModuleInfo(name: name, yamlURLs: sortedURLs)
        }
        .sorted { $0.name < $1.name }
}

// MARK: - Execution Ordering

/// Returns selected modules' YAML URLs in execution order.
///
/// Module order:
///   - `login` first
///   - other selected modules alphabetical (in between)
///   - `logout` last
///
/// Within every module (set by `discoverModules`):
///   - `negative` → `edge` → `positive`
///
/// Combined effect for a typical run with login + middle modules + logout:
///   login negatives → login edges → login positive (user is now signed in)
///   → middle module(s)' negatives/edges/positives
///   → logout negatives → logout edges → logout positive (user signed out, run ends).
///
/// The actual execution order is enforced via maestro's `config.yaml`
/// (`executionOrder.flowsOrder`), not via filename prefixes — maestro
/// runs flows in non-deterministic order by default when scanning a folder.
func orderedYAMLs(from modules: [ModuleInfo], selected: Set<String>) -> [URL] {
    let selectedModules = modules.filter { selected.contains($0.name) }
    var result: [URL] = []

    if let login = selectedModules.first(where: { $0.name == "login" }) {
        result.append(contentsOf: login.yamlURLs)
    }

    let middle = selectedModules
        .filter { $0.name != "login" && $0.name != "logout" }
        .sorted { $0.name < $1.name }

    for module in middle {
        result.append(contentsOf: module.yamlURLs)
    }

    if let logout = selectedModules.first(where: { $0.name == "logout" }) {
        result.append(contentsOf: logout.yamlURLs)
    }

    return result
}

// MARK: - File System Watcher

final class FolderWatcher: ObservableObject {
    private var source: DispatchSourceFileSystemObject?
    private var descriptor: Int32 = -1

    func start(at url: URL, onChange: @escaping () -> Void) {
        stop()
        try? FileManager.default.createDirectory(at: url, withIntermediateDirectories: true)

        let fd = open(url.path, O_EVTONLY)
        guard fd >= 0 else {
            print("⚠️ FolderWatcher: cannot open \(url.path)")
            return
        }
        descriptor = fd

        let src = DispatchSource.makeFileSystemObjectSource(
            fileDescriptor: fd,
            eventMask: [.write, .delete, .rename, .extend],
            queue: .main
        )
        src.setEventHandler {
            onChange()
        }
        src.setCancelHandler { [weak self] in
            if let fd = self?.descriptor, fd >= 0 {
                close(fd)
            }
        }
        src.resume()
        source = src
    }

    func stop() {
        source?.cancel()
        source = nil
        descriptor = -1
    }

    deinit { stop() }
}

// MARK: - FlowLayout (wraps chips)

@available(macOS 13.0, *)
struct FlowLayout: Layout {
    var spacing: CGFloat = 8

    func sizeThatFits(proposal: ProposedViewSize, subviews: Subviews, cache: inout ()) -> CGSize {
        let width = proposal.width ?? .infinity
        return arrange(subviews: subviews, in: width).size
    }

    func placeSubviews(in bounds: CGRect, proposal: ProposedViewSize, subviews: Subviews, cache: inout ()) {
        let result = arrange(subviews: subviews, in: bounds.width)
        for (i, position) in result.positions.enumerated() {
            subviews[i].place(
                at: CGPoint(x: bounds.minX + position.x, y: bounds.minY + position.y),
                proposal: .unspecified
            )
        }
    }

    private func arrange(subviews: Subviews, in width: CGFloat) -> (size: CGSize, positions: [CGPoint]) {
        var positions: [CGPoint] = []
        var x: CGFloat = 0
        var y: CGFloat = 0
        var lineHeight: CGFloat = 0
        var maxX: CGFloat = 0

        for view in subviews {
            let size = view.sizeThatFits(.unspecified)
            if x > 0 && x + size.width > width {
                x = 0
                y += lineHeight + spacing
                lineHeight = 0
            }
            positions.append(CGPoint(x: x, y: y))
            x += size.width + spacing
            lineHeight = max(lineHeight, size.height)
            maxX = max(maxX, x)
        }

        return (CGSize(width: maxX, height: y + lineHeight), positions)
    }
}

// MARK: - ModuleChip

struct ModuleChip: View {
    let label: String
    let isSelected: Bool
    let isMaster: Bool
    let action: () -> Void

    init(label: String, isSelected: Bool, isMaster: Bool = false, action: @escaping () -> Void) {
        self.label = label
        self.isSelected = isSelected
        self.isMaster = isMaster
        self.action = action
    }

    var body: some View {
        Button(action: action) {
            HStack(spacing: 6) {
                Image(systemName: isSelected ? "checkmark.square.fill" : "square")
                    .font(.system(size: 13))
                Text(label)
                    .font(.custom(isMaster ? "Roboto-Bold" : "Roboto-Regular", size: 12))
            }
            .padding(.horizontal, 11)
            .padding(.vertical, 6)
            .background(
                RoundedRectangle(cornerRadius: 7)
                    .fill(isSelected ? Color.clear.opacity(0.14) : Color.clear)
            )
            .overlay(
                RoundedRectangle(cornerRadius: 7)
                    .strokeBorder(
                        isSelected ? Color.red : Color.secondary.opacity(0.35),
                        lineWidth: 1
                    )
            )
            .foregroundStyle(isSelected ? Color.red : Color.primary)
        }
        .buttonStyle(.plain)
    }
}
