//
//  TestStepsGenerator.swift
//  AIQATestRunner
//
//  Created by Sayed on 26/04/26.
//

import Foundation
import SwiftUI
import UniformTypeIdentifiers

struct TestStepsGenerator: View {
    @Binding var featureName: String
    @Binding var screenshots: [ScreenshotItem]
    @Binding var isLoading: Bool
    @Binding var testSteps: [TestStep]
    @Binding var flowDescription: String
    @State var testCases: [TestCase] = []
    @Binding var generationMode: FlowGenerationMode
    @Binding var appId: String
    @Binding var projectName: String
    @Binding var appType: String
    @Binding var multiFlowSavedCount: Int
    @State var multiFlowCases: [EditableMultiFlowCase] = []
    @State var multiFlowStatus: String = ""
    @State var multiFlowError: String = ""
    
    @State var multiFlowSavedFolder: URL? = nil

    @State private var isExternalDropTargeted: Bool = false
    @State private var selectedPlatform = "Smoke"
    @ObservedObject private var vaultManager = VaultManager.shared
    var platforms = ["Smoke", "Sanity", "Regression"]

    /// Small dropdown shown next to the Feature-under-test field. Picks any
    /// existing vault module by slug; selecting one writes it into
    /// `featureName`. The TextField stays the canonical input so the user can
    /// still type a brand-new feature name (which the rest of the pipeline
    /// will slugify and treat as a new module — auto-create-empty is off, so
    /// no vault entry is forced; the AI just works freeform for that module).
    @ViewBuilder
    private var vaultModulePicker: some View {
        let slugs = vaultManager.availableModuleSlugs()
        if slugs.isEmpty {
            EmptyView()
        } else {
            Menu {
                ForEach(slugs, id: \.self) { slug in
                    Button(slug) { featureName = slug }
                }
            } label: {
                Label("Vault", systemImage: "tray.full")
                    .labelStyle(.iconOnly)
            }
            .menuStyle(.borderlessButton)
            .help("Pick an existing module from the vault")
            .frame(width: 28)
        }
    }
    var body: some View {
        VStack(alignment: .leading, spacing: 14) {
            HStack(spacing: 10) {
                VStack(alignment: .leading, spacing: 6) {
                    Text("Project Name*")
                        .font(.custom("Inter-Bold", size: 12))
                        .foregroundStyle(.black)
                    TextField("Enter project name", text: $projectName)
                        .font(.custom("Inter-Regular", size: 12))
                        .textFieldStyle(.plain)
                        .padding(.horizontal, 12)
                        .padding(.vertical, 8)
                        .background(Color(.textBackgroundColor))
                        .cornerRadius(6)
                        .overlay(
                            RoundedRectangle(cornerRadius: 6)
                                .stroke(Color.gray.opacity(0.4), lineWidth: 1)
                        )
                        .frame(width: 250)
                        .tint(.red)
                }
                VStack(alignment: .leading, spacing: 6) {
                    Text("App Type*")
                        .font(.custom("Inter-Bold", size: 12))
                        .foregroundStyle(.black)
                    TextField("e.g. Consumer, Channel, etc", text: $appType)
                        .font(.custom("Inter-Regular", size: 12))
                        .textFieldStyle(.plain)
                        .padding(.horizontal, 12)
                        .padding(.vertical, 8)
                        .background(Color(.textBackgroundColor))
                        .cornerRadius(6)
                        .overlay(
                            RoundedRectangle(cornerRadius: 6)
                                .stroke(Color.gray.opacity(0.4), lineWidth: 1)
                        )
                        .frame(width: 250)
                        .tint(.red)
                }
                VStack(alignment: .leading, spacing: 6) {
                    HStack {
                        Text("Feature under Test")
                            .font(.custom("Inter-Bold", size: 12))
                            .foregroundStyle(.black)
                        vaultModulePicker
                    }
                    TextField("e.g. login, registration, checkout", text: $featureName)
                        .font(.custom("Inter-Regular", size: 12))
                        .textFieldStyle(.plain)
                        .padding(.horizontal, 12)
                        .padding(.vertical, 8)
                        .background(Color(.textBackgroundColor))
                        .cornerRadius(6)
                        .overlay(
                            RoundedRectangle(cornerRadius: 6)
                                .stroke(Color.gray.opacity(0.4), lineWidth: 1)
                        )
                        .frame(width: 250)
                        .tint(.red)
                }
                
                VStack(alignment: .leading, spacing: 6) {
                    // Label
                    Text("Select Test Type")
                        .font(.headline)
                    
                    // Radio Buttons
                    HStack(spacing: 15) {
                        ForEach(platforms, id: \.self) { platform in
                            RadioButtonField(
                                label: platform,
                                isSelected: selectedPlatform == platform,
                                action: { selectedPlatform = platform }
                            )
                        }
                    }
                }
                .padding()
            }
            
           
            screenshotDropArea
            multiFlowSection
            
        }
    }
   public struct RadioButtonField: View {
        let label: String
        let isSelected: Bool
        let action: () -> Void
        
        var body: some View {
            Button(action: action) {
                HStack(spacing: 8) {
                    // The Radio Circle
                    ZStack {
                        Circle()
                            .stroke(Color.red, lineWidth: 2)
                            .frame(width: 20, height: 20)
                        
                        if isSelected {
                            Circle()
                                .fill(Color.red)
                                .frame(width: 12, height: 12)
                        }
                    }
                    
                    Text(label)
                        .foregroundColor(.primary)
                }
            }
            .buttonStyle(PlainButtonStyle()) // Prevents the whole row from flashing on tap
        }
    }
    @ViewBuilder
    private var screenshotDropArea: some View {
        VStack(alignment: .trailing) {
            ZStack {
                
//                Image("drop_zone_background")
//                    .resizable()
//                    .cornerRadius(CGFloat(10.0))
                
                if screenshots.isEmpty {
                    VStack(alignment: .center, spacing: 20) {
                        Image("drop_screenshot_icon")
                            .resizable()
                            .frame(width: 100, height: 60)
                            .padding(.vertical, 20)
                           // .padding(.bottom, -50)
                        
                        Text("Drop screenshots here")
                            .font(.custom("Inter-Bold", size: 25))
                            .foregroundStyle(.black)
                        Text("Drag & drop your screenshots or click to upload")
                            .font(.custom("Inter-Regular", size: 16))
                            .foregroundStyle(.secondary.opacity(0.8))
                            .padding(.bottom, 10)
                        
                        
                        Button {
                            openImagePicker()
                        } label: {
                            Text("Upload Screenshots")
                                .font(.custom("Inter-Bold", size: 16))
                                .fontWeight(.semibold)
                                .foregroundColor(.white)
                                .padding(.horizontal, 45)
                                .padding(.vertical, 8)
                                .background(Color.red)
                                .clipShape(Capsule())
                        }
                        .buttonStyle(.plain)
                    }
                    .frame(maxWidth: .infinity, minHeight: 140)
                } else {
                    ScrollView(.horizontal, showsIndicators: false) {
                        HStack(spacing: 12) {
                            ForEach($screenshots) { $item in
                                screenshotThumbnail(item: $item)
                                    .draggable(item.id.uuidString) {
                                        Image(nsImage: item.image)
                                            .resizable()
                                            .aspectRatio(contentMode: .fill)
                                            .frame(width: 100, height: 200)
                                            .clipShape(RoundedRectangle(cornerRadius: 8))
                                            .opacity(0.8)
                                    }
                                    .dropDestination(for: String.self) { droppedIds, _ in
                                        handleScreenshotReorder(targetId: item.id, draggedIds: droppedIds)
                                    }
                            }
                        }
                        .padding(.vertical, 6)
                        .padding(.horizontal, 30)
                    }
                    
                    Text("\(screenshots.count) screenshot\(screenshots.count == 1 ? "" : "s") · drag to reorder")
                        .font(.custom("Roboto-Regular", size: 11))
                        .foregroundStyle(.secondary)
                    
                    
                    
                }
                
            }
            .frame(maxWidth: .infinity, minHeight: screenshots.isEmpty ? 140 : nil)
            .background(
                RoundedRectangle(cornerRadius: 12)
                    .fill(isExternalDropTargeted ? Color.accentColor.opacity(0.08) : Color.white.opacity(0.04))
            )
            .overlay(
                RoundedRectangle(cornerRadius: 12)
                    .strokeBorder(
                        isExternalDropTargeted ? Color.accentColor : Color.white.opacity(0.2),
                        style: StrokeStyle(
                            lineWidth: isExternalDropTargeted ? 2 : 1,
                            dash: screenshots.isEmpty ? [6, 4] : []
                        )
                    )
            )
            .animation(.easeInOut(duration: 0.15), value: isExternalDropTargeted)
            .onDrop(of: [UTType.fileURL, UTType.image], isTargeted: $isExternalDropTargeted) { providers in
                handleExternalImageDrop(providers: providers)
            }
            if !screenshots.isEmpty {
            Button {
                openImagePicker()
            } label: {
                Text("+ Add more")
                    .font(.custom("Inter-Bold", size: 16))
                    .fontWeight(.semibold)
                    .foregroundColor(.white)
                    .padding(.horizontal, 45)
                    .padding(.vertical, 8)
                    .background(Color.red)
                    .clipShape(Capsule())
            }
            .buttonStyle(.plain)
        }
    }
    }

    private func handleScreenshotReorder(targetId: UUID, draggedIds: [String]) -> Bool {
        guard let droppedIdString = draggedIds.first,
              let droppedUUID = UUID(uuidString: droppedIdString),
              droppedUUID != targetId,
              let fromIndex = screenshots.firstIndex(where: { $0.id == droppedUUID }),
              let toIndex = screenshots.firstIndex(where: { $0.id == targetId })
        else { return false }

        withAnimation(.easeInOut(duration: 0.2)) {
            let moved = screenshots.remove(at: fromIndex)
            screenshots.insert(moved, at: toIndex)
        }
        return true
    }

    private func handleExternalImageDrop(providers: [NSItemProvider]) -> Bool {
        var handledAny = false

        for provider in providers {
            if provider.canLoadObject(ofClass: NSImage.self) {
                handledAny = true
                _ = provider.loadObject(ofClass: NSImage.self) { image, _ in
                    if let nsImage = image as? NSImage {
                        DispatchQueue.main.async {
                            screenshots.append(ScreenshotItem(image: nsImage, description: ""))
                        }
                    }
                }
            } else if provider.hasItemConformingToTypeIdentifier(UTType.fileURL.identifier) {
                handledAny = true
                provider.loadItem(forTypeIdentifier: UTType.fileURL.identifier, options: nil) { item, _ in
                    var fileURL: URL?
                    if let url = item as? URL {
                        fileURL = url
                    } else if let data = item as? Data,
                              let urlString = String(data: data, encoding: .utf8) {
                        fileURL = URL(string: urlString) ?? URL(fileURLWithPath: urlString)
                    }
                    if let url = fileURL, let img = NSImage(contentsOf: url) {
                        DispatchQueue.main.async {
                            screenshots.append(ScreenshotItem(image: img, description: ""))
                        }
                    }
                }
            }
        }
        return handledAny
    }

    private func screenshotThumbnail(item: Binding<ScreenshotItem>) -> some View {
        VStack(spacing: 6) {
            ZStack(alignment: .topTrailing) {
                Image(nsImage: item.wrappedValue.image)
                    .resizable()
                    .aspectRatio(contentMode: .fill)
                    .frame(width: 150, height: 300)
                    .clipShape(RoundedRectangle(cornerRadius: 10))
                    .overlay(
                        RoundedRectangle(cornerRadius: 10)
                            .stroke(Color.secondary.opacity(0.25), lineWidth: 1)
                    )

                Button(action: {
                    removeScreenshot(item.wrappedValue)
                }) {
                    Image(systemName: "xmark.circle.fill")
                        .font(.system(size: 18))
                        .foregroundColor(.red)
                        .background(Color.white.clipShape(Circle()))
                }
                .buttonStyle(PlainButtonStyle())
                .offset(x: 6, y: -6)
            }

            ZStack(alignment: .topLeading) {
                if item.wrappedValue.description.isEmpty {
                    Text("Describe the user flow you want to test...")
                        .font(.custom("Roboto-Regular", size: 10))
                        .foregroundColor(.gray)
                        .padding(.top, 8)
                        .padding(.leading, 8)
                        .allowsHitTesting(false)
                }
                TextEditor(text: item.description)
                    .font(.system(size: 11))
                    .scrollContentBackground(.hidden)
                    .padding(4)
            }
            .frame(width: 150, height: 80)
            .background(
                RoundedRectangle(cornerRadius: 8)
                    .fill(Color(NSColor.textBackgroundColor))
            )
            .overlay(
                RoundedRectangle(cornerRadius: 8)
                    .stroke(Color.secondary.opacity(0.2), lineWidth: 1)
            )
        }
    }

    @ViewBuilder
    private var multiFlowSection: some View {
        VStack(alignment: .leading, spacing: 12) {
            Divider()
            HStack(spacing: 8) {
                Text("Multi-Flow Test Cases Suite")
                    .font(.custom("Inter-Bold", size: 15))
                Spacer()
                if generationMode == .online {
                    HStack(spacing: 10) {
                        Spacer()
                        Button(action: {
                            Task {
                                await generateTestScenarios()
                            }
                        }) {
                            if isLoading {
                                HStack(spacing: 6) {
                                    ProgressView().controlSize(.small)
                                    Text("Generate Test Scenario Online")
                                        .font(.custom("Inter-Bold", size: 16))
                                        .fontWeight(.semibold)
                                        .foregroundColor(.black)
                                        .padding(.horizontal, 45)
                                        .padding(.vertical, 8)
                                        .background(Color.white)
                                        .clipShape(Capsule())
                                }
                            } else {
                                Text("Generate Test Scenario Online")
                                    .font(.custom("Inter-Bold", size: 16))
                                    .fontWeight(.semibold)
                                    .foregroundColor(.black)
                                    .padding(.horizontal, 45)
                                    .padding(.vertical, 8)
                                    .background(Color.white)
                                    .clipShape(Capsule())
                            }
                        }.buttonStyle(.plain)
                        .overlay(
                                RoundedRectangle(cornerRadius: 20)
                                    .stroke(Color.black, lineWidth: 1)
                            )
                        .disabled(isLoading)
                        
                    }
                } else {
                    HStack(spacing: 10) {
                        Spacer()
                        Button(action: offlineTestScenarioGenerator) {
                            if isLoading {
                                HStack(spacing: 6) {
                                    ProgressView().controlSize(.small)
                                    Text("Generate Test Scenario Offline")
                                        .font(.custom("Inter-Bold", size: 16))
                                        .fontWeight(.semibold)
                                        .foregroundColor(.black)
                                        .padding(.horizontal, 45)
                                        .padding(.vertical, 8)
                                        .background(Color.white)
                                        .clipShape(Capsule())
                                }
                            } else {
                                Text("Generate Test Scenario Offline")
                                    .font(.custom("Inter-Bold", size: 16))
                                    .fontWeight(.semibold)
                                    .foregroundColor(.black)
                                    .padding(.horizontal, 45)
                                    .padding(.vertical, 8)
                                    .background(Color.white)
                                    .clipShape(Capsule())
                            }
                        }.buttonStyle(.plain)
                            .overlay(
                                RoundedRectangle(cornerRadius: 20)
                                    .stroke(Color.black, lineWidth: 1)
                            )
                            .disabled(isLoading)
                        
                    }
                }
                
                // GENERATE MULTI-FLOW BUTTON
                Button {
                    Task { await generateMultiFlowSuite() }
                } label: {
                    if isLoading && multiFlowCases.isEmpty {
                        HStack(spacing: 6) {
                            ProgressView().controlSize(.small)
                            Text("Generating Test Cases Steps...")
                                .font(.custom("Inter-Bold", size: 16))
                                .fontWeight(.semibold)
                                .foregroundColor(.white)
                                .padding(.horizontal, 45)
                                .padding(.vertical, 8)
                                .background(Color.red)
                                .clipShape(Capsule())
                        }
                    } else {
                        Text("Generate Test Cases Steps \(generationMode.rawValue)")
                            .font(.custom("Inter-Bold", size: 16))
                            .fontWeight(.semibold)
                            .foregroundColor(.white)
                            .padding(.horizontal, 45)
                            .padding(.vertical, 8)
                            .background(Color.red)
                            .clipShape(Capsule())
                    }
                }
                .buttonStyle(.plain)
                .disabled(isLoading)
            }

            if !multiFlowCases.isEmpty {
                Text("\(multiFlowCases.count) flow\(multiFlowCases.count == 1 ? "" : "s") generated. Review and edit the DSL below, then transpile to YAML.")
                    .font(.custom("Roboto-Regular", size: 12))
                    .foregroundStyle(.secondary)

                ScrollView(.horizontal, showsIndicators: true) {
                    HStack(alignment: .top, spacing: 12) {
                        ForEach(multiFlowCases.indices, id: \.self) { idx in
                            // Capture the case's UUID so the closure removes
                            // the correct entry even if the array reorders
                            // (or another case is deleted) before the user
                            // clicks. Index alone would be unsafe.
                            let caseId = multiFlowCases[idx].id
                            MultiFlowCardView(
                                index: idx + 1,
                                testCase: $multiFlowCases[idx],
                                onDelete: {
                                    multiFlowCases.removeAll { $0.id == caseId }
                                }
                            )
                        }
                    }
                    .padding(.vertical, 4)
                }
                .frame(minHeight: 320)

                HStack(spacing: 12) {
                    HStack() {
                        // Label + placeholder track the active platform so the
                        // field reads correctly on iOS (Bundle Id), Android
                        // (Package Name), and Web (URL).
                        Text(WorkspaceManager.shared.activePlatform.appIdFieldLabel)
                            .font(.custom("Roboto-Bold", size: 13))
                            .foregroundStyle(.secondary)
                        TextField(
                            WorkspaceManager.shared.activePlatform.appIdPlaceholder,
                            text: $appId
                        )
                            .textFieldStyle(.roundedBorder)
                            .onChange(of: appId) { newValue in
                                // Persist edits to the active app's manifest so
                                // the value sticks across platform switches and
                                // app restarts. Empty strings are fine — they
                                // just clear the stored id for that platform.
                                WorkspaceManager.shared.setActiveAppId(newValue)
                            }
                    }
                    Button {
                        generateYAMLForMultiFlowSuite()
                    } label: {
                        Text("Generate YAML for Suite")
                            .font(.custom("Inter-Bold", size: 16))
                            .fontWeight(.semibold)
                            .foregroundColor(.white)
                            .padding(.horizontal, 30)
                            .padding(.vertical, 8)
                            .background(Color.red)
                            .clipShape(Capsule())
                    }
                    .buttonStyle(.plain)
                    .disabled(isLoading)
                   
                    if multiFlowSavedCount > 0 {
                        // PEEK FOLDER BUTTON AFTER TRANSPILATION
                        Button {
                            openMultiFlowFolder()
                        } label: {
                            Label("Open Folder", systemImage: "folder")
                                .font(.custom("Inter-Bold", size: 16))
                                .fontWeight(.semibold)
                                .foregroundColor(.black)
                                .padding(.horizontal, 30)
                                .padding(.vertical, 8)
                                .background(Color.white)
                                .clipShape(Capsule())
                        }.buttonStyle(.plain)
                            .overlay(
                                RoundedRectangle(cornerRadius: 20)
                                    .stroke(Color.black, lineWidth: 1)
                            )
                        
                        // NEXT FEATURE BUTTON AFTER TRANSPILATION
                        Button {
                            resetForNextModule()
                        } label: {
                            Label("Next Module", systemImage: "arrow.uturn.forward.circle")
                                .font(.custom("Inter-Bold", size: 16))
                                .fontWeight(.semibold)
                                .foregroundColor(.black)
                                .padding(.horizontal, 30)
                                .padding(.vertical, 8)
                                .background(Color.white)
                                .clipShape(Capsule())
                        }.buttonStyle(.plain)
                            .overlay(
                                RoundedRectangle(cornerRadius: 20)
                                    .stroke(Color.black, lineWidth: 1)
                            )
                        .help("Clear feature name, screenshots, and DSL cards to start a fresh module. Keeps project, app type, app id, and mode.")
                    }
                    Spacer()
                }
            }

            if !multiFlowStatus.isEmpty {
                HStack(spacing: 6) {
                    Image(systemName: "info.circle")
                        .foregroundStyle(.secondary)
                    Text(multiFlowStatus)
                        .font(.custom("Roboto-Regular", size: 12))
                        .foregroundStyle(.secondary)
                        .textSelection(.enabled)
                }
                .padding(.horizontal, 10)
                .padding(.vertical, 6)
                .background(
                    RoundedRectangle(cornerRadius: 6)
                        .fill(Color.secondary.opacity(0.08))
                )
            }

            if !multiFlowError.isEmpty {
                HStack(spacing: 6) {
                    Image(systemName: "exclamationmark.triangle.fill")
                        .foregroundStyle(.red)
                    Text(multiFlowError)
                        .font(.custom("Roboto-Regular", size: 12))
                        .foregroundStyle(.red)
                }
                .padding(.horizontal, 10)
                .padding(.vertical, 6)
                .background(
                    RoundedRectangle(cornerRadius: 6)
                        .fill(Color.red.opacity(0.08))
                )
            }
        }
        .padding(.top, 6)
    }
    
    
    
    
    
    
    
    // To OPEN the image picker PANEL
    func openImagePicker() {
        let panel = NSOpenPanel()
        panel.allowedContentTypes = [.png, .jpeg]
        panel.allowsMultipleSelection = true
        
        if panel.runModal() == .OK {
            for url in panel.urls {
                if let img = NSImage(contentsOf: url) {
                    screenshots.append(ScreenshotItem(image: img, description: ""))
                }
            }
        }
    }
    // To DELETE the selected screenshot
    func removeScreenshot(_ item: ScreenshotItem) {
        screenshots.removeAll { $0.id == item.id }
    }
    
    // Online API Call FOR INFERENCE
    func generateTestCases() {
        guard !screenshots.isEmpty else {
            return
        }
        
        isLoading = true
        
        let apiKey = ""
        
        
        let imagesPayload: [[String: Any]] = screenshots.compactMap { item -> [[String: Any]]? in
            guard let base64 = imageToBase64(item.image) else { return nil }
            
            return [
                [
                    "text": item.description.isEmpty
                    ? "Analyze this screen and generate steps to complete flow."
                    : "Screen description: \(item.description)"
                ],
                [
                    "inline_data": [
                        "mime_type": "image/png",
                        "data": base64
                    ]
                ]
            ]
        }.flatMap { $0 }
        
        let descriptions = screenshots.enumerated().map { index, shot in
            "Screen \(index + 1): \(shot.description)"
        }.joined(separator: "\n")
        
        let prompt = """
        You are a mobile test automation expert.
        Your job is to analyze mobile app screenshots and generate sequential steps.
        COMMAND REFERENCE:
        - Tap <label>          → Tap a visible labeled element
        - Tap <label> <index>  → Tap when multiple elements share the same label (0-based index)
        - TapIcon <x%,y%>      → Tap an icon-only element with no readable label
        - Visible <label>      → Assert element is visible (use as screen boundary check)
        - Enter <value>        → Type into the currently focused input field
        - Scroll to <value>    → Scroll to that element until visible
        - runflow <label>      → Conditional tap: only if element is visible
        
        RULES FOR OUTPUT:
        1. Output ONLY the steps, one per line. No explanation, no markdown, no numbering.
        2. For input fields: always Tap the field first, then Enter the value on the next line.
        3. If duplicate labels exist, always target the interactive element (button, textField, etc.) instead of static text, and append a 0-based index after the label.
            Format: Tap <label> <index>
            Example: Tap Login 1 means tap the second interactive element labeled “Login”.
        4. use TapIcon with the icon’s exact center position as screen-relative whole-number percentages and comma separated. Example: TapIcon: 92%, 8%
        5. Use scroll, when prompted by user
        6. Use runflow for elements that may or may not appear (conditional screens like Continue, Skip, Allow).
        7. Follow the logical order: fill all fields before tapping submit/login/confirm.
        8. Use the screen hints provided by the user to understand context and field meaning.
        
        Module under test: \(featureName)
        
        Screen Descriptions:
        \(descriptions)
        
        Return output strictly in JSON array format:
        [
          {
            "steps": ""
          }
        ]
        """
        
        let requestBody: [String: Any] = [
            "contents": [
                [
                    "parts": [
                        ["text": prompt]
                    ] + imagesPayload
                ]
            ]
        ]
        
        guard let url = URL(string: "https://generativelanguage.googleapis.com/v1beta/models/gemini-2.5-flash:generateContent?key=\(apiKey)") else {
            return
        }
        let config = URLSessionConfiguration.default
        config.timeoutIntervalForRequest = 120   // 2 minutes
        config.timeoutIntervalForResource = 180  // 3 minutes
        
        
        var request = URLRequest(url: url)
        request.httpMethod = "POST"
        request.addValue("application/json", forHTTPHeaderField: "Content-Type")
        request.httpBody = try? JSONSerialization.data(withJSONObject: requestBody)
        
        let session = URLSession(configuration: config)
        session.dataTask(with: request) { data, response, error in
            DispatchQueue.main.async {
                self.isLoading = false
            }
            if let error = error {
                print("❌ ERROR:", error.localizedDescription)
                return
            }
            
            if let httpResponse = response as? HTTPURLResponse {
                print("📡 Status Code:", httpResponse.statusCode)
            }
            
            if let data = data {
                print("📦 Response:", String(data: data, encoding: .utf8) ?? "nil")
            }
            guard let data = data else { return }
            
            if let jsonString = parseGeminiResponse(data: data) {
                parseTestCases(jsonString)
            }
        }.resume()
    }
    
    // Encode image to Base64
    func imageToBase64(_ image: NSImage) -> String? {
        guard let tiffData = image.tiffRepresentation,
              let bitmap = NSBitmapImageRep(data: tiffData),
              let pngData = bitmap.representation(using: .png, properties: [:]) else {
            return nil
        }
        return pngData.base64EncodedString()
    }
    // PARSE the RESPONSE of GEMINI
    func parseGeminiResponse(data: Data) -> String? {
        guard let json = try? JSONSerialization.jsonObject(with: data) as? [String: Any],
              let candidates = json["candidates"] as? [[String: Any]],
              let content = candidates.first?["content"] as? [String: Any],
              let parts = content["parts"] as? [[String: Any]],
              let text = parts.first?["text"] as? String else {
            return nil
        }
        return text
    }
    // Clean the MESSY Strings
    func parseTestCases(_ jsonString: String) {
        print("Now inside Existing: parseTestCases")
        let cleaned = jsonString
            .replacingOccurrences(of: "```json", with: "")
            .replacingOccurrences(of: "```", with: "")
            .trimmingCharacters(in: .whitespacesAndNewlines)
        
        guard let data = cleaned.data(using: .utf8),
              let decoded = try? JSONDecoder().decode([TestStep].self, from: data) else {
            print("❌ Decoding failed")
            print(cleaned)
            return
        }
        
        DispatchQueue.main.async {
            print("adding decoded to testSteps")
            self.testSteps = decoded
            print("self.testSteps--value::", self.testSteps)
            let steps = decoded.map {
                $0.steps
            }.joined(separator: "\n")
            self.flowDescription = steps
            print("self.flowDescription--value::", self.flowDescription)
        }
    }
    
    // This is TEST SCENARIO
    func generateTestScenarios() async {
        
        print("screenshots::", screenshots.isEmpty)
        
        guard !screenshots.isEmpty else {
            setMultiFlowError("Upload at least one screenshot before generating a suite.")
            return
        }
        let trimmedFeature = featureName.trimmingCharacters(in: .whitespacesAndNewlines)
        guard !trimmedFeature.isEmpty else {
            await setMultiFlowError("Enter the feature name before generating a suite.")
            return
        }
        
        
        isLoading = true
        let apiKey = ""
        
        let imagesPayload: [[String: Any]] = screenshots.compactMap { item -> [[String: Any]]? in
            guard let base64 = imageToBase64(item.image) else { return nil }
            return [
                ["text": item.description.isEmpty ? "Analyze screen" : item.description],
                ["inline_data": ["mime_type": "image/png", "data": base64]]
            ]
        }.flatMap { $0 }
        let descriptions = screenshots.map { $0.description }.joined(separator: "\n")
        
        let prompt = """
        You are a QA AI Agent.
        Generate test cases in JSON format.
        Feature: \(featureName)
        Descriptions: \(descriptions)
        Return output strictly in JSON array format:
        [
         {
           "title": "",
           "steps": "",
           "expectedResult": "",
           "type": "positive/negative/edge"
         }
        ]
        Ensure:
        - "title": Title of the test case only. Do NOT include type (positive/negative/edge) in this field.
        - "type": Must contain only ONE word — either "positive", "negative", or "edge".
        """
        
        let body: [String: Any] = [
            "contents": [[
                "parts": [["text": prompt]] + imagesPayload
            ]]
        ]
        
        guard let url = URL(string: "https://generativelanguage.googleapis.com/v1beta/models/gemini-2.5-flash:generateContent?key=\(apiKey)") else { return }
        
        print("complete URL::", url)
        let config = URLSessionConfiguration.default
        config.timeoutIntervalForRequest = 120   // 2 minutes
        config.timeoutIntervalForResource = 180  // 3 minutes
        
        
        var request = URLRequest(url: url)
        request.httpMethod = "POST"
        request.addValue("application/json", forHTTPHeaderField: "Content-Type")
        request.httpBody = try? JSONSerialization.data(withJSONObject: body)
        
        do {
            let session = URLSession(configuration: config)
            let (data, response) = try await session.data(for: request)
            print("FETCHED DATA:++LL")
            dump(data)
            if let httpResponse = response as? HTTPURLResponse {
                if !(200...299).contains(httpResponse.statusCode) {
                    isLoading = false
                    var apiMessage = "Something went wrong"
                    print("❌ HTTP Error:", httpResponse.statusCode)
                    print(String(data: data, encoding: .utf8) ?? "")
                    if let json = try? JSONSerialization.jsonObject(with: data) as? [String: Any],
                       let error = json["error"] as? [String: Any],
                       let message = error["message"] as? String {
                        apiMessage = message
                    }
                    DispatchQueue.main.async {
                        
                        var errorCode = "Error Code: \(httpResponse.statusCode) \n"
                        var errorMessage = errorCode + apiMessage
                    }
                    return
                }
            }
            if let text = parseGeminiResponse(data: data) {
                print("Enter to parse")
                await parseTestScenarios(text)
            }
            isLoading = false
            
            
            
        } catch {
            print("Error:", error)
        }
    }
    func parseTestScenarios(_ jsonString: String) async {
        print("Inside parse testcases##$$")
        
        let cleaned = jsonString
            .replacingOccurrences(of: "```json", with: "")
            .replacingOccurrences(of: "```", with: "")
            .trimmingCharacters(in: .whitespacesAndNewlines)
        
        guard let data = cleaned.data(using: .utf8),
              let decoded = try? JSONDecoder().decode([TestCase].self, from: data) else {
            print("Decode failed")
            return
        }
        
        DispatchQueue.main.async {
            print("added testcases##$$")
            self.testCases = decoded
            print("ROW#::")
            print(self.testCases.count)
            self.exportCSV()
        }
    }
    func escapeCSV(_ text: String) -> String {
        var escaped = text.replacingOccurrences(of: "\"", with: "\"\"")
        return "\"\(escaped)\""
    }
    
    func exportCSV() {
        var csv = "Test Case ID,Test Scenario,Test Steps,Expected Result,Polarity\n"
        print("ROW#::ExportCSSVV--")
        print(self.testCases.count)
        var testNo: String = ""
        var testSerial: String = ""
        var count: Int = 000
        for test in testCases {
            count += 1
            testNo = String(format: "TC_%03d", count)
            testSerial = testNo + "\n"
            let testSerialFormatted = testSerial.replacingOccurrences(of: "\n", with: "\r\n")
            let testSerial = escapeCSV(testSerialFormatted)
            let title = escapeCSV(test.title)
            
            let stepsFormatted = test.steps.replacingOccurrences(of: "\n", with: "\r\n")
            let expectedFormatted = test.expectedResult.replacingOccurrences(of: "\n", with: "\r\n")
            
            let steps = escapeCSV(stepsFormatted)
            let expected = escapeCSV(expectedFormatted)
            let type = escapeCSV(test.type)
            
            csv += "\(testSerial),\(title),\(steps),\(expected),\(type)\n"
        }
        
        let savePanel = NSSavePanel()
        savePanel.nameFieldStringValue = "TestCases.csv"
        
        if savePanel.runModal() == .OK {
            do {
                try csv.write(to: savePanel.url!, atomically: true, encoding: .utf8)
            } catch {
                print("❌ Failed to save CSV:", error)
            }
        }
    }
}

// MARK: - Multi-Flow Suite Card View

struct MultiFlowCardView: View {
    let index: Int
    @Binding var testCase: EditableMultiFlowCase
    /// Removes this card from the parent's multiFlowCases array.
    /// Defaulted to a no-op so existing callers that don't pass it still compile.
    var onDelete: () -> Void = {}

    var body: some View {
        VStack(alignment: .leading, spacing: 8) {
            HStack(spacing: 8) {
                Text(String(format: "TC_%03d", index))
                    .font(.custom("Roboto-Bold", size: 13))
                    .foregroundStyle(.secondary)
                Spacer()
                Text(testCase.type.uppercased())
                    .font(.custom("Roboto-Bold", size: 11))
                    .padding(.horizontal, 8)
                    .padding(.vertical, 3)
                    .background(typeBadgeColor.opacity(0.18))
                    .foregroundStyle(typeBadgeColor)
                    .clipShape(Capsule())
                Button(action: onDelete) {
                    Image(systemName: "xmark.circle.fill")
                        .font(.system(size: 16))
                        .foregroundStyle(.secondary)
                        .symbolRenderingMode(.hierarchical)
                }
                .buttonStyle(.plain)
                .help("Remove this test case")
            }

            Text(testCase.title)
                .font(.custom("Roboto-Bold", size: 13))
                .lineLimit(2)
                .frame(maxWidth: .infinity, alignment: .leading)

            Text("DSL Steps (editable)")
                .font(.custom("Roboto-Regular", size: 10))
                .foregroundStyle(.secondary)

            TextEditor(text: $testCase.steps)
                .font(.system(.caption, design: .monospaced))
                .frame(minHeight: 140)
                .padding(6)
                .background(
                    RoundedRectangle(cornerRadius: 8)
                        .fill(Color(NSColor.textBackgroundColor))
                )
                .overlay(
                    RoundedRectangle(cornerRadius: 8)
                        .stroke(Color.secondary.opacity(0.25), lineWidth: 1)
                )

            VStack(alignment: .leading, spacing: 2) {
                Text("Expected")
                    .font(.custom("Roboto-Regular", size: 10))
                    .foregroundStyle(.secondary)
                Text(testCase.expectedResult)
                    .font(.custom("Roboto-Regular", size: 11))
                    .foregroundStyle(.primary.opacity(0.85))
                    .lineLimit(3)
            }
        }
        .padding(12)
        .frame(width: 320)
        .background(
            RoundedRectangle(cornerRadius: 12)
                .fill(Color(NSColor.windowBackgroundColor))
        )
        .overlay(
            RoundedRectangle(cornerRadius: 12)
                .stroke(Color.secondary.opacity(0.15), lineWidth: 1)
        )
    }

    private var typeBadgeColor: Color {
        switch testCase.type.lowercased() {
        case "positive": return .green
        case "negative": return .red
        case "edge":     return .orange
        default:         return .gray
        }
    }
}


