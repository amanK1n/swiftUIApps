//
//  TestDataVaultView.swift
//  AIQATestRunner
//
//  Created by Sayed on 16/05/26.
//
//  Visual editor for ~/Desktop/e2e/test-data.json. Sidebar lists modules,
//  the main panel exposes two tables for the selected module:
//   • Data       — key/value rows the AI uses as ${module.key} placeholders
//                  for POSITIVE flow inputs.
//   • Assertions — scenario_id + type + value rows the AI uses verbatim for
//                  NEGATIVE / EDGE assertions.
//
//  The view binds to a *draft* copy of the vault so edits are debounced and
//  only land on disk when the user clicks Save (or when the JSON is written
//  back silently from the YAML transpiler — that path bypasses this view
//  and the FolderWatcher in VaultManager picks it up automatically).
//

import SwiftUI
import AppKit

struct TestDataVaultView: View {
    @StateObject private var manager = VaultManager.shared

    @State private var draft: Vault = Vault()
    @State private var selectedModule: String? = nil
    @State private var newModuleName: String = ""
    @State private var hasUnsavedChanges: Bool = false

    @Environment(\.dismiss) private var dismiss

    var body: some View {
        VStack(spacing: 0) {
            header
            Divider()
            HStack(spacing: 0) {
                sidebar
                    .frame(width: 240)
                Divider()
                editor
                    .frame(maxWidth: .infinity, maxHeight: .infinity)
            }
            Divider()
            footer
        }
        .frame(minWidth: 880, minHeight: 600)
        .onAppear {
            draft = manager.vault
            selectedModule = draft.modules.keys.sorted().first
        }
        // External edits (silent write-back from transpiler, or hand-edited
        // JSON) reload the draft as long as the user hasn't started typing.
        .onReceive(manager.$vault) { newValue in
            if !hasUnsavedChanges {
                draft = newValue
            }
        }
    }

    // MARK: - Header

    private var header: some View {
        HStack(spacing: 12) {
            Image(systemName: "tablecells.badge.ellipsis")
                .font(.system(size: 22, weight: .semibold))
                .foregroundStyle(Color.accentColor)
            VStack(alignment: .leading, spacing: 2) {
                Text("Test Data Vault")
                    .font(.custom("Roboto-Bold", size: 18))
                Text(manager.fileURL?.path ?? "No active workspace")
                    .font(.system(size: 10, design: .monospaced))
                    .foregroundStyle(.secondary)
                    .lineLimit(1)
                    .truncationMode(.middle)
            }
            Spacer()
            if hasUnsavedChanges {
                Label("Unsaved changes", systemImage: "circle.fill")
                    .labelStyle(.titleAndIcon)
                    .font(.system(size: 11, weight: .semibold))
                    .foregroundStyle(.orange)
            }
            Button {
                if let url = manager.fileURL {
                    NSWorkspace.shared.activateFileViewerSelecting([url])
                }
            } label: {
                Label("Reveal in Finder", systemImage: "folder")
            }
            .controlSize(.small)
            .disabled(manager.fileURL == nil)
            Button {
                dismiss()
            } label: {
                Label("Close", systemImage: "xmark")
            }
            .controlSize(.small)
        }
        .padding(EdgeInsets(top: 14, leading: 20, bottom: 12, trailing: 16))
    }

    // MARK: - Sidebar

    private var sidebar: some View {
        VStack(alignment: .leading, spacing: 0) {
            HStack {
                Text("MODULES")
                    .font(.system(size: 10, weight: .bold))
                    .tracking(0.6)
                    .foregroundStyle(.secondary)
                Spacer()
                Text("\(draft.modules.count)")
                    .font(.system(size: 11, weight: .semibold))
                    .foregroundStyle(.secondary)
            }
            .padding(.horizontal, 14)
            .padding(.top, 14)
            .padding(.bottom, 6)

            ScrollView {
                LazyVStack(alignment: .leading, spacing: 2) {
                    ForEach(draft.modules.keys.sorted(), id: \.self) { name in
                        sidebarRow(name: name)
                    }
                }
                .padding(.horizontal, 8)
            }

            Divider()

            VStack(alignment: .leading, spacing: 6) {
                TextField("e.g. send_money", text: $newModuleName)
                    .textFieldStyle(.roundedBorder)
                    .onSubmit { addModule() }
                Button {
                    addModule()
                } label: {
                    Label("Add Module", systemImage: "plus.circle.fill")
                        .frame(maxWidth: .infinity)
                }
                .controlSize(.regular)
                .buttonStyle(.borderedProminent)
                .disabled(!canAddModule)
            }
            .padding(12)
        }
        .background(Color(NSColor.windowBackgroundColor).opacity(0.6))
    }

    private func sidebarRow(name: String) -> some View {
        let isSelected = selectedModule == name
        return Button {
            selectedModule = name
        } label: {
            HStack(spacing: 8) {
                Image(systemName: isSelected ? "square.fill" : "square")
                    .font(.system(size: 10))
                    .foregroundStyle(isSelected ? Color.accentColor : Color.secondary)
                Text(name)
                    .font(.system(size: 13, weight: isSelected ? .semibold : .regular))
                    .lineLimit(1)
                Spacer()
                Text("\(draft.modules[name]?.data.count ?? 0)·\(draft.modules[name]?.assertions.count ?? 0)")
                    .font(.system(size: 10, design: .monospaced))
                    .foregroundStyle(.secondary)
            }
            .contentShape(Rectangle())
            .padding(.horizontal, 8)
            .padding(.vertical, 6)
            .background(
                RoundedRectangle(cornerRadius: 6)
                    .fill(isSelected ? Color.accentColor.opacity(0.14) : Color.clear)
            )
        }
        .buttonStyle(.plain)
        .contextMenu {
            Button(role: .destructive) {
                deleteModule(name)
            } label: {
                Label("Delete '\(name)'", systemImage: "trash")
            }
        }
    }

    // MARK: - Editor

    private var editor: some View {
        Group {
            if let slug = selectedModule, draft.modules[slug] != nil {
                moduleEditor(slug: slug)
            } else {
                emptyState
            }
        }
    }

    private var emptyState: some View {
        VStack(spacing: 12) {
            Spacer()
            Image(systemName: "tray")
                .font(.system(size: 40))
                .foregroundStyle(.secondary)
            Text("No module selected")
                .font(.system(size: 14, weight: .semibold))
            Text("Pick a module from the sidebar, or add a new one. An empty vault is fine — the AI will inline literal values.")
                .font(.system(size: 12))
                .multilineTextAlignment(.center)
                .foregroundStyle(.secondary)
                .frame(maxWidth: 380)
            Spacer()
        }
        .frame(maxWidth: .infinity, maxHeight: .infinity)
    }

    private func moduleEditor(slug: String) -> some View {
        ScrollView {
            VStack(alignment: .leading, spacing: 20) {
                // Section header — module name
                HStack(spacing: 10) {
                    Image(systemName: "puzzlepiece.extension.fill")
                        .foregroundStyle(Color.accentColor)
                    Text(slug)
                        .font(.custom("Roboto-Bold", size: 18))
                    Spacer()
                }

                // Data table
                groupCard(title: "Test Data — used for POSITIVE flows", icon: "keyboard") {
                    VStack(spacing: 6) {
                        // Header row
                        HStack(spacing: 8) {
                            Text("KEY").headerCellStyle().frame(width: 200, alignment: .leading)
                            Text("VALUE").headerCellStyle().frame(maxWidth: .infinity, alignment: .leading)
                            Text("").frame(width: 22)
                        }
                        if draft.modules[slug]?.data.isEmpty ?? true {
                            emptyRow(text: "No data fields yet.")
                        } else {
                            ForEach(sortedKeys(of: draft.modules[slug]?.data ?? [:]), id: \.self) { key in
                                dataRow(slug: slug, key: key)
                            }
                        }
                        Button {
                            addDataField(slug: slug)
                        } label: {
                            Label("Add Field", systemImage: "plus")
                        }
                        .controlSize(.small)
                        .padding(.top, 4)
                    }
                }

                // Assertions table
                groupCard(title: "Assertions — used for NEGATIVE / EDGE flows", icon: "exclamationmark.bubble") {
                    VStack(spacing: 6) {
                        HStack(spacing: 8) {
                            Text("SCENARIO_ID").headerCellStyle().frame(width: 200, alignment: .leading)
                            Text("TYPE").headerCellStyle().frame(width: 130, alignment: .leading)
                            Text("VALUE").headerCellStyle().frame(maxWidth: .infinity, alignment: .leading)
                            Text("").frame(width: 22)
                        }
                        if draft.modules[slug]?.assertions.isEmpty ?? true {
                            emptyRow(text: "No assertions yet. Add scenarios for negative/edge error states.")
                        } else {
                            ForEach(sortedKeys(of: draft.modules[slug]?.assertions ?? [:]), id: \.self) { scenarioId in
                                assertionRow(slug: slug, scenarioId: scenarioId)
                            }
                        }
                        Button {
                            addAssertion(slug: slug)
                        } label: {
                            Label("Add Scenario", systemImage: "plus")
                        }
                        .controlSize(.small)
                        .padding(.top, 4)
                    }
                }
            }
            .padding(20)
        }
    }

    // MARK: - Row builders

    private func dataRow(slug: String, key: String) -> some View {
        let valueBinding = Binding<String>(
            get: { draft.modules[slug]?.data[key] ?? "" },
            set: { newValue in
                draft.modules[slug]?.data[key] = newValue
                hasUnsavedChanges = true
            }
        )
        return HStack(spacing: 8) {
            EditableKeyCell(
                currentKey: key,
                isAllowedKey: { candidate in
                    if candidate == key { return true }
                    return draft.modules[slug]?.data[candidate] == nil
                },
                onCommit: { newKey in
                    renameDataKeyInline(slug: slug, oldKey: key, newKey: newKey)
                }
            )
            .frame(width: 200)

            TextField("", text: valueBinding)
                .textFieldStyle(.roundedBorder)
                .frame(maxWidth: .infinity)

            Button {
                deleteDataKey(slug: slug, key: key)
            } label: {
                Image(systemName: "minus.circle")
                    .foregroundStyle(.secondary)
            }
            .buttonStyle(.plain)
            .frame(width: 22)
        }
    }

    private func assertionRow(slug: String, scenarioId: String) -> some View {
        let current = draft.modules[slug]?.assertions[scenarioId] ?? VaultAssertion(type: .toast, value: "")
        let typeBinding = Binding<VaultAssertionType>(
            get: { current.type },
            set: { newType in
                draft.modules[slug]?.assertions[scenarioId]?.type = newType
                hasUnsavedChanges = true
            }
        )
        let valueBinding = Binding<String>(
            get: { current.value },
            set: { newValue in
                draft.modules[slug]?.assertions[scenarioId]?.value = newValue
                hasUnsavedChanges = true
            }
        )

        return HStack(spacing: 8) {
            EditableKeyCell(
                currentKey: scenarioId,
                isAllowedKey: { candidate in
                    if candidate == scenarioId { return true }
                    return draft.modules[slug]?.assertions[candidate] == nil
                },
                onCommit: { newId in
                    renameScenarioInline(slug: slug, oldId: scenarioId, newId: newId)
                }
            )
            .frame(width: 200)

            Picker("", selection: typeBinding) {
                ForEach(VaultAssertionType.allCases) { t in
                    Text(t.rawValue).tag(t)
                }
            }
            .labelsHidden()
            .frame(width: 130)

            TextField(current.type == .toast ? "Expected toast text" : "Screen marker (e.g. Sign In)",
                      text: valueBinding)
                .textFieldStyle(.roundedBorder)
                .frame(maxWidth: .infinity)

            Button {
                deleteScenario(slug: slug, scenarioId: scenarioId)
            } label: {
                Image(systemName: "minus.circle")
                    .foregroundStyle(.secondary)
            }
            .buttonStyle(.plain)
            .frame(width: 22)
        }
    }

    private func emptyRow(text: String) -> some View {
        HStack {
            Text(text)
                .font(.system(size: 12))
                .foregroundStyle(.secondary)
                .padding(.vertical, 6)
            Spacer()
        }
    }

    private func groupCard<Content: View>(title: String,
                                          icon: String,
                                          @ViewBuilder content: () -> Content) -> some View {
        VStack(alignment: .leading, spacing: 12) {
            HStack(spacing: 8) {
                Image(systemName: icon)
                    .font(.system(size: 12, weight: .semibold))
                    .foregroundStyle(Color.accentColor)
                Text(title)
                    .font(.system(size: 13, weight: .bold))
                Spacer()
            }
            content()
        }
        .padding(14)
        .background(
            RoundedRectangle(cornerRadius: 10)
                .fill(Color(NSColor.windowBackgroundColor))
        )
        .overlay(
            RoundedRectangle(cornerRadius: 10)
                .strokeBorder(Color.secondary.opacity(0.14), lineWidth: 1)
        )
    }

    // MARK: - Footer

    private var footer: some View {
        HStack(spacing: 10) {
            Text("Empty vault is fine. Populate fields to enable placeholders.")
                .font(.system(size: 11))
                .foregroundStyle(.secondary)
            Spacer()
            Button {
                draft = manager.vault
                hasUnsavedChanges = false
            } label: {
                Label("Discard", systemImage: "arrow.uturn.backward")
            }
            .disabled(!hasUnsavedChanges)

            Button {
                manager.save(draft)
                hasUnsavedChanges = false
            } label: {
                Label("Save", systemImage: "tray.and.arrow.down")
            }
            .buttonStyle(.borderedProminent)
            .disabled(!hasUnsavedChanges)
        }
        .padding(EdgeInsets(top: 10, leading: 16, bottom: 12, trailing: 16))
    }

    // MARK: - Mutations

    private var canAddModule: Bool {
        let slug = vaultSlug(newModuleName)
        return !slug.isEmpty && draft.modules[slug] == nil
    }

    private func addModule() {
        let slug = vaultSlug(newModuleName)
        guard !slug.isEmpty, draft.modules[slug] == nil else { return }
        draft.modules[slug] = VaultModule()
        selectedModule = slug
        newModuleName = ""
        hasUnsavedChanges = true
    }

    private func deleteModule(_ name: String) {
        draft.modules.removeValue(forKey: name)
        if selectedModule == name {
            selectedModule = draft.modules.keys.sorted().first
        }
        hasUnsavedChanges = true
    }

    private func addDataField(slug: String) {
        guard var module = draft.modules[slug] else { return }
        let newKey = uniqueKey(base: "field", existing: Array(module.data.keys))
        module.data[newKey] = ""
        draft.modules[slug] = module
        hasUnsavedChanges = true
    }

    private func deleteDataKey(slug: String, key: String) {
        draft.modules[slug]?.data.removeValue(forKey: key)
        hasUnsavedChanges = true
    }

    /// Inline rename for data keys — called by EditableKeyCell on commit.
    /// Caller has already validated uniqueness and non-emptiness, so this just
    /// swaps the dictionary entry while preserving the value.
    private func renameDataKeyInline(slug: String, oldKey: String, newKey: String) {
        guard var module = draft.modules[slug] else { return }
        guard let value = module.data.removeValue(forKey: oldKey) else { return }
        module.data[newKey] = value
        draft.modules[slug] = module
        hasUnsavedChanges = true
    }

    private func addAssertion(slug: String) {
        guard var module = draft.modules[slug] else { return }
        let newId = uniqueKey(base: "scenario", existing: Array(module.assertions.keys))
        module.assertions[newId] = VaultAssertion(type: .toast, value: "")
        draft.modules[slug] = module
        hasUnsavedChanges = true
    }

    private func deleteScenario(slug: String, scenarioId: String) {
        draft.modules[slug]?.assertions.removeValue(forKey: scenarioId)
        hasUnsavedChanges = true
    }

    /// Inline rename for scenario_ids — called by EditableKeyCell on commit.
    private func renameScenarioInline(slug: String, oldId: String, newId: String) {
        guard var module = draft.modules[slug] else { return }
        guard let assertion = module.assertions.removeValue(forKey: oldId) else { return }
        module.assertions[newId] = assertion
        draft.modules[slug] = module
        hasUnsavedChanges = true
    }

    // MARK: - Helpers

    private func sortedKeys<V>(of dict: [String: V]) -> [String] {
        dict.keys.sorted()
    }

    private func uniqueKey(base: String, existing: [String]) -> String {
        if !existing.contains(base) { return base }
        var n = 2
        while existing.contains("\(base)_\(n)") { n += 1 }
        return "\(base)_\(n)"
    }
}

private extension Text {
    func headerCellStyle() -> some View {
        self
            .font(.system(size: 10, weight: .bold))
            .tracking(0.5)
            .foregroundStyle(.secondary)
    }
}

/// Inline-editable key cell used for both data keys and scenario_ids.
///
/// The cell renders a monospaced `TextField` bound to a local buffer so the
/// user can type freely without the underlying dictionary being thrashed on
/// every keystroke. The rename is committed only on Enter or focus-loss,
/// and only when the new value is:
///   - non-empty after slugification, AND
///   - either unchanged from the current key, OR not already in use
///     (validated by the parent via `isAllowedKey`).
///
/// On invalid input the buffer reverts to `currentKey` so the user never
/// ends up with a stuck partial state.
private struct EditableKeyCell: View {
    let currentKey: String
    let isAllowedKey: (String) -> Bool
    let onCommit: (String) -> Void

    @State private var buffer: String = ""
    @FocusState private var isFocused: Bool

    var body: some View {
        TextField("", text: $buffer)
            .font(.system(size: 12, design: .monospaced))
            .textFieldStyle(.roundedBorder)
            .focused($isFocused)
            .onAppear { buffer = currentKey }
            .onChange(of: currentKey) { newValue in
                // External rename (e.g. silent write-back) — keep buffer in
                // sync only when the user isn't actively typing here.
                if !isFocused { buffer = newValue }
            }
            .onSubmit { commit() }
            .onChange(of: isFocused) { focused in
                if !focused { commit() }
            }
    }

    private func commit() {
        let slug = vaultSlug(buffer)
        if slug == currentKey { return }
        guard !slug.isEmpty, isAllowedKey(slug) else {
            buffer = currentKey   // revert on empty / collision
            return
        }
        onCommit(slug)
    }
}
