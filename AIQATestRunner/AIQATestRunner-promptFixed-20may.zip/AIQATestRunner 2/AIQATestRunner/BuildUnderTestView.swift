//
//  BuildUnderTestView.swift
//  AIQATestRunner
//
//  The "App Under Test" card. Two visual states:
//
//   • Empty   — drop zone with browse button; prompts the user to drop an
//               .app/.ipa (iOS) or .apk (Android).
//   • Filled  — single-row card showing filename · bundle id · version ·
//               size · imported-when, plus three buttons:
//                   [Install on <Device>] · [Replace…] · [Remove]
//
//  Hidden when the active platform is Web (browsers don't take builds).
//
//  All disk I/O lives in BuildManager — this view just orchestrates the
//  drop/browse/confirm dialogs and renders the result.
//

import SwiftUI
import AppKit
import UniformTypeIdentifiers

struct BuildUnderTestView: View {
    @ObservedObject private var workspace = WorkspaceManager.shared
    @ObservedObject private var deviceManager = DeviceManager.shared
    @ObservedObject private var builds = BuildManager.shared

    @State private var isHoveringDrop = false
    @State private var pendingReplacementSource: URL? = nil
    @State private var pendingReplacementMetadata: BuildInfo? = nil
    @State private var bundleIdMismatch: BundleIdMismatch? = nil
    @State private var installOutput: String? = nil
    @State private var installSucceeded: Bool? = nil
    @State private var appIdAutoFillBanner: String? = nil

    /// Tracks in-flight install/boot work for the Install button. The
    /// view shows a spinner + dynamic label while this isn't `.idle`,
    /// and disables the button so a second click can't double-fire.
    @State private var installStage: InstallStageUIState = .idle

    /// UI-side mirror of BuildManager.InstallStage. We have our own
    /// enum (rather than reusing the model one directly) so SwiftUI can
    /// also represent the "idle" state cleanly.
    private enum InstallStageUIState: Equatable {
        case idle
        case booting(_ deviceDisplayName: String)
        case installing(_ deviceDisplayName: String)

        var isBusy: Bool {
            if case .idle = self { return false }
            return true
        }
    }

    /// Tracks a peeked replacement where the new build has a different
    /// bundle id than the existing one. Surfaced as a destructive alert.
    private struct BundleIdMismatch {
        let source: URL
        let oldBundleId: String
        let newBundleId: String
    }

    var body: some View {
        HStack(alignment: .top, spacing: 10) {
            VStack(alignment: .leading, spacing: 12) {
                HStack(spacing: 8) {
                    Text("App Under Test")
                        .font(builds.current != nil ? .custom("Inter-Bold", size: 14) : .custom("Inter-Bold", size: 16))
                        .foregroundStyle(builds.current != nil ? .gray : .black)
                    if let build = builds.current {
                        Text("·  \(build.platform.uppercased())")
                            .font(.custom("Inter-Regular", size: 11))
                            .fontWeight(.semibold)
                            .foregroundStyle(.secondary)
                    }
                   
                    Spacer()
                    if builds.current != nil {
                        // Platform wise icon placement top right corner of B-U-T card
                        let platform = workspace.activePlatform
                        if platform == .ios {
                            Image(systemName: "apple.logo")
                                .font(.system(size: 22))
                                .foregroundStyle(Color.black)
                        } else {
                            Image("android_icon")
                                .resizable()
                                .frame(width: 22, height: 22)
                        }

                    } else {
                        Button {
                            browseForBuild()
                        } label: {
                            Text("Drop / Upload")
                                .font(.custom("Inter", size: 10))
                                .fontWeight(.regular)
                                .foregroundColor(.white)
                                .padding(.horizontal, 10)
                                .padding(.vertical, 8)
                                .background(Color.red)
                                .clipShape(Capsule())
                        }.buttonStyle(.plain)
                    }
                    
                    
                }
               
                if let build = builds.current {
                    filledState(build: build)
                } else {
                    Divider()
                    emptyState
                }
                
                if let error = builds.lastImportError {
                    statusPill(text: error, color: .red, icon: "exclamationmark.triangle.fill")
                }
                if let banner = appIdAutoFillBanner {
                    statusPill(text: banner, color: .accentColor, icon: "wand.and.stars")
                }
                if let output = installOutput {
                    statusPill(
                        text: output,
                        color: installSucceeded == true ? .green : .red,
                        icon: installSucceeded == true ? "checkmark.circle.fill" : "exclamationmark.triangle.fill"
                    )
                }
               
            }
            .sectionCard()
            .frame(minWidth: 400, maxWidth: 400) // THIS FRAME IS BUILD UNDER TEST CARDDD
            // Replace-confirmation alert — same bundle id case.
            .alert(
                "Replace current build?",
                isPresented: Binding(
                    get: { pendingReplacementSource != nil && bundleIdMismatch == nil },
                    set: { if !$0 { clearPendingReplacement() } }
                )
            ) {
                Button("Cancel", role: .cancel) { clearPendingReplacement() }
                Button("Replace", role: .destructive) { confirmReplacement() }
            } message: {
                if let meta = pendingReplacementMetadata, let current = builds.current {
                    Text("\(current.filename) · v\(current.versionName) will be removed and replaced with \(meta.filename) · v\(meta.versionName).")
                } else {
                    Text("The current build will be removed and replaced.")
                }
            }
            // Bundle-id mismatch alert — destructive variant with extra context.
            .alert(
                "Different bundle id detected",
                isPresented: Binding(
                    get: { bundleIdMismatch != nil },
                    set: { if !$0 { bundleIdMismatch = nil; clearPendingReplacement() } }
                )
            ) {
                Button("Cancel", role: .cancel) {
                    bundleIdMismatch = nil
                    clearPendingReplacement()
                }
                Button("Replace anyway", role: .destructive) {
                    bundleIdMismatch = nil
                    confirmReplacement()
                }
            } message: {
                if let m = bundleIdMismatch {
                    Text("The new build's bundle id is \(m.newBundleId), which doesn't match the existing build's id \(m.oldBundleId). They are effectively two different apps. Your vault entries keyed on \(m.oldBundleId) would become orphaned.")
                }
            }
            
            // Badging
            Spacer()
            VStack(alignment: .trailing, spacing: 2) {
                Text("WELCOME TO CTA")
                    .font(.custom("Inter-Bold", size: 32))
                Text("                                    AI-Powered Intelligent Quality")
                    .font(.custom("Inter-Regular", size: 12))
                    .foregroundStyle(.primary)
                Text("Engineering for Faster, Smarter, and Autonomous Testing")
                    .font(.custom("Inter-Regular", size: 12))
                    .foregroundStyle(.primary)
                
                
            }.frame(maxWidth: 350)
        }
    }

    // MARK: Empty state

    private var emptyState: some View {
        let platform = workspace.activePlatform
        let accepted = acceptedTypesDescription(for: platform)

        return VStack(spacing: 12) {
            VStack(spacing: 10) {
//                Image(systemName: "arrow.down.doc")
//                    .font(.system(size: 28))
//                    .foregroundStyle(.secondary)
//                Text("Drop your \(accepted) here")
//                    .font(.custom("Roboto-Bold", size: 13))
//                Text("or click to browse")
//                    .font(.custom("Roboto-Regular", size: 11))
//                    .foregroundStyle(.secondary)
              
                HStack(spacing: 6) {
                    Image(systemName: "info.circle")
                        .foregroundStyle(.secondary)
                    Text("Accepted: \(accepted)")
                        .font(.custom("Roboto-Regular", size: 11))
                        .foregroundStyle(.secondary)
                    Spacer()
                }.padding(.top, -20)
            }
            .frame(maxWidth: .infinity)
            .padding(.vertical, 22)
            .background(
                RoundedRectangle(cornerRadius: 12)
                    .stroke(
                        isHoveringDrop ? Color.clear : Color.clear.opacity(0.35),
                        style: StrokeStyle(lineWidth: 1.5, dash: [6, 4])
                    )
            )
            .background(
                RoundedRectangle(cornerRadius: 12)
                    .fill(isHoveringDrop ? Color.red.opacity(0.06) : Color.clear)
            )
            .onTapGesture { browseForBuild() }
            .onDrop(of: [.fileURL], isTargeted: $isHoveringDrop) { providers in
                handleDrop(providers: providers)
            }

            
        }
    }

    // MARK: Filled state

    @ViewBuilder
    private func filledState(build: BuildInfo) -> some View {
        let platform = workspace.activePlatform
        let devices = deviceManager.devices(for: platform)
        let selectedDevice = deviceManager.selectedDevice(for: platform)
        let installDisabled = selectedDevice == nil || installStage.isBusy

        VStack(alignment: .leading, spacing: 10) {
            HStack(alignment: .top, spacing: 12) {
//                Image(systemName: platform == .ios ? "apple.logo" : "smartphone")
//                    .font(.system(size: 22))
//                    .foregroundStyle(Color.accentColor)

                VStack(alignment: .leading, spacing: 2) {
                    Text(build.filename)
                        .font(.custom("Roboto-Bold", size: 13))
                    HStack(spacing: 6) {
                        if !build.bundleId.isEmpty {
                            Text(build.bundleId)
                                .font(.system(size: 11, design: .monospaced))
                                .foregroundStyle(.secondary)
                            Text("·").foregroundStyle(.secondary)
                        }
                        Text("v\(build.versionName)\(build.versionCode.isEmpty ? "" : " (\(build.versionCode))")")
                            .font(.custom("Roboto-Regular", size: 11))
                            .foregroundStyle(.secondary)
                        Text("·").foregroundStyle(.secondary)
                        Text(build.humanSize)
                            .font(.custom("Roboto-Regular", size: 11))
                            .foregroundStyle(.secondary)
                    }
                    Text("Imported \(build.humanImportedAt)")
                        .font(.custom("Roboto-Regular", size: 10))
                        .foregroundStyle(.secondary)
                        .padding(.bottom, 10)
                    Divider()
                }

                Spacer()
            }

            // Inline device picker — same DeviceManager state as the
            // Action section, so changes here flow there and vice versa.
            // Lets the user retarget the install without scrolling.
            HStack(spacing: 8) {
                Text("Install onto:")
                    .font(.custom("Roboto-Regular", size: 12))
                    .foregroundStyle(.secondary)

                Menu {
                    if devices.isEmpty {
                        Button(deviceManager.error(for: platform) ?? "No devices found") {}.disabled(true)
                    } else {
                        ForEach(devices) { device in
                            Button {
                                deviceManager.select(device)
                            } label: {
                                if device.id == selectedDevice?.id {
                                    Label(device.displayName, systemImage: "checkmark")
                                } else {
                                    Text(device.displayName)
                                }
                            }
                            .help(device.tooltip)
                        }
                    }
                } label: {
                    Text(selectedDevice?.displayName ?? "Select a device")
                        .font(.custom("Roboto-Regular", size: 12))
                        .lineLimit(1)
                        .truncationMode(.middle)
                }
                .menuStyle(.borderlessButton)
                .frame(minWidth: 220, maxWidth: 320)
                .disabled(installStage.isBusy)

                Spacer()
            }
            // PRIMARY BOOT & INSTALL button of Build under test card
            HStack(spacing: 10) {
                Button {
                    installCurrentBuild()
                } label: {
                    HStack(spacing: 6) {
                        if installStage.isBusy {
                            ProgressView().controlSize(.small)
                        }
                        Text(installButtonLabel(
                            platform: platform,
                            device: selectedDevice,
                            stage: installStage
                        )).font(.custom("Inter-Bold", size: 12))
                            .fontWeight(.semibold)
                            .foregroundColor(.white)
                    }
                    .padding(.horizontal, 10)
                    .padding(.vertical, 7)
                    .background(Color.red)
                    .clipShape(Capsule())
                }
                .buttonStyle(.plain)
                .disabled(installDisabled)
                .help(installButtonHelp(
                    device: selectedDevice,
                    stage: installStage
                ))

                
                // REPLACE button of Build under test card
                Button {
                    browseForBuild()
                } label: {
                    Text("Replace")
                        .font(.custom("Inter-Bold", size: 12))
                        .fontWeight(.semibold)
                        .foregroundColor(.black)
                        .padding(.horizontal, 30)
                        .padding(.vertical, 7)
                        .background(Color.white)
                        .clipShape(Capsule())
                }.buttonStyle(.plain)
                .disabled(installStage.isBusy)
                .overlay(
                    RoundedRectangle(cornerRadius: 15)
                        .stroke(Color.black, lineWidth: 1)
                )

                
                // REMOVE button of Build under test card
                Button(role: .destructive) {
                    builds.removeCurrent()
                    installOutput = nil
                    appIdAutoFillBanner = nil
                } label: {
                    Text("Remove")
                        .font(.custom("Inter-Bold", size: 12))
                        .fontWeight(.semibold)
                        .foregroundColor(.black)
                        .padding(.horizontal, 30)
                        .padding(.vertical, 7)
                        .background(Color.white)
                        .clipShape(Capsule())
                }.buttonStyle(.plain)
                .disabled(installStage.isBusy)
                .overlay(
                    RoundedRectangle(cornerRadius: 15)
                        .stroke(Color.black, lineWidth: 1)
                )

                Spacer()
            }
            .onDrop(of: [.fileURL], isTargeted: nil) { providers in
                handleDrop(providers: providers)
            }
        }
    }

    // MARK: Drop / browse plumbing

    /// Opens a file panel scoped to the platform's accepted extensions.
    private func browseForBuild() {
        let panel = NSOpenPanel()
        panel.canChooseFiles = true
        panel.canChooseDirectories = workspace.activePlatform == .ios  // .app is a directory bundle
        panel.allowsMultipleSelection = false
        panel.allowedContentTypes = allowedContentTypes(for: workspace.activePlatform)
        panel.title = "Select build file"
        panel.prompt = "Select"
        if panel.runModal() == .OK, let url = panel.url {
            beginImport(from: url)
        }
    }

    /// Maps a dropped NSItemProvider list to a file URL and routes to
    /// `beginImport`. Returns true if the drop is accepted.
    private func handleDrop(providers: [NSItemProvider]) -> Bool {
        guard let provider = providers.first else { return false }
        provider.loadObject(ofClass: URL.self) { url, _ in
            guard let url else { return }
            DispatchQueue.main.async {
                beginImport(from: url)
            }
        }
        return true
    }

    /// Entry point for both browse and drop. Peeks metadata, then either
    /// commits straight away (no existing build) or routes through one of
    /// two confirmation alerts (same-id replace / different-id replace).
    private func beginImport(from source: URL) {
        builds.lastImportError = nil
        installOutput = nil
        appIdAutoFillBanner = nil

        let result = builds.peekMetadata(of: source, platform: workspace.activePlatform)
        switch result {
        case .failure(let err):
            builds.lastImportError = err.errorDescription
            return
        case .success(let peek):
            // First-time import: just commit.
            guard let existing = builds.current else {
                commitImport(source: source, peekedMetadata: peek.metadata)
                return
            }

            // Replace, same bundle id → simple "Replace?" alert.
            if existing.bundleId == peek.metadata.bundleId
                || peek.metadata.bundleId.isEmpty
                || existing.bundleId.isEmpty {
                pendingReplacementSource = source
                pendingReplacementMetadata = peek.metadata
                return
            }

            // Replace, different bundle id → louder warning.
            bundleIdMismatch = BundleIdMismatch(
                source: source,
                oldBundleId: existing.bundleId,
                newBundleId: peek.metadata.bundleId
            )
            pendingReplacementSource = source
            pendingReplacementMetadata = peek.metadata
        }
    }

    /// Called from both alert "Replace" buttons. Resolves to a single
    /// commit + post-import bookkeeping.
    private func confirmReplacement() {
        guard let source = pendingReplacementSource,
              let metadata = pendingReplacementMetadata else { return }
        commitImport(source: source, peekedMetadata: metadata)
        clearPendingReplacement()
    }

    private func clearPendingReplacement() {
        pendingReplacementSource = nil
        pendingReplacementMetadata = nil
    }

    /// Real import work: BuildManager.commitImport + AppId auto-fill /
    /// banner. Centralized so both alert paths and the first-time path
    /// run identical bookkeeping.
    private func commitImport(source: URL, peekedMetadata: BuildInfo) {
        let result = builds.commitImport(of: source, platform: workspace.activePlatform)
        switch result {
        case .failure(let err):
            builds.lastImportError = err.errorDescription
        case .success(let info):
            applyAppIdAutoFill(info: info)
        }
    }

    /// Updates the active app's manifest id with the parsed bundle id
    /// when it's non-empty. Shows a one-line banner explaining the
    /// change when the user had previously typed something different,
    /// so the auto-fill never feels invisible.
    private func applyAppIdAutoFill(info: BuildInfo) {
        guard !info.bundleId.isEmpty else { return }
        let oldId = workspace.currentAppId
        if oldId == info.bundleId { return }

        workspace.setActiveAppId(info.bundleId)
        if oldId.isEmpty {
            appIdAutoFillBanner = "AppId set from build: \(info.bundleId)"
        } else {
            appIdAutoFillBanner = "AppId updated from build: \(oldId) → \(info.bundleId)"
        }
    }

    // MARK: Install (boot + install pipeline)

    private func installCurrentBuild() {
        installOutput = nil
        installSucceeded = nil
        guard let device = deviceManager.selectedDevice(for: workspace.activePlatform) else {
            installOutput = "Pick a simulator first."
            installSucceeded = false
            return
        }

        // Optimistically reset to .idle in case the user retries after a
        // previous failure. The pipeline pushes its own stage updates.
        installStage = .idle

        builds.installCurrent(
            on: device,
            onProgress: { stage in
                switch stage {
                case .booting(let name):    installStage = .booting(name)
                case .installing(let name): installStage = .installing(name)
                }
            },
            completion: { success, output in
                installStage = .idle
                installSucceeded = success
                if success {
                    installOutput = "Installed onto \(stripStatusSuffix(device.displayName))."
                    // Re-scan devices so the picker's "(Booted)" /
                    // "(Running)" suffix updates after a cold boot.
                    deviceManager.refresh(for: workspace.activePlatform)
                } else {
                    let trimmed = output.trimmingCharacters(in: .whitespacesAndNewlines)
                    installOutput = trimmed.isEmpty
                        ? "Install failed."
                        : "Install failed. \(trimmed)"
                }
            }
        )
    }

    // MARK: Per-platform copy

    private func acceptedTypesDescription(for platform: Platform) -> String {
        switch platform {
        case .ios:     return ".app or .ipa"
        case .android: return ".apk"
        case .web:     return ""
        }
    }

    private func allowedContentTypes(for platform: Platform) -> [UTType] {
        switch platform {
        case .ios:
            // .app is a bundle (directory with .app extension); .ipa is a zip.
            // We accept both by extension since UTType doesn't have a builtin
            // for `.ipa`.
            let appType = UTType(filenameExtension: "app") ?? .bundle
            let ipaType = UTType(filenameExtension: "ipa") ?? .data
            return [appType, ipaType]
        case .android:
            let apkType = UTType(filenameExtension: "apk") ?? .data
            return [apkType]
        case .web:
            return []
        }
    }

    /// Builds the dynamic Install-button label, taking both device state
    /// and in-flight install stage into account.
    ///
    /// Examples:
    ///   • no device picked              → "Install on Simulator"
    ///   • booted sim                    → "Install on iPhone 16 Pro"
    ///   • shutdown sim                  → "Boot & Install on iPhone 16 Pro"
    ///   • physical / running Android    → "Install on Pixel 8"
    ///   • mid-boot                      → "Booting iPhone 16 Pro…"
    ///   • mid-install                   → "Installing on iPhone 16 Pro…"
    private func installButtonLabel(
        platform: Platform,
        device: DeviceInfo?,
        stage: InstallStageUIState
    ) -> String {
        switch stage {
        case .booting(let name):   return "Booting"// return "Booting \(name)…"
        case .installing(let name): return "Installing" //return "Installing on \(name)…"
        case .idle: break
        }

        guard let device else {
            return platform == .ios ? "Install on Simulator" : "Install on Device"
        }
        let trimmed = stripStatusSuffix(device.displayName)

        // Connected physical Android device — already on, just install.
        if device.isPhysical { return "Install" }// { return "Install on \(trimmed)" }
        // Sim is booted / AVD is running — single-step install.
        if device.isRunning  { return "Install" }//{ return "Install on \(trimmed)" }
        // Sim/AVD is dormant — we'll boot and then install. Tell the user.
        //return "Boot & Install on \(trimmed)"
        return "Boot &  Install"
    }

    private func installButtonHelp(
        device: DeviceInfo?,
        stage: InstallStageUIState
    ) -> String {
        if stage.isBusy { return "Working on it…" }
        guard let device else { return "Pick a simulator first." }
        if device.isPhysical { return "Install onto the connected device." }
        if device.isRunning  { return "Install onto the running device." }
        return "The selected device isn't booted yet. Clicking will boot it first, then install."
    }

    private func stripStatusSuffix(_ display: String) -> String {
        display
            .replacingOccurrences(of: " (Booted)", with: "")
            .replacingOccurrences(of: " (Running)", with: "")
            .replacingOccurrences(of: " (Connected)", with: "")
    }

    private func statusPill(text: String, color: Color, icon: String) -> some View {
        HStack(spacing: 8) {
            Image(systemName: icon).foregroundStyle(color)
            Text(text)
                .font(.custom("Roboto-Regular", size: 12))
                .foregroundStyle(color)
                .textSelection(.enabled)
                .lineLimit(3)
            Spacer()
        }
        .padding(.horizontal, 10)
        .padding(.vertical, 6)
        .background(
            RoundedRectangle(cornerRadius: 8).fill(color.opacity(0.08))
        )
    }
}
