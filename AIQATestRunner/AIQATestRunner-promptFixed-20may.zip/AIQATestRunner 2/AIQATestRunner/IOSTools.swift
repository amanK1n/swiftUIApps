//
//  IOSTools.swift
//  AIQATestRunner
//
//  iOS-side helpers for the build pipeline:
//    • Info.plist parsing (bundle id + versions)
//    • .ipa → .app unzip into a temp dir
//    • simctl install onto a chosen simulator
//
//  Why a separate file: UItilityExplorer.swift owns sim boot/run plumbing;
//  this file owns *build artefact* concerns. Keeping them separate makes
//  future Android/Web mirroring easier to spot.
//

import Foundation
import AppKit

enum IOSTools {

    // MARK: Info.plist parsing

    struct BundleMetadata {
        let bundleId: String
        let versionShort: String   // CFBundleShortVersionString — e.g. "1.4.2"
        let bundleVersion: String  // CFBundleVersion — e.g. "1042" (build number)
    }

    /// Reads `Info.plist` from a `.app` bundle directory and returns the
    /// fields we care about. Returns nil when the plist is missing or
    /// unparseable — the build importer treats that as a non-fatal error
    /// and falls back to filename-derived metadata.
    static func bundleMetadata(forApp appURL: URL) -> BundleMetadata? {
        let plistURL = appURL.appendingPathComponent("Info.plist")
        guard let data = try? Data(contentsOf: plistURL) else { return nil }
        guard let plist = try? PropertyListSerialization.propertyList(
            from: data, options: [], format: nil
        ) as? [String: Any] else { return nil }

        let bundleId = (plist["CFBundleIdentifier"] as? String) ?? ""
        let versionShort = (plist["CFBundleShortVersionString"] as? String) ?? ""
        let bundleVersion = (plist["CFBundleVersion"] as? String) ?? ""

        guard !bundleId.isEmpty else { return nil }
        return BundleMetadata(
            bundleId: bundleId,
            versionShort: versionShort,
            bundleVersion: bundleVersion
        )
    }

    // MARK: .ipa unzip

    /// Unzips the `Payload/<AppName>.app/` directory out of an `.ipa` into
    /// a fresh temp folder and returns the unpacked `.app` URL.
    ///
    /// We shell out to `/usr/bin/unzip` because Foundation has no zip
    /// support on macOS. The temp dir is the caller's responsibility to
    /// clean up — BuildManager moves the `.app` into the workspace and
    /// then `rm -rf`s the temp dir.
    static func unzipIPA(at ipaURL: URL) throws -> URL {
        let tempDir = URL(fileURLWithPath: NSTemporaryDirectory(), isDirectory: true)
            .appendingPathComponent("aiqa-ipa-\(UUID().uuidString)", isDirectory: true)
        try FileManager.default.createDirectory(at: tempDir, withIntermediateDirectories: true)

        let task = Process()
        task.launchPath = "/usr/bin/unzip"
        task.arguments = ["-q", ipaURL.path, "-d", tempDir.path]
        let pipe = Pipe()
        task.standardOutput = pipe
        task.standardError = pipe
        try task.run()
        task.waitUntilExit()

        guard task.terminationStatus == 0 else {
            let err = String(data: pipe.fileHandleForReading.readDataToEndOfFile(),
                             encoding: .utf8) ?? ""
            throw NSError(
                domain: "AIQAIPAUnzip",
                code: Int(task.terminationStatus),
                userInfo: [NSLocalizedDescriptionKey: err.isEmpty ? "unzip failed" : err]
            )
        }

        // Find the .app inside Payload/. Typical layout:
        //   Payload/MyApp.app/...
        let payload = tempDir.appendingPathComponent("Payload", isDirectory: true)
        let entries = (try? FileManager.default.contentsOfDirectory(
            at: payload,
            includingPropertiesForKeys: nil,
            options: [.skipsHiddenFiles]
        )) ?? []
        guard let appURL = entries.first(where: { $0.pathExtension.lowercased() == "app" }) else {
            // Cleanup the failed extraction so we don't leak temp folders.
            try? FileManager.default.removeItem(at: tempDir)
            throw NSError(
                domain: "AIQAIPAUnzip",
                code: -1,
                userInfo: [NSLocalizedDescriptionKey: "No .app bundle found inside Payload/"]
            )
        }
        return appURL
    }

    // MARK: Boot & wait

    /// Boots the given simulator UDID and blocks until it reports a
    /// fully-completed boot state (i.e. `simctl install` will succeed).
    ///
    /// Implementation: `simctl boot` returns immediately even though the
    /// simulator isn't ready yet. The canonical way to wait for readiness
    /// is `simctl bootstatus <udid> -b`, which blocks until the device's
    /// boot status is "Booted" and prints stage transitions on stdout.
    ///
    /// We treat "already booted" (exit code 149 from `simctl boot`) as
    /// success and skip straight to the bootstatus check.
    static func bootAndWaitReady(udid: String, timeoutSeconds: Int = 120)
        -> (success: Bool, output: String)
    {
        // Kick off the boot. Ignore exit code — if it's already booted
        // simctl prints "Unable to boot device in current state: Booted"
        // and exits non-zero, which is exactly what we want.
        let bootTask = Process()
        bootTask.launchPath = "/usr/bin/xcrun"
        bootTask.arguments = ["simctl", "boot", udid]
        bootTask.standardOutput = Pipe()
        bootTask.standardError = Pipe()
        try? bootTask.run()
        bootTask.waitUntilExit()

        // Block until the device is fully booted (bootstatus). The `-b`
        // flag means "block"; `simctl bootstatus` would otherwise just
        // print the current status and exit.
        let waitTask = Process()
        waitTask.launchPath = "/usr/bin/xcrun"
        waitTask.arguments = ["simctl", "bootstatus", udid, "-b"]
        let pipe = Pipe()
        waitTask.standardOutput = pipe
        waitTask.standardError = pipe
        do {
            try waitTask.run()
        } catch {
            return (false, "Failed to invoke bootstatus: \(error.localizedDescription)")
        }

        // Manual timeout: bootstatus has no built-in timeout, and a stuck
        // simulator would otherwise wedge the UI thread that called us.
        let deadline = Date().addingTimeInterval(TimeInterval(timeoutSeconds))
        while waitTask.isRunning {
            if Date() > deadline {
                waitTask.terminate()
                return (false, "Boot timed out after \(timeoutSeconds)s")
            }
            Thread.sleep(forTimeInterval: 0.5)
        }

        let output = String(data: pipe.fileHandleForReading.readDataToEndOfFile(),
                            encoding: .utf8) ?? ""

        // Bring the Simulator app window to front so the user can see
        // what they just booted, mirroring the manual Boot button.
        openSimulatorApp()

        return (waitTask.terminationStatus == 0, output)
    }

    // MARK: simctl install

    /// Installs the given `.app` bundle onto the simulator with the given
    /// UDID via `xcrun simctl install`. Same bundle id is upserted in
    /// place (the previous installation is replaced — data sandbox is
    /// preserved by Apple's simctl semantics).
    ///
    /// Returns the combined stdout+stderr for the UI to surface on failure.
    static func installApp(at appURL: URL, onUDID udid: String) -> (success: Bool, output: String) {
        let task = Process()
        task.launchPath = "/usr/bin/xcrun"
        task.arguments = ["simctl", "install", udid, appURL.path]
        let pipe = Pipe()
        task.standardOutput = pipe
        task.standardError = pipe
        do {
            try task.run()
            task.waitUntilExit()
        } catch {
            return (false, "Failed to run xcrun: \(error.localizedDescription)")
        }
        let output = String(data: pipe.fileHandleForReading.readDataToEndOfFile(),
                            encoding: .utf8) ?? ""
        return (task.terminationStatus == 0, output)
    }

    // MARK: Pre-grant privacy services

    /// Pre-grants every privacy service simctl supports (camera, photos,
    /// contacts, microphone, location, motion, calendars, reminders, etc.)
    /// for `bundleId` on the given simulator. Equivalent to the user
    /// tapping "Allow" on every TCC dialog before it ever appears.
    ///
    /// Run this once after `installApp` succeeds. It's idempotent —
    /// granting an already-granted service is a no-op.
    ///
    /// Caveats:
    /// • simctl does NOT cover notifications or App Tracking Transparency
    ///   (Apple didn't ship a TCC service for either). Those still need
    ///   the in-flow dismissal that Layer 2 (staging-time injection)
    ///   provides.
    /// • Requires the simulator to be booted (which it is by the time
    ///   `installApp` returns successfully). Calling on a Shutdown sim
    ///   prints an error and exits non-zero, which we treat as a
    ///   non-fatal log line.
    @discardableResult
    static func grantAllPrivacy(udid: String, bundleId: String) -> (success: Bool, output: String) {
        let task = Process()
        task.launchPath = "/usr/bin/xcrun"
        task.arguments = ["simctl", "privacy", udid, "grant", "all", bundleId]
        let pipe = Pipe()
        task.standardOutput = pipe
        task.standardError = pipe
        do {
            try task.run()
            task.waitUntilExit()
        } catch {
            return (false, "Failed to run xcrun: \(error.localizedDescription)")
        }
        let output = String(data: pipe.fileHandleForReading.readDataToEndOfFile(),
                            encoding: .utf8) ?? ""
        return (task.terminationStatus == 0, output)
    }
}
