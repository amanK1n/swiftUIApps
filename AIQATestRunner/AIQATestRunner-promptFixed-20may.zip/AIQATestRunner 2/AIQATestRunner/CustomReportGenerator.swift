//
//  CustomReportGenerator.swift
//  AIQATestRunner
//
//  Created by Sayed on 14/05/26.
//
//  Parses the maestro html-detailed report (~/Desktop/e2e/build/report.html)
//  and renders a richer custom report at ~/Desktop/e2e/build/aiqa-report.html
//  with a project header (project name / app type / features), a 4-card
//  type-wise summary (positive/negative/edge/total → passed & failed) and
//  a module-wise detailed section grouped by feature.
//

import Foundation
import AppKit

// MARK: - Models

struct ReportStep {
    let symbol: String        // ✅ / ❌ / 🟡 or others
    let name: String          // already HTML-encoded by maestro
    let duration: String
    var isFailed: Bool { symbol.contains("❌") }
}

struct ReportFlow {
    let rawName: String       // may include a staging order prefix, e.g. "010_TC_001_login_positive_valid_login"
    let status: String        // "SUCCESS" / "FAILURE"
    let duration: String
    let fileName: String
    let steps: [ReportStep]

    var serial: String { extractSerial() }
    var feature: String { extractFeature() }
    var displayFeature: String { humanize(feature) }
    var type: String { extractType() }
    var displayTitle: String { extractDisplayTitle() }
    var cleanFileName: String { stripPrefix(fileName) }
    var isPassed: Bool { status.uppercased() == "SUCCESS" }

    // Strips the leading staging-order prefix (e.g. "010_") if present, so
    // the parser sees the underlying TC_<NNN>_<feature>_<type>_<title>.
    private func cleanedParts() -> [Substring] {
        var parts = rawName.split(separator: "_")
        if let first = parts.first, !first.isEmpty, first.allSatisfy(\.isNumber), parts.count > 1 {
            parts = Array(parts.dropFirst())
        }
        return parts
    }

    private func stripPrefix(_ s: String) -> String {
        var parts = s.split(separator: "_")
        if let first = parts.first, !first.isEmpty, first.allSatisfy(\.isNumber), parts.count > 1 {
            parts = Array(parts.dropFirst())
        }
        return parts.joined(separator: "_")
    }

    private func extractSerial() -> String {
        let parts = cleanedParts()
        if parts.count >= 2, parts[0] == "TC" {
            return "TC_\(parts[1])"
        }
        return rawName
    }

    private func extractFeature() -> String {
        let parts = cleanedParts()
        return parts.count >= 3 ? String(parts[2]) : "unknown"
    }

    private func extractType() -> String {
        let parts = cleanedParts()
        guard parts.count >= 4 else { return "unknown" }
        let candidate = String(parts[3]).lowercased()
        if ["positive", "negative", "edge"].contains(candidate) {
            return candidate
        }
        return "unknown"
    }

    private func extractDisplayTitle() -> String {
        let parts = cleanedParts()
        guard parts.count >= 5 else { return rawName }
        let titleParts = parts.dropFirst(4)
        return titleParts.joined(separator: " ").capitalized
    }

    private func humanize(_ slug: String) -> String {
        slug.replacingOccurrences(of: "_", with: " ")
            .split(separator: " ")
            .map { $0.prefix(1).uppercased() + $0.dropFirst() }
            .joined(separator: " ")
    }
}

struct ReportSummary {
    let projectName: String
    let appType: String
    let totalFlows: Int
    let passedFlows: Int
    let failedFlows: Int
    let overallStatus: String
    let overallDuration: String
    let flows: [ReportFlow]

    // Unique features preserved in first-encounter order.
    var features: [String] {
        var seen = Set<String>()
        var ordered: [String] = []
        for flow in flows where !seen.contains(flow.feature) {
            seen.insert(flow.feature)
            ordered.append(flow.feature)
        }
        return ordered
    }

    var displayFeatures: [String] {
        features.map { slug in
            slug.replacingOccurrences(of: "_", with: " ")
                .split(separator: " ")
                .map { $0.prefix(1).uppercased() + $0.dropFirst() }
                .joined(separator: " ")
        }
    }

    func count(of type: String) -> Int  { flows.filter { $0.type == type }.count }
    func passed(of type: String) -> Int { flows.filter { $0.type == type && $0.isPassed }.count }
    func failed(of type: String) -> Int { flows.filter { $0.type == type && !$0.isPassed }.count }

    // Flows grouped by feature, in first-encounter order, sorted by serial.
    var flowsByFeature: [(slug: String, display: String, flows: [ReportFlow])] {
        features.map { slug in
            let group = flows
                .filter { $0.feature == slug }
                .sorted { $0.rawName < $1.rawName }
            let display = slug
                .replacingOccurrences(of: "_", with: " ")
                .split(separator: " ")
                .map { $0.prefix(1).uppercased() + $0.dropFirst() }
                .joined(separator: " ")
            return (slug: slug, display: display, flows: group)
        }
    }
}

// MARK: - Public Entry Point

@discardableResult
func generateAndSaveCustomReport(from maestroReportURL: URL,
                                 projectName: String,
                                 appType: String) -> URL? {
    guard let html = try? String(contentsOf: maestroReportURL, encoding: .utf8) else {
        print("❌ Custom report: cannot read maestro report at \(maestroReportURL.path)")
        return nil
    }

    let summary = parseMaestroReport(html: html,
                                     projectName: projectName,
                                     appType: appType)
    let renderedHTML = renderCustomReportHTML(from: summary)

    let outURL = maestroReportURL
        .deletingLastPathComponent()
        .appendingPathComponent("aiqa-report.html")

    do {
        try renderedHTML.write(to: outURL, atomically: true, encoding: .utf8)
        print("✅ Custom report saved to \(outURL.path)")
    } catch {
        print("❌ Custom report: failed to write — \(error.localizedDescription)")
        return nil
    }

    // Save the companion .xlsx workbook alongside the HTML report. Failures
    // here are logged but do not block returning the HTML report URL — the
    // HTML report is still the primary deliverable that auto-opens.
    let buildFolder = outURL.deletingLastPathComponent()
    _ = generateAndSaveExcelReport(from: summary, in: buildFolder)

    return outURL
}

// MARK: - Parser

private func parseMaestroReport(html: String,
                                projectName: String,
                                appType: String) -> ReportSummary {
    let total = firstIntMatch(in: html,
        pattern: #"Total number of Flows</h5>\s*<h3[^>]*>(\d+)</h3>"#) ?? 0
    let failed = firstIntMatch(in: html,
        pattern: #"Failed Flows</h5>\s*<h3[^>]*>(\d+)</h3>"#) ?? 0
    let passed = firstIntMatch(in: html,
        pattern: #"Successful Flows</h5>\s*<h3[^>]*>(\d+)</h3>"#) ?? 0
    let overallStatus = firstStringMatch(in: html,
        pattern: #"Test Result:\s*([A-Z]+)<br>"#) ?? "UNKNOWN"
    let overallDuration = firstStringMatch(in: html,
        pattern: #"Test Result:\s*[A-Z]+<br>Duration:\s*([^<]+)<br>"#) ?? "—"

    let flows = parseFlowBlocks(html: html)

    return ReportSummary(
        projectName: projectName,
        appType: appType,
        totalFlows: total > 0 ? total : flows.count,
        passedFlows: passed > 0 ? passed : flows.filter { $0.isPassed }.count,
        failedFlows: failed,
        overallStatus: overallStatus,
        overallDuration: overallDuration,
        flows: flows
    )
}

private func parseFlowBlocks(html: String) -> [ReportFlow] {
    let pieces = html.components(separatedBy: #"<h5 class="mb-0"><button class="btn btn-"#)
    guard pieces.count > 1 else { return [] }

    return pieces.dropFirst().compactMap { chunk -> ReportFlow? in
        guard let name = firstStringMatch(in: chunk,
                pattern: ##"data-bs-target="#flow-\d+-([A-Za-z0-9_\-]+)""##)
              ?? firstStringMatch(in: chunk, pattern: #">([A-Za-z0-9_\-]+)\s*:\s*(?:SUCCESS|FAILURE)</button>"#)
        else { return nil }

        // Maestro emits `Status: SUCCESS<br>` for passing flows and
        // `Status: ERROR<br>` for failed flows. Allow any uppercase token,
        // and fall back to the collapse-header button text which uses the
        // human-readable `: SUCCESS|FAILURE` form.
        let status = firstStringMatch(in: chunk,
            pattern: #"Status:\s*(?:<[^>]*>\s*)*([A-Z]+)"#)
            ?? firstStringMatch(in: chunk,
                pattern: #":\s*(SUCCESS|FAILURE)\s*</button>"#)
            ?? "UNKNOWN"
        // Duration is parsed independently so a non-SUCCESS status no
        // longer breaks the lookup.
        let duration = firstStringMatch(in: chunk,
            pattern: #"Duration:\s*([^<]+)<"#) ?? "—"
        let fileName = firstStringMatch(in: chunk,
            pattern: #"File Name:\s*([^<]+)<br>"#) ?? name

        let steps = parseSteps(chunk: chunk)

        return ReportFlow(
            rawName: name,
            status: status,
            duration: duration,
            fileName: fileName,
            steps: steps
        )
    }
}

private func parseSteps(chunk: String) -> [ReportStep] {
    let pattern = #"<div class="step-header[^>]*><span>(.{1,4})\s*<span class="step-name">([^<]+)</span></span>\s*<span class="badge[^>]*>([^<]+)</span></div>"#
    guard let regex = try? NSRegularExpression(pattern: pattern, options: [.dotMatchesLineSeparators]) else {
        return []
    }
    let ns = chunk as NSString
    let matches = regex.matches(in: chunk, options: [], range: NSRange(location: 0, length: ns.length))

    return matches.compactMap { match in
        guard match.numberOfRanges == 4 else { return nil }
        let symbol = ns.substring(with: match.range(at: 1)).trimmingCharacters(in: .whitespacesAndNewlines)
        let name = ns.substring(with: match.range(at: 2))
        let dur = ns.substring(with: match.range(at: 3))
        return ReportStep(symbol: symbol, name: name, duration: dur)
    }
}

// MARK: - Regex Helpers

private func firstIntMatch(in text: String, pattern: String) -> Int? {
    if let s = firstStringMatch(in: text, pattern: pattern), let n = Int(s) {
        return n
    }
    return nil
}

private func firstStringMatch(in text: String, pattern: String) -> String? {
    guard let regex = try? NSRegularExpression(pattern: pattern, options: [.dotMatchesLineSeparators]) else {
        return nil
    }
    let ns = text as NSString
    guard let match = regex.firstMatch(in: text, options: [], range: NSRange(location: 0, length: ns.length)),
          match.numberOfRanges > 1 else {
        return nil
    }
    let range = match.range(at: 1)
    guard range.location != NSNotFound else { return nil }
    return ns.substring(with: range).trimmingCharacters(in: .whitespacesAndNewlines)
}

// MARK: - HTML Renderer

private func renderCustomReportHTML(from summary: ReportSummary) -> String {
    let overallPassed = summary.overallStatus.uppercased() == "PASSED"
    let timestamp = ISO8601DateFormatter().string(from: Date())

    let projectName = summary.projectName.isEmpty ? "—" : summary.projectName
    let appType = summary.appType.isEmpty ? "—" : summary.appType
    let featuresText = summary.displayFeatures.isEmpty
        ? "—"
        : summary.displayFeatures.joined(separator: ", ")

    let positiveTotal = summary.count(of: "positive")
    let negativeTotal = summary.count(of: "negative")
    let edgeTotal     = summary.count(of: "edge")

    let modulesHTML = summary.flowsByFeature
        .map { renderModuleHTML(displayName: $0.display, flows: $0.flows) }
        .joined(separator: "\n")

    return """
    <!DOCTYPE html>
    <html lang="en">
    <head>
      <meta charset="UTF-8">
      <title>CTA Test Report</title>
      <style>\(reportCSS)</style>
    </head>
    <body>
      <header class="header">
        <div class="header-left">
          <h1>Cognitive Test Automation Report</h1>
          <div class="header-meta">Generated \(timestamp)</div>
        </div>
        <div class="header-right">
          <span class="overall-badge \(overallPassed ? "passed" : "failed")">
            \(escape(summary.overallStatus.uppercased()))
          </span>
          <span class="duration-pill">⏱ \(escape(summary.overallDuration))</span>
        </div>
      </header>

      <section class="project-info">
        <div class="project-row">
          <span class="project-label">Project Name</span>
          <span class="project-value">\(escape(projectName))</span>
        </div>
        <div class="project-row">
          <span class="project-label">App Type</span>
          <span class="project-value">\(escape(appType))</span>
        </div>
        <div class="project-row">
          <span class="project-label">Features under test</span>
          <span class="project-value">\(escape(featuresText))</span>
        </div>
      </section>

      <section class="summary">
        <h2>Summary</h2>
        <div class="cards">
          \(renderSummaryCard(title: "Positive",
                              accent: "positive",
                              total: positiveTotal,
                              passed: summary.passed(of: "positive"),
                              failed: summary.failed(of: "positive")))
          \(renderSummaryCard(title: "Negative",
                              accent: "negative",
                              total: negativeTotal,
                              passed: summary.passed(of: "negative"),
                              failed: summary.failed(of: "negative")))
          \(renderSummaryCard(title: "Edge",
                              accent: "edge",
                              total: edgeTotal,
                              passed: summary.passed(of: "edge"),
                              failed: summary.failed(of: "edge")))
          \(renderSummaryCard(title: "Total Test Cases",
                              accent: "total",
                              total: summary.totalFlows,
                              passed: summary.passedFlows,
                              failed: summary.failedFlows))
        </div>
      </section>

      <section class="modules-section">
        <h2>Detailed Report (\(summary.flowsByFeature.count) module\(summary.flowsByFeature.count == 1 ? "" : "s"))</h2>
        <div class="module-list">
          \(modulesHTML)
        </div>
      </section>

      <footer class="footer">
        CTA Test Runner • Auto-generated report
      </footer>
    </body>
    </html>
    """
}

private func renderSummaryCard(title: String, accent: String,
                               total: Int, passed: Int, failed: Int) -> String {
    """
    <div class="card \(accent)">
      <div class="card-label">\(escape(title))</div>
      <div class="card-number">\(total)</div>
      <div class="card-breakdown">
        <span class="pill pill-passed">Passed: \(passed)</span>
        <span class="pill pill-failed">Failed: \(failed)</span>
      </div>
    </div>
    """
}

private func renderModuleHTML(displayName: String, flows: [ReportFlow]) -> String {
    let total = flows.count
    let passed = flows.filter { $0.isPassed }.count
    let failed = total - passed
    let moduleStatusClass = failed == 0 ? "passed" : "failed"

    let flowsHTML = flows
        .map { renderFlowHTML(flow: $0) }
        .joined(separator: "\n")

    return """
    <details class="module \(moduleStatusClass)">
      <summary>
        <span class="module-name">\(escape(displayName))</span>
        <span class="module-meta">
          <span class="pill pill-total">\(total) test case\(total == 1 ? "" : "s")</span>
          <span class="pill pill-passed">\(passed) passed</span>
          <span class="pill pill-failed">\(failed) failed</span>
        </span>
      </summary>
      <div class="module-body">
        \(flowsHTML)
      </div>
    </details>
    """
}

private func renderFlowHTML(flow: ReportFlow) -> String {
    let typeClass = flow.type
    let statusClass = flow.isPassed ? "passed" : "failed"
    let statusBadgeText = flow.isPassed ? "PASSED" : "FAILED"

    let stepsHTML = flow.steps.map { step in
        let stepClass = step.isFailed ? "step failed" : "step ok"
        return """
        <li class="\(stepClass)">
          <span class="step-icon">\(escape(step.symbol))</span>
          <span class="step-text">\(escape(step.name))</span>
          <span class="step-duration">\(escape(step.duration))</span>
        </li>
        """
    }.joined(separator: "\n")

    return """
    <details class="flow \(typeClass) \(statusClass)">
      <summary>
        <span class="flow-serial">\(escape(flow.serial))</span>
        <span class="flow-title">\(escape(flow.displayTitle))</span>
        <span class="flow-badges">
          <span class="badge type-\(typeClass)">\(typeClass.uppercased())</span>
          <span class="badge status-\(statusClass)">\(statusBadgeText)</span>
          <span class="badge duration">\(escape(flow.duration))</span>
        </span>
      </summary>
      <div class="flow-body">
        <div class="meta-grid">
          <div><span class="meta-k">Feature</span><span class="meta-v">\(escape(flow.displayFeature))</span></div>
          <div><span class="meta-k">Type</span><span class="meta-v">\(escape(flow.type))</span></div>
          <div><span class="meta-k">Status</span><span class="meta-v">\(escape(flow.status))</span></div>
          <div><span class="meta-k">Duration</span><span class="meta-v">\(escape(flow.duration))</span></div>
          <div class="meta-wide"><span class="meta-k">File</span><span class="meta-v mono">\(escape(flow.cleanFileName)).yaml</span></div>
        </div>
        <h4>Test Steps (\(flow.steps.count))</h4>
        <ol class="steps">
          \(stepsHTML)
        </ol>
      </div>
    </details>
    """
}

private func escape(_ s: String) -> String {
    // Maestro's HTML for step names is already encoded; for derived fields
    // (titles, durations, file names, user input) we escape the basics.
    return s
        .replacingOccurrences(of: "&", with: "&amp;")
        .replacingOccurrences(of: "<", with: "&lt;")
        .replacingOccurrences(of: ">", with: "&gt;")
}

// MARK: - CSS

private let reportCSS = """
:root {
  --bg: #f5f6f8;
  --surface: #ffffff;
  --border: #e6e8ec;
  --text: #1c1f24;
  --muted: #6b7280;
  --green: #16a34a;
  --red: #dc2626;
  --orange: #f59e0b;
  --blue: #2563eb;
  --shadow: 0 1px 3px rgba(0,0,0,0.04), 0 1px 2px rgba(0,0,0,0.06);
}

* { box-sizing: border-box; }
body {
  margin: 0;
  font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif;
  color: var(--text);
  background: var(--bg);
  line-height: 1.5;
}

.header {
  display: flex;
  justify-content: space-between;
  align-items: center;
  padding: 28px 40px;
  background: var(--surface);
  border-bottom: 1px solid var(--border);
}
.header h1 { margin: 0; font-size: 26px; }
.header-meta { color: var(--muted); font-size: 13px; margin-top: 4px; }
.header-right { display: flex; align-items: center; gap: 12px; }
.overall-badge {
  font-weight: 700;
  padding: 8px 16px;
  border-radius: 999px;
  font-size: 13px;
  letter-spacing: 0.5px;
}
.overall-badge.passed { background: rgba(22,163,74,0.12); color: var(--green); }
.overall-badge.failed { background: rgba(220,38,38,0.12); color: var(--red); }
.duration-pill {
  background: var(--bg);
  border: 1px solid var(--border);
  padding: 6px 14px;
  border-radius: 999px;
  font-size: 13px;
  color: var(--muted);
}

section { padding: 24px 40px; }
section h2 { margin: 0 0 16px; font-size: 18px; }

.project-info {
  background: var(--surface);
  border-bottom: 1px solid var(--border);
  display: flex;
  flex-direction: column;
  gap: 6px;
  padding: 20px 40px;
}
.project-row {
  display: flex;
  align-items: baseline;
  gap: 10px;
  font-size: 14px;
}
.project-label {
  font-weight: 700;
  color: var(--muted);
  min-width: 170px;
  text-transform: uppercase;
  letter-spacing: 0.4px;
  font-size: 11px;
}
.project-value {
  color: var(--text);
  font-size: 14px;
}

.cards {
  display: grid;
  grid-template-columns: repeat(4, 1fr);
  gap: 14px;
}
@media (max-width: 900px) { .cards { grid-template-columns: repeat(2, 1fr); } }
@media (max-width: 520px) { .cards { grid-template-columns: 1fr; } }

.card {
  background: var(--surface);
  border-radius: 12px;
  border: 1px solid var(--border);
  padding: 18px 18px 16px;
  box-shadow: var(--shadow);
  position: relative;
  overflow: hidden;
}
.card::before {
  content: "";
  position: absolute;
  left: 0; top: 0; bottom: 0;
  width: 4px;
  background: var(--blue);
}
.card.positive::before { background: var(--green); }
.card.negative::before { background: var(--red); }
.card.edge::before     { background: var(--orange); }
.card.total::before    { background: var(--blue); }

.card-label {
  color: var(--muted);
  font-size: 12px;
  text-transform: uppercase;
  letter-spacing: 0.5px;
  margin-bottom: 6px;
  font-weight: 700;
}
.card-number { font-size: 32px; font-weight: 700; line-height: 1.1; }
.card.positive .card-number { color: var(--green); }
.card.negative .card-number { color: var(--red); }
.card.edge .card-number     { color: var(--orange); }
.card.total .card-number    { color: var(--blue); }

.card-breakdown {
  display: flex;
  gap: 6px;
  margin-top: 10px;
  flex-wrap: wrap;
}

.pill {
  font-size: 11px;
  font-weight: 700;
  padding: 3px 10px;
  border-radius: 999px;
  letter-spacing: 0.3px;
  border: 1px solid transparent;
}
.pill-passed { background: rgba(22,163,74,0.12);  color: var(--green); }
.pill-failed { background: rgba(220,38,38,0.12);  color: var(--red); }
.pill-total  { background: var(--bg); color: var(--muted); border-color: var(--border); }

.module-list { display: flex; flex-direction: column; gap: 12px; }

.module {
  background: var(--surface);
  border: 1px solid var(--border);
  border-left-width: 4px;
  border-radius: 12px;
  overflow: hidden;
  box-shadow: var(--shadow);
}
.module.passed { border-left-color: var(--green); }
.module.failed { border-left-color: var(--red); }

.module > summary {
  display: flex;
  align-items: center;
  justify-content: space-between;
  gap: 14px;
  padding: 16px 20px;
  cursor: pointer;
  list-style: none;
  user-select: none;
}
.module > summary::-webkit-details-marker { display: none; }
.module > summary::before {
  content: "▶";
  font-size: 11px;
  color: var(--muted);
  transition: transform 0.15s ease;
  display: inline-block;
}
.module[open] > summary::before { transform: rotate(90deg); }

.module-name {
  flex: 1;
  font-weight: 700;
  font-size: 15px;
  letter-spacing: 0.2px;
}
.module-meta { display: flex; gap: 6px; align-items: center; flex-wrap: wrap; }

.module-body {
  display: flex;
  flex-direction: column;
  gap: 8px;
  padding: 14px 18px 18px;
  background: #fafbfc;
  border-top: 1px solid var(--border);
}

.flow {
  background: var(--surface);
  border: 1px solid var(--border);
  border-left-width: 4px;
  border-radius: 10px;
  overflow: hidden;
}
.flow.positive { border-left-color: var(--green); }
.flow.negative { border-left-color: var(--red); }
.flow.edge     { border-left-color: var(--orange); }
.flow.unknown  { border-left-color: var(--muted); }

.flow > summary {
  display: flex;
  align-items: center;
  gap: 12px;
  padding: 12px 16px;
  cursor: pointer;
  list-style: none;
  user-select: none;
}
.flow > summary::-webkit-details-marker { display: none; }
.flow > summary::before {
  content: "▶";
  font-size: 10px;
  color: var(--muted);
  transition: transform 0.15s ease;
  display: inline-block;
}
.flow[open] > summary::before { transform: rotate(90deg); }

.flow-serial {
  font-family: ui-monospace, SFMono-Regular, Menlo, monospace;
  font-size: 12px;
  color: var(--muted);
  background: var(--bg);
  padding: 3px 8px;
  border-radius: 4px;
}
.flow-title { flex: 1; font-weight: 600; font-size: 13px; }
.flow-badges { display: flex; gap: 6px; align-items: center; }

.badge {
  font-size: 11px;
  font-weight: 700;
  padding: 4px 10px;
  border-radius: 999px;
  letter-spacing: 0.3px;
}
.badge.type-positive { background: rgba(22,163,74,0.12); color: var(--green); }
.badge.type-negative { background: rgba(220,38,38,0.12); color: var(--red); }
.badge.type-edge     { background: rgba(245,158,11,0.15); color: var(--orange); }
.badge.type-unknown  { background: rgba(107,114,128,0.12); color: var(--muted); }
.badge.status-passed { background: rgba(22,163,74,0.12); color: var(--green); }
.badge.status-failed { background: rgba(220,38,38,0.12); color: var(--red); }
.badge.duration { background: var(--bg); color: var(--muted); border: 1px solid var(--border); }

.flow-body {
  padding: 16px;
  border-top: 1px solid var(--border);
  background: #fafbfc;
}

.meta-grid {
  display: grid;
  grid-template-columns: repeat(4, 1fr);
  gap: 10px;
  margin-bottom: 14px;
}
.meta-grid > div {
  background: var(--surface);
  border: 1px solid var(--border);
  border-radius: 8px;
  padding: 9px 12px;
  display: flex;
  flex-direction: column;
}
.meta-grid .meta-wide { grid-column: span 4; }
.meta-k { font-size: 11px; color: var(--muted); text-transform: uppercase; letter-spacing: 0.4px; }
.meta-v { font-size: 13px; margin-top: 3px; }
.meta-v.mono { font-family: ui-monospace, SFMono-Regular, Menlo, monospace; }

.flow-body h4 {
  margin: 0 0 10px;
  font-size: 13px;
  text-transform: uppercase;
  color: var(--muted);
  letter-spacing: 0.5px;
}

.steps {
  list-style: none;
  padding: 0;
  margin: 0;
  border-radius: 8px;
  overflow: hidden;
  border: 1px solid var(--border);
  background: var(--surface);
}
.step {
  display: flex;
  align-items: center;
  gap: 10px;
  padding: 9px 14px;
  font-size: 13px;
  border-bottom: 1px solid var(--border);
}
.step:last-child { border-bottom: none; }
.step.ok { color: var(--text); }
.step.failed { color: var(--red); background: rgba(220,38,38,0.04); font-weight: 500; }
.step-icon { font-size: 14px; }
.step-text { flex: 1; }
.step-duration {
  font-family: ui-monospace, SFMono-Regular, Menlo, monospace;
  font-size: 11px;
  color: var(--muted);
  background: var(--bg);
  padding: 2px 7px;
  border-radius: 4px;
}

.footer {
  padding: 24px 40px;
  text-align: center;
  color: var(--muted);
  font-size: 12px;
  border-top: 1px solid var(--border);
  background: var(--surface);
}
"""
