//
//  OfflineTestStepAndScenarioGenerator.swift
//  AIQATestRunner
//
//  Created by Sayed on 13/05/26.
//

import Foundation
import SwiftUI

extension TestStepsGenerator {

    // MARK: - Offline DSL Step Generation (Screenshot → DSL via Ollama)

    func offlineTestStepsGenerator() {
        guard !screenshots.isEmpty else {
            print("⚠️ No screenshots uploaded.")
            return
        }

        isLoading = true

        let imagesBase64: [String] = screenshots.compactMap { imageToBase64($0.image) }

        let descriptions = screenshots.enumerated().map { index, shot in
            "Screen \(index + 1): \(shot.description.isEmpty ? "No description provided" : shot.description)"
        }.joined(separator: "\n")

        let prompt = """
        You are a mobile test automation expert.
        Your job is to analyze mobile app screenshots and generate sequential steps.
        COMMAND REFERENCE:
        - Tap <label>          → Tap a visible labeled element
        - Tap <label> <index>  → Tap when multiple elements share the same label (0-based index)
        - TapIcon <x%,y%>      → Tap an icon-only element with no readable label
        - Visible <label>      → Assert element is visible (use as screen boundary check)
        - Enter <value>        → Type into the currently focused input field
        - Scroll to <value>    → Scroll to that element until visible
        - runflow <label>      → Conditional tap: only if element is visible

        RULES FOR OUTPUT:
        1. Output ONLY the steps, one per line. No explanation, no markdown, no numbering.
        2. For input fields: always Tap the field first, then Enter the value on the next line.
        3. If duplicate labels exist, always target the interactive element (button, textField, etc.) instead of static text, and append a 0-based index after the label.
            Format: Tap <label> <index>
            Example: Tap Login 1 means tap the second interactive element labeled "Login".
        4. Use TapIcon with the icon's exact center position as screen-relative whole-number percentages and comma separated. Example: TapIcon: 92%, 8%
        5. Use Scroll to, when prompted by user.
        6. Use runflow for elements that may or may not appear (conditional screens like Continue, Skip, Allow).
        7. Follow the logical order: fill all fields before tapping submit/login/confirm.
        8. Use the screen hints provided by the user to understand context and field meaning.

        Module under test: \(featureName)

        Screen Descriptions:
        \(descriptions)

        Return output strictly in JSON array format:
        [
          {
            "steps": ""
          }
        ]
        """

        let requestBody: [String: Any] = [
            "model": "qwen2.5vl:7b",
            "prompt": prompt,
            "images": imagesBase64,
            "stream": false
        ]

        guard let url = URL(string: "http://127.0.0.1:11434/api/generate"),
              let body = try? JSONSerialization.data(withJSONObject: requestBody) else {
            print("❌ Failed to build Ollama request.")
            isLoading = false
            return
        }

        var request = URLRequest(url: url)
        request.httpMethod = "POST"
        request.addValue("application/json", forHTTPHeaderField: "Content-Type")
        request.httpBody = body
        request.timeoutInterval = 600

        let config = URLSessionConfiguration.default
        config.timeoutIntervalForRequest = 600
        config.timeoutIntervalForResource = 900

        URLSession(configuration: config).dataTask(with: request) { data, response, error in
            DispatchQueue.main.async { self.isLoading = false }

            if let error = error {
                print("❌ Ollama error:", error.localizedDescription)
                return
            }
            guard let data = data else {
                print("❌ Ollama returned no data.")
                return
            }

            print("📦 Ollama raw response:", String(data: data, encoding: .utf8) ?? "nil")

            if let responseText = parseOllamaGenerateResponse(data: data) {
                
                self.parseTestCases(responseText)
            }
        }.resume()
    }

    // MARK: - Offline Test Scenario Generation (Screenshot → CSV via Ollama)

    func offlineTestScenarioGenerator() {
        guard !screenshots.isEmpty else {
            print("⚠️ No screenshots uploaded.")
            return
        }

        isLoading = true

        let imagesBase64: [String] = screenshots.compactMap { imageToBase64($0.image) }
        let descriptions = screenshots.map { $0.description }.joined(separator: "\n")

        let prompt = """
        You are a QA AI Agent.
        Generate test cases in JSON format.
        Feature: \(featureName)
        Descriptions: \(descriptions)
        Return output strictly in JSON array format:
        [
         {
           "title": "",
           "steps": "",
           "expectedResult": "",
           "type": "positive/negative/edge"
         }
        ]
        Ensure:
        - "title": Title of the test case only. Do NOT include type (positive/negative/edge) in this field.
        - "type": Must contain only ONE word — either "positive", "negative", or "edge".
        """

        let requestBody: [String: Any] = [
            "model": "qwen2.5vl:7b",
            "prompt": prompt,
            "images": imagesBase64,
            "stream": false
        ]

        guard let url = URL(string: "http://127.0.0.1:11434/api/generate"),
              let body = try? JSONSerialization.data(withJSONObject: requestBody) else {
            print("❌ Failed to build Ollama request.")
            isLoading = false
            return
        }

        var request = URLRequest(url: url)
        request.httpMethod = "POST"
        request.addValue("application/json", forHTTPHeaderField: "Content-Type")
        request.httpBody = body
        request.timeoutInterval = 600

        let config = URLSessionConfiguration.default
        config.timeoutIntervalForRequest = 600
        config.timeoutIntervalForResource = 900

        Task {
            do {
                let (data, response) = try await URLSession(configuration: config).data(for: request)

                await MainActor.run { self.isLoading = false }

                if let httpResponse = response as? HTTPURLResponse,
                   !(200...299).contains(httpResponse.statusCode) {
                    print("❌ Ollama HTTP error:", httpResponse.statusCode)
                    print(String(data: data, encoding: .utf8) ?? "")
                    return
                }

                print("📦 Ollama scenario raw response:", String(data: data, encoding: .utf8) ?? "nil")

                if let responseText = parseOllamaGenerateResponse(data: data) {
                    await parseTestScenarios(responseText)
                }
            } catch {
                await MainActor.run { self.isLoading = false }
                print("❌ Ollama scenario error:", error.localizedDescription)
            }
        }
    }
}

// MARK: - Ollama Response Parser

private func parseOllamaGenerateResponse(data: Data) -> String? {
    guard let json = try? JSONSerialization.jsonObject(with: data) as? [String: Any],
          let text = json["response"] as? String else {
        print("❌ Failed to parse Ollama response.")
        return nil
    }
    print("parsedOllama Response")
    return text
}
