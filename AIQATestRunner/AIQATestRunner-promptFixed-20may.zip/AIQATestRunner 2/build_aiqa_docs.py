#!/usr/bin/env python3
"""
Generate AIQA-TestRunner.docx — a concise architecture & feature document
for the AIQA Test Runner Swift app. Output lives on the user's Desktop.

Sections kept tight on purpose (user explicitly asked for concise).
"""
from docx import Document
from docx.shared import Pt, RGBColor, Inches, Cm
from docx.enum.text import WD_ALIGN_PARAGRAPH
from docx.enum.table import WD_ALIGN_VERTICAL
from docx.oxml.ns import qn
from docx.oxml import OxmlElement
from pathlib import Path

# ---------- styling helpers ----------

PRIMARY = RGBColor(0x10, 0x3A, 0x6F)   # deep blue
ACCENT  = RGBColor(0x2A, 0x6B, 0xB0)   # mid blue
MUTED   = RGBColor(0x55, 0x55, 0x55)
CODE_BG = "F4F4F4"
HEAD_BG = "10316F"


def shade_cell(cell, color_hex: str):
    tc_pr = cell._tc.get_or_add_tcPr()
    shd = OxmlElement("w:shd")
    shd.set(qn("w:val"), "clear")
    shd.set(qn("w:color"), "auto")
    shd.set(qn("w:fill"), color_hex)
    tc_pr.append(shd)


def add_heading(doc, text, level=1):
    h = doc.add_heading(text, level=level)
    for run in h.runs:
        run.font.color.rgb = PRIMARY
        run.font.name = "Helvetica Neue"
    return h


def add_para(doc, text, *, bold=False, italic=False, size=10.5, color=None,
             space_after=4):
    p = doc.add_paragraph()
    run = p.add_run(text)
    run.font.size = Pt(size)
    run.font.name = "Helvetica Neue"
    run.bold = bold
    run.italic = italic
    if color is not None:
        run.font.color.rgb = color
    p.paragraph_format.space_after = Pt(space_after)
    return p


def add_bullet(doc, text, *, level=0, size=10.5):
    p = doc.add_paragraph(style="List Bullet" if level == 0 else "List Bullet 2")
    run = p.add_run(text)
    run.font.size = Pt(size)
    run.font.name = "Helvetica Neue"
    p.paragraph_format.space_after = Pt(2)
    return p


def add_code(doc, text):
    p = doc.add_paragraph()
    run = p.add_run(text)
    run.font.name = "Menlo"
    run.font.size = Pt(9.5)
    run.font.color.rgb = RGBColor(0x22, 0x22, 0x22)
    # Light gray background for the paragraph.
    p_pr = p._p.get_or_add_pPr()
    shd = OxmlElement("w:shd")
    shd.set(qn("w:val"), "clear")
    shd.set(qn("w:color"), "auto")
    shd.set(qn("w:fill"), CODE_BG)
    p_pr.append(shd)
    p.paragraph_format.space_before = Pt(4)
    p.paragraph_format.space_after = Pt(6)
    p.paragraph_format.left_indent = Cm(0.4)
    return p


def add_table(doc, rows, *, col_widths=None, header=True):
    """rows[0] is the header row."""
    t = doc.add_table(rows=len(rows), cols=len(rows[0]))
    t.style = "Light Grid Accent 1"
    t.alignment = WD_ALIGN_PARAGRAPH.LEFT
    for r_idx, row in enumerate(rows):
        for c_idx, cell_text in enumerate(row):
            cell = t.rows[r_idx].cells[c_idx]
            cell.vertical_alignment = WD_ALIGN_VERTICAL.TOP
            cell.text = ""
            p = cell.paragraphs[0]
            run = p.add_run(cell_text)
            run.font.name = "Helvetica Neue"
            run.font.size = Pt(9.5)
            if r_idx == 0 and header:
                run.bold = True
                run.font.color.rgb = RGBColor(0xFF, 0xFF, 0xFF)
                shade_cell(cell, HEAD_BG)
    if col_widths:
        for c_idx, w in enumerate(col_widths):
            for r in t.rows:
                r.cells[c_idx].width = Inches(w)
    return t


# ---------- document ----------

doc = Document()

# Page margins.
for section in doc.sections:
    section.left_margin = Cm(2.0)
    section.right_margin = Cm(2.0)
    section.top_margin = Cm(2.0)
    section.bottom_margin = Cm(2.0)

# Cover.
title = doc.add_paragraph()
title.alignment = WD_ALIGN_PARAGRAPH.CENTER
t_run = title.add_run("AIQA Test Runner")
t_run.font.size = Pt(28)
t_run.font.bold = True
t_run.font.color.rgb = PRIMARY
t_run.font.name = "Helvetica Neue"

sub = doc.add_paragraph()
sub.alignment = WD_ALIGN_PARAGRAPH.CENTER
s_run = sub.add_run("Architecture, Workflow, and Roadmap")
s_run.font.size = Pt(14)
s_run.font.color.rgb = ACCENT
s_run.font.name = "Helvetica Neue"

meta = doc.add_paragraph()
meta.alignment = WD_ALIGN_PARAGRAPH.CENTER
m_run = meta.add_run("AI-driven mobile E2E test generation • Swift / SwiftUI • macOS")
m_run.font.size = Pt(10)
m_run.font.italic = True
m_run.font.color.rgb = MUTED
m_run.font.name = "Helvetica Neue"

doc.add_paragraph()  # spacer
doc.add_paragraph()  # spacer

# ===================== 1. Prerequisites =====================
add_heading(doc, "1. Prerequisites", level=1)
add_para(doc, "Install these once on the developer machine before running the app.")

add_table(doc, [
    ["Component", "How to install", "Why it's needed"],
    ["macOS 13+ (Ventura or later)", "—", "Required by SwiftUI APIs in use."],
    ["Xcode (15+)", "App Store → Xcode → install. Then xcode-select --install for CLI tools.",
     "Provides the iOS Simulator, simctl, and signing toolchain used by the build pipeline."],
    ["Android Studio + SDK", "developer.android.com/studio → install. Set ANDROID_HOME to ~/Library/Android/sdk.",
     "Provides adb, emulator, aapt/aapt2 used to discover devices, install APKs, and parse permissions."],
    ["At least one iOS Simulator", "Xcode → Settings → Platforms → install an iOS runtime.",
     "Target for iOS automation. The app discovers all installed simulators automatically."],
    ["At least one Android AVD", "Android Studio → Device Manager → Create Virtual Device.",
     "Target for Android automation. The app reads AVD names via emulator -list-avds."],
    ["Maestro CLI", 'curl -Ls "https://get.maestro.mobile.dev" | bash',
     "Runs the generated YAML flows against the booted simulator/emulator."],
    ["Ollama + qwen2.5vl:7b (optional, offline mode)",
     "brew install ollama  •  ollama pull qwen2.5vl:7b",
     "Local vision LLM. Avoids Gemini API cost / network dependence. Online mode (Gemini) still works without this."],
    ["Gemini API key (optional, online mode)", "Set GEMINI_API_KEY in env or in-app settings.",
     "Faster + higher quality than the local model for screenshot → DSL."],
], col_widths=[1.7, 2.5, 2.5])

# ===================== 2. User Workflow =====================
doc.add_page_break()
add_heading(doc, "2. End-to-End User Workflow", level=1)
add_para(doc, "From a fresh install to a generated test report.")

steps = [
    ("Pick / migrate workspace",
     "On first launch the app prompts for a workspace folder. Pick any directory; the app scaffolds <workspace>/<App>/<platform>/{flows,builds,build} subfolders. Users who previously stored flows in ~/Desktop/e2e are offered a one-click migration."),
    ("Create first App",
     "Provide an app name plus iOS bundle ID and Android package name. These are persisted in aiqa.json inside the workspace and are auto-restored on next launch."),
    ("Pick active app and platform",
     "The top context bar shows the currently active workspace, app, and platform (iOS / Android / Web). Switching the platform automatically re-scans devices, modules, and the build slot for that platform."),
    ("Upload the build under test",
     "Drag an .ipa / .app (iOS) or .apk (Android) onto the Build card. Metadata (bundle id, version, size) is parsed from Info.plist or aapt and auto-fills the App ID field. Build is copied into <app>/<platform>/builds/ and tracked via build.meta.json."),
    ("Select target device",
     "Inline device picker on the Build card shows all installed simulators (iOS) or AVDs and connected devices (Android), with badges for already-booted ones. Selection is persisted per platform."),
    ("Install on device (smart button)",
     "Single button label adapts to state: 'Install on iPhone 16 Pro', 'Boot & Install on Pixel 7…', etc. If the device is shut down, the app boots it (and waits for sys.boot_completed / simctl bootstatus) before installing. Layer 1 permission pre-granting fires silently after a successful install."),
    ("Open Test Data Vault (optional)",
     "Test Data tab lets users define per-module input values (username, password) and expected assertion strings (toast messages, etc.). Stored in test-data.json inside the workspace and surfaced into the AI prompt at generation time."),
    ("Upload screenshots & feature name",
     "On the Test Steps card, enter the feature/module name (or pick from the vault dropdown). Drag, paste, or browse to add screenshots. Screenshots support drag-to-reorder and external drops."),
    ("Generate Multi-Flow Suite",
     "Choose Online (Gemini) or Offline (Ollama). The AI returns multiple test cases (positive + negatives + edges, count decided by feature complexity) as preview cards with editable DSL text. Each card has a remove button."),
    ("Review & edit DSL",
     "User scrolls horizontally through the preview cards and fixes any AI mistakes inline. This step is the safety valve — AI never goes straight to YAML."),
    ("Generate YAML",
     "Each card's DSL is transpiled into a Maestro YAML file and saved to <app>/<platform>/flows/ with the standard naming convention (see §4). A 'Next Module' button resets the UI for the next feature."),
    ("Select modules to run",
     "The action bar shows chips for every module discovered in the flows/ folder. User picks any subset; an 'All' shortcut is provided."),
    ("Run automation suite",
     "Behind the scenes: ordered staging folder built (§3), config.yaml written, --env flags built from the vault, Maestro invoked. Live stdout streamed to console."),
    ("Reports auto-open",
     "After Maestro finishes, a custom HTML report (parsed from Maestro's html-detailed output, decorated with summary cards) and a companion .xlsx workbook are generated in <app>/<platform>/build/. The HTML report opens automatically."),
]
for i, (title_, body) in enumerate(steps, 1):
    add_para(doc, f"Step {i}. {title_}", bold=True, size=11, space_after=2)
    add_para(doc, body)

# ===================== 3. Architecture / File Map =====================
doc.add_page_break()
add_heading(doc, "3. Architecture Overview", level=1)
add_para(doc, "The app is a Swift / SwiftUI macOS app organized around one orchestrating view (ContentView) "
              "and a small set of single-responsibility managers and tool modules. The table below lists every "
              "file and its job.")

add_table(doc, [
    ["File", "Responsibility"],
    ["ContentView.swift", "Top-level UI. Hosts the workspace context bar, build card, test-steps card, action section. Reacts to workspace and platform changes."],
    ["WorkspaceManager.swift", "Singleton ObservableObject. Owns the active (workspace, app, platform) tuple. Scaffolds directories. Persists state in aiqa.json + UserDefaults. Notifies dependent managers when context changes."],
    ["BuildManager.swift", "Owns the App Under Test artifact for the active (app, platform). Peek metadata, commit import, install, remove. Calls Layer 1 (simctl privacy grant / adb pm grant) after a successful install."],
    ["BuildUnderTestView.swift", "Drop zone + filled-state card. Inline device picker, smart Install button, progress states, replace/remove dialogs."],
    ["DeviceManager.swift", "Discovers iOS simulators (simctl list) and Android AVDs + devices (emulator -list-avds + adb devices). Persists user selection per platform."],
    ["IOSTools.swift", "All simctl plumbing — Info.plist parsing, IPA unzip, install, boot+wait, simctl privacy grant all."],
    ["AndroidTools.swift", "All adb / emulator / aapt plumbing — APK badging, install -r, boot+wait via sys.boot_completed, pm grant for dangerous permissions."],
    ["TestStepsGenerator.swift", "Screenshot drag/drop/reorder, AppId field, feature name field, the 'Next Module' reset button."],
    ["MultiFlowSuiteGenerator.swift", "Builds the multi-flow AI prompt (with vault block appended), calls Gemini / Ollama, parses the JSON response, drives the preview cards, and orchestrates YAML save."],
    ["OfflineTestStepAndScenarioGenerator.swift", "Ollama-specific calls for offline mode (single-step DSL and CSV scenarios)."],
    ["YAMLGenerator.swift", "DSL → Maestro YAML transpiler. Splits DSL lines, maps each verb (Tap / Enter / TapIcon / Scroll / Visible / runflow) to maestro commands. Rewrites ${module.field} placeholders into the ${MODULE_FIELD} env-var form. Captures scenario_id markers for silent vault write-back."],
    ["VaultManager.swift", "Singleton. Owns test-data.json. Provides promptBlock(forModuleSlug:) used at AI-generation time, flattenedEnvDict() used at run time, and upsertAssertion() for silent write-back."],
    ["TestDataVaultView.swift", "Sheet UI for editing the vault. Inline-editable keys via EditableKeyCell. Add / delete data fields and assertion scenarios."],
    ["ModuleManager.swift", "Discovers modules by parsing YAML filenames. Computes execution order (login first → middle → logout last; within module: negative → edge → positive). Also hosts FolderWatcher for live UI refresh."],
    ["UItilityExplorer.swift", "Run-time plumbing. Builds /tmp/aiqa-staging, performs Layer 2 permission-block injection on the first ordered YAML, symlinks the rest, writes config.yaml, builds --env flags from the vault, runs maestro test."],
    ["CustomReportGenerator.swift", "Parses Maestro's html-detailed report, regenerates a branded HTML report with summary cards and expandable per-flow details. Also kicks off ExcelReportGenerator."],
    ["ExcelReportGenerator.swift", "Pure-Swift OOXML generator. Writes a self-contained .xlsx workbook listing every test case with module / type / title / status, color-coded green/red."],
], col_widths=[2.0, 4.7])

# ===================== 4. Execution Pipeline Deep Dive =====================
doc.add_page_break()
add_heading(doc, "4. Execution Pipeline Deep Dive", level=1)

# 4.1 Naming convention.
add_heading(doc, "4.1 Test case naming convention", level=2)
add_code(doc, "TC_<NNN>_<feature>_<type>_<title-slug>.yaml\n"
              "TC_001_login_positive_successful_login_with_valid_credentials.yaml")
add_para(doc, "The filename is the source of truth. ModuleManager.discoverModules() splits the stem on "
              "underscores and reads:")
add_bullet(doc, "parts[0] = 'TC' marker — anything else is skipped.")
add_bullet(doc, "parts[1] = serial number (NNN) — used for stable secondary sort.")
add_bullet(doc, "parts[2] = feature / module slug — used to group YAMLs into ModuleInfo entries.")
add_bullet(doc, "parts[3] = type — one of negative / edge / positive. Drives the type-rank sort (negatives first, positive last).")
add_bullet(doc, "parts[4..] = human-readable title slug — purely descriptive, not parsed.")
add_para(doc, "Because the entire ordering pipeline downstream — module grouping, within-module ordering, "
              "config.yaml flowsOrder — keys off this filename, regenerating a file with a different name "
              "automatically reslots it.")

# 4.2 Staging folder.
add_heading(doc, "4.2 /tmp/aiqa-staging — the run-time staging folder", level=2)
add_para(doc, "Every time the user hits Run, UItilityExplorer.runAutomationRunner() creates a fresh "
              "/tmp/aiqa-staging directory. This folder is the actual root Maestro is pointed at — never the "
              "user's flows/ folder. Three things land inside it:")
add_bullet(doc, "The first YAML in execution order — written as a real file with the Layer 2 first-launch permission-dismissal block spliced in just after the '---' separator.")
add_bullet(doc, "Every other YAML — symlinked to the original file in <app>/<platform>/flows/.")
add_bullet(doc, "config.yaml — written from buildMaestroConfigYAML(flowStems:). Contains executionOrder.flowsOrder so Maestro respects the chosen order.")
add_para(doc, "The whole folder is wiped at the start of every run, ensuring no leftover state from prior "
              "runs ever interferes. After Maestro exits, it is wiped again.")

# 4.3 Symlinks.
add_heading(doc, "4.3 What a symbolic link is, and why we use it here", level=2)
add_para(doc, "A symbolic link (symlink) is a tiny filesystem entry that contains a pointer to another file. "
              "When any process opens the symlink, the OS transparently redirects to the target. From "
              "Maestro's point of view a symlink looks exactly like a real YAML file — it reads the same bytes.")
add_para(doc, "Why symlinks instead of copying the YAMLs:")
add_bullet(doc, "Zero duplication — no test data is copied even for a 100-flow suite.")
add_bullet(doc, "Original YAMLs are guaranteed untouched, which preserves git diffs and prevents accidental corruption.")
add_bullet(doc, "Symlink creation is O(1) per file regardless of YAML size.")
add_bullet(doc, "Atomic — partial symlink failures don't leave half-copied artifacts.")
add_para(doc, "The single exception is index 0 — the first ordered flow — which is a real file because we "
              "modify its body to include the permission-dismissal block. The original on disk stays clean.")

# 4.4 config.yaml.
add_heading(doc, "4.4 config.yaml and executionOrder.flowsOrder", level=2)
add_para(doc, "By default, Maestro runs flows in a directory in non-deterministic order. That violates our "
              "guarantee of 'login first, logout last, negatives before positives within each module'. The "
              "fix is a config.yaml in the staging folder:")
add_code(doc, "executionOrder:\n"
              "  continueOnFailure: true\n"
              "  flowsOrder:\n"
              "    - TC_002_login_negative_incorrect_password\n"
              "    - TC_003_login_negative_empty_username\n"
              "    - TC_001_login_positive_successful_login_with_valid_credentials\n"
              "    - TC_004_addmoney_negative_invalid_amount\n"
              "    - ...\n"
              "    - TC_999_logout_positive_verify_successful_user_logout")
add_para(doc, "Each entry is the file stem (filename without .yaml). 'continueOnFailure: true' is set so "
              "one failing flow does not abort the remainder of the run — users want to see every result.")

# 4.5 Module ordering mechanism.
add_heading(doc, "4.5 How user control over module ordering works", level=2)
add_para(doc, "Three layers compose the final order:")
add_bullet(doc, "User selection — UI chips in ContentView feed a Set<String> of chosen module names.")
add_bullet(doc, "Module-level order — orderedYAMLs(from:selected:) places 'login' first, 'logout' last, and the remaining selected modules alphabetically in between.")
add_bullet(doc, "Within-module order — discoverModules() pre-sorts each module's YAMLs by typeRank (negative=0 / edge=1 / positive=2) and then by serial. So the positive 'state-changing' case always runs last within its module.")
add_para(doc, "Net effect for a typical run with login + middle modules + logout selected:")
add_code(doc, "login negatives  →  login edges  →  login positive   (user is now signed in)\n"
              "middle modules' negatives / edges / positives, alphabetical\n"
              "logout negatives →  logout edges →  logout positive  (session torn down, run ends)")

# 4.6 --env wiring.
add_heading(doc, "4.6 --env KEY=VALUE flag wiring (Vault → Maestro)", level=2)
add_para(doc, "The vault stores per-module data as a nested map; Maestro expects flat environment variables "
              "in CLI form. The transformation happens in two places:")
add_bullet(doc, "YAMLGenerator.rewriteVaultPlaceholders() — rewrites every ${module.field} placeholder in the YAML body to the flat form ${MODULE_FIELD}. This is what ends up on disk.")
add_bullet(doc, "VaultManager.flattenedEnvDict() — returns a [String:String] dictionary like { LOGIN_USERNAME: 'agent01', LOGIN_PASSWORD: 'Agent@123' }.")
add_bullet(doc, "UItilityExplorer.runAutomationRunner() — loops over that dictionary and builds a string of  --env KEY=VALUE flags. Each VALUE is wrapped via shellSingleQuote() so '$', spaces, quotes and special characters survive the zsh -c hop.")
add_para(doc, "Final command (paraphrased):")
add_code(doc, "~/.maestro/bin/maestro test \\\n"
              "  --env LOGIN_USERNAME='agent01' \\\n"
              "  --env LOGIN_PASSWORD='Agent@123' \\\n"
              "  --format html-detailed \\\n"
              "  --output <build>/report.html \\\n"
              "  /tmp/aiqa-staging")
add_para(doc, "Why CLI flags instead of process environment: Maestro's launcher script does not propagate "
              "arbitrary parent env vars to the substitution engine, so ${VAR} references would resolve to "
              "the literal string 'undefined'. CLI --env is the documented, reliable channel.")

# ===================== 5. Vault flow =====================
doc.add_page_break()
add_heading(doc, "5. Test Data Vault — Files, Functions, Flow", level=1)
add_table(doc, [
    ["Stage", "File", "Function", "What happens"],
    ["Edit UI", "TestDataVaultView.swift", "TestDataVaultView", "User adds module + data keys + assertions via inline-editable cells."],
    ["Persist", "VaultManager.swift", "save() / reload() / startWatching()", "Reads / writes test-data.json. Watches the file for external edits."],
    ["Prompt", "VaultManager.swift", "promptBlock(forModuleSlug:)", "Builds a strict 'VAULT FOR THIS MODULE' block appended to the AI prompt."],
    ["AI", "MultiFlowSuiteGenerator.swift", "buildMultiFlowPrompt()", "Embeds the vault block and feature name; sends to Gemini / Ollama."],
    ["Transpile", "YAMLGenerator.swift", "rewriteVaultPlaceholders() + extractScenarioContext()", "Converts ${module.field} → ${MODULE_FIELD}; silently writes the user-resolved Visible assertion back to the vault."],
    ["Inject env", "UItilityExplorer.swift", "runAutomationRunner() + shellSingleQuote()", "Pulls flattenedEnvDict() from the vault and passes each entry as a --env flag to maestro."],
    ["Write back", "VaultManager.swift", "upsertAssertion()", "Silently updates test-data.json so the next run already has the assertion learned."],
], col_widths=[1.0, 1.8, 2.0, 2.5])

# ===================== 6. Algorithms =====================
add_heading(doc, "6. Algorithms — what is and isn't used today", level=1)
add_para(doc, "The current pipeline is straight-line, not graph-based. Specifically:")
add_bullet(doc, "Module discovery: O(N) directory scan + O(N log N) stable sort. No BFS / DFS — the YAMLs are a flat list keyed by filename, not a tree.")
add_bullet(doc, "Within-module ordering: comparator-based sort on (typeRank, serial) — Swift's Timsort under the hood.")
add_bullet(doc, "Across-module ordering: explicit splice — login → middle (alphabetical sort) → logout.")
add_bullet(doc, "Permission-dismissal in flow: Maestro's repeat / while: visible loop. This is a fixed-point-style iteration, not a graph algorithm.")
add_para(doc, "BFS / DFS becomes relevant only once we bring in a tree-shaped input — exactly what the "
              "proposed Figma integration provides. See §8.")

# ===================== 7. Permission Handling =====================
add_heading(doc, "7. First-launch permission handling (Layer 1 + Layer 2)", level=1)
add_para(doc, "Mobile apps prompt the user with system dialogs (camera, location, notifications, ATT, etc.) "
              "on the very first launch after a fresh install. Two complementary layers handle this:")
add_bullet(doc, "Layer 1 — Install-time pre-grant. After a successful install, BuildManager.installCurrent() calls IOSTools.grantAllPrivacy() (xcrun simctl privacy <udid> grant all <bundleId>) or, on Android, parses the APK's dangerous permissions via aapt and runs adb pm grant for each. Eliminates roughly 80% of dialogs at the source.")
add_bullet(doc, "Layer 2 — First-flow YAML splice. UItilityExplorer.runAutomationRunner() injects a 'repeat while: visible' Allow / OK / Continue loop into only the first YAML in execution order. Permission grants are app-scoped (tcc.db / appops) and survive subsequent flows, so a single injection per run is sufficient.")
add_para(doc, "The two layers are additive. Layer 1 catches what simctl / pm can pre-grant; Layer 2 catches "
              "what they cannot (iOS notifications, App Tracking Transparency). The result is that the AI "
              "never has to learn about permission dialogs at all.")

# ===================== 8. Future enhancements =====================
doc.add_page_break()
add_heading(doc, "8. Future Enhancements", level=1)

# 8.1 Figma.
add_heading(doc, "8.1 Figma integration — design-driven test generation", level=2)
add_para(doc, "Idea: replace the manual screenshot upload step with an automated traversal of a Figma file. "
              "Each Figma page maps to a module; each top-level frame inside a page maps to a screen. The "
              "app fetches them, hands them to the existing vision-LLM pipeline, and out comes a full test "
              "suite without anyone capturing screenshots by hand.")
add_para(doc, "Concrete shape:")
add_bullet(doc, "Connect via Figma REST API (X-Figma-Token) — read-only is sufficient.")
add_bullet(doc, "BFS over the file's pages (each page = one module). For each page, run a DFS over its frame hierarchy collecting leaf frames (each leaf frame = one screen).")
add_bullet(doc, "Render each leaf frame to a PNG via the Figma images endpoint at 2x scale — the same kind of bitmap the user is feeding the model today.")
add_bullet(doc, "Feed the rendered screens through the existing MultiFlowSuiteGenerator. No transpiler or vault changes are needed downstream.")
add_para(doc, "Feasibility:", bold=True)
add_table(doc, [
    ["Concern", "Verdict"],
    ["Figma API exposes pages / frames / images", "Yes, fully documented. ~half a day to wire."],
    ["Designer file convention required?", "Yes — at minimum, one page per logical module. Frames must be named meaningfully so the test titles aren't garbage. Add an optional Code Connect / metadata layer on each frame for module type, intent, etc."],
    ["BFS / DFS difficulty", "Trivial. Figma's tree is tiny (typically <500 frames per file). Straight recursion is sufficient; BFS/DFS distinction is academic at this scale."],
    ["Inferring tap-to-navigate flows", "The hard part. Static frames don't tell you which button transitions to which screen. Two practical approaches: (a) require designers to add Figma 'Prototype' connections — those edges are exposed in the API — and walk the prototype graph; (b) keep the AI's screenshot-by-screenshot inference as today."],
    ["Time to MVP from current code base", "Roughly 2 to 3 engineer-weeks: Figma client (~3 d), tree traversal + frame export (~3 d), UI for picking the file and module mapping (~3 d), integration tests (~2 d), polish (~2 d)."],
    ["Will it eliminate human effort entirely?", "No. It eliminates the screenshot capture step. The DSL preview / edit step should still exist as the human safety valve."],
], col_widths=[2.6, 4.1])

# 8.2 Web testing.
add_heading(doc, "8.2 Web platform support", level=2)
add_para(doc, "Web is already a first-class entry in the Platform enum, but execution is disabled today. "
              "Maestro Web is the natural runtime. Required work:")
add_bullet(doc, "Replace the build slot with a URL field (no .ipa / .apk).")
add_bullet(doc, "Add a web-specific runner that points Maestro at the URL via maestro test --driver web.")
add_bullet(doc, "Slightly broaden the DSL: web-only verbs like NavigateToURL, SetCookie, AssertURL. The screenshot → DSL portion needs no changes — the vision model handles web screenshots equivalently.")
add_para(doc, "Estimated effort: 1 to 2 engineer-weeks for a usable MVP.")

# ===================== 9. Novelty & Patent worthiness =====================
add_heading(doc, "9. Novelty and Patent Worthiness", level=1)

add_heading(doc, "9.1 What exists in prior art", level=2)
add_bullet(doc, "Vision-LLM-driven screenshot-to-test research is published (Google, Microsoft) — the concept itself is not novel.")
add_bullet(doc, "Maestro and other YAML-based mobile automation frameworks exist.")
add_bullet(doc, "DSL → YAML transpilers are textbook compiler work.")
add_bullet(doc, "Test-data vaults / env-var injection are common in CI tooling.")

add_heading(doc, "9.2 What is novel today (current code base)", level=2)
add_para(doc, "Defensible claims rest on the combination, not individual pieces:")
add_bullet(doc, "A vault-aware AI prompt that statically constrains the model's allowed values per module, paired with a transpiler that converts dotted-placeholder DSL into Maestro --env flags with shell-safe escaping.")
add_bullet(doc, "Module-aware execution ordering via filename convention + comparator sort + dynamically-emitted config.yaml — guaranteeing login-first / logout-last and negative-before-positive semantics without burdening the test author.")
add_bullet(doc, "Two-layer first-launch permission handling: pre-grant via simctl / aapt+adb (Layer 1) and run-time splice into only the first ordered staged flow (Layer 2). Particularly the staging-time, run-time-determined target selection is not obvious in existing tooling.")
add_bullet(doc, "Silent vault write-back: a generated YAML containing a <TODO> Visible assertion, after user resolution, automatically updates test-data.json with the resolved assertion under the correct scenario_id — turning every test run into a learning event for the suite.")
add_para(doc, "Realistic assessment:", bold=True)
add_para(doc, "Patent-worthy as a combination — yes, especially the staging-time first-flow permission "
              "injection and the silent assertion write-back. But the strongest commercial moat today is "
              "the integrated workflow itself; a trade-secret + first-mover strategy is arguably more "
              "valuable than a narrow patent on any single mechanism.")

add_heading(doc, "9.3 Novelty after the Figma + traversal enhancement", level=2)
add_para(doc, "Adding a tree-traversal step over a design system file (Figma) changes the picture "
              "considerably. The novel claim becomes:")
add_bullet(doc, "A method for generating an executable, ordered end-to-end mobile UI test suite directly from a design system file, by traversing the design tree, rendering frames, generating an editable DSL via a vision LLM, transpiling to a declarative automation framework, and executing under a deterministic ordering policy with first-launch permission auto-handling.")
add_para(doc, "This is a substantially stronger claim because it ties together the design source of truth, "
              "the AI, the DSL, and the deterministic runtime under one method. We are not aware of an "
              "existing product that closes that loop end to end.")
add_para(doc, "Recommendation:", bold=True)
add_bullet(doc, "File a provisional patent application (US — and India, if the team is India-based) covering the staging mechanism + vault write-back + permission layering, before any public demo. A provisional locks in priority date and is cheap.")
add_bullet(doc, "Once the Figma traversal step is implemented, file a continuation-in-part adding the design-driven generation claims. That second filing is where the strongest commercial claim lives.")
add_bullet(doc, "In parallel, treat the integrated workflow as a trade secret — open-source nothing, demo behind NDA.")

# ===================== 10. Closing =====================
add_heading(doc, "10. Summary", level=1)
add_para(doc, "AIQA Test Runner collapses the most expensive part of mobile QA — authoring and maintaining "
              "end-to-end UI regression suites — into a screenshot-and-edit loop driven by a vision LLM and "
              "executed by Maestro under a deterministic ordering and data-injection policy. The pipeline "
              "is straight-line today; the planned Figma traversal step is the natural next step both for "
              "user productivity and for defensibility.")

# ---------- save ----------

out = Path(__file__).parent / "AIQA-TestRunner.docx"
doc.save(out.as_posix())
print(f"✓ wrote {out}")
